import React, { useState, useEffect } from 'react';
import { 
  Wrench, Plus, Trash2, Edit2, CheckCircle2, 
  Clock, X, Car, User, ShieldCheck, DollarSign 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';

export default function AdminJobCardsPage() {
  const [jobCards, setJobCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeJobDetails, setActiveJobDetails] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);

  // New Part / Labor Item Form
  const [itemType, setItemType] = useState('PART');
  const [itemDesc, setItemDesc] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unitPrice, setUnitPrice] = useState('');
  const [addingItem, setAddingItem] = useState(false);

  // Edit Job Card form
  const [technicianName, setTechnicianName] = useState('');
  const [workSummary, setWorkSummary] = useState('');
  const [diagnosisNotes, setDiagnosisNotes] = useState('');
  const [jobStatus, setJobStatus] = useState('QUEUED');
  const [updatingCard, setUpdatingCard] = useState(false);

  const loadJobCards = async () => {
    try {
      setLoading(true);
      const res = await api.getAllJobCards();
      if (res.success) {
        setJobCards(res.jobCards);
      }
    } catch (err) {
      console.error('Failed to load job cards:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobCards();
  }, []);

  const openJobCardDetails = async (jobId) => {
    try {
      setDetailLoading(true);
      const res = await api.getJobCardById(jobId);
      if (res.success) {
        setActiveJobDetails(res);
        setTechnicianName(res.jobCard.technician_name || '');
        setWorkSummary(res.jobCard.work_summary || '');
        setDiagnosisNotes(res.jobCard.diagnosis_notes || '');
        setJobStatus(res.jobCard.status || 'QUEUED');
      }
    } catch (err) {
      alert(err.message || 'Failed to load job card details');
    } finally {
      setDetailLoading(false);
    }
  };

  const handleAddItem = async (e) => {
    e.preventDefault();
    if (!itemDesc || !unitPrice || !activeJobDetails) return;

    setAddingItem(true);
    try {
      const res = await api.addJobItem(activeJobDetails.jobCard.id, {
        item_type: itemType,
        item_description: itemDesc,
        quantity: Number(quantity),
        unit_price: Number(unitPrice)
      });

      if (res.success) {
        setItemDesc('');
        setUnitPrice('');
        setQuantity(1);
        // Refresh detail
        openJobCardDetails(activeJobDetails.jobCard.id);
        loadJobCards();
      }
    } catch (err) {
      alert(err.message || 'Failed to add item');
    } finally {
      setAddingItem(false);
    }
  };

  const handleDeleteItem = async (itemId) => {
    if (window.confirm('Remove this item from the job card? Invoice will be automatically recalculated.')) {
      try {
        await api.deleteJobItem(itemId);
        openJobCardDetails(activeJobDetails.jobCard.id);
        loadJobCards();
      } catch (err) {
        alert(err.message || 'Failed to delete item');
      }
    }
  };

  const handleUpdateJobCard = async (e) => {
    e.preventDefault();
    if (!activeJobDetails) return;

    setUpdatingCard(true);
    try {
      await api.updateJobCard(activeJobDetails.jobCard.id, {
        technician_name: technicianName,
        diagnosis_notes: diagnosisNotes,
        work_summary: workSummary,
        status: jobStatus
      });
      alert('Job card updated successfully.');
      openJobCardDetails(activeJobDetails.jobCard.id);
      loadJobCards();
    } catch (err) {
      alert(err.message || 'Failed to update job card');
    } finally {
      setUpdatingCard(false);
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
          Workshop Job Cards & Diagnostics
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
          Manage bay operations, technician notes, and add replacement parts / labor to invoices
        </p>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
          Loading workshop job cards...
        </div>
      ) : jobCards.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem' }}>
          <Wrench size={44} color="#94a3b8" style={{ margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#0f172a' }}>
            No Workshop Job Cards Created
          </h3>
          <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.5rem' }}>
            Job cards are automatically initialized when customers book service appointments.
          </p>
        </div>
      ) : (
        <div className="grid-3">
          {jobCards.map((j) => (
            <div
              key={j.id}
              className="card"
              style={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                border: '1px solid #e2e8f0',
                borderRadius: '16px'
              }}
            >
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                  <span style={{
                    fontFamily: 'monospace',
                    fontWeight: 800,
                    fontSize: '0.9rem',
                    color: '#2563eb',
                    background: '#eff6ff',
                    padding: '0.2rem 0.6rem',
                    borderRadius: '6px'
                  }}>
                    {j.job_number}
                  </span>
                  <StatusBadge status={j.status} />
                </div>

                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.25rem' }}>
                  {j.service_name}
                </h3>
                <div style={{ fontSize: '0.825rem', color: '#64748b', marginBottom: '1rem' }}>
                  Ref: {j.booking_reference}
                </div>

                <div style={{
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  padding: '0.85rem',
                  fontSize: '0.825rem',
                  marginBottom: '1rem',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '0.4rem'
                }}>
                  <div>
                    <span style={{ color: '#64748b' }}>Vehicle: </span>
                    <strong>{j.make} {j.model}</strong> ({j.reg_number})
                  </div>
                  <div>
                    <span style={{ color: '#64748b' }}>Customer: </span>
                    <strong>{j.customer_name}</strong> ({j.customer_phone})
                  </div>
                  <div>
                    <span style={{ color: '#64748b' }}>Technician / Bay: </span>
                    <span>{j.technician_name} ({j.bay_number})</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => openJobCardDetails(j.id)}
                className="btn btn-primary btn-sm"
                style={{ width: '100%' }}
              >
                <Wrench size={14} />
                <span>Open Job Card & Parts ({j.item_count || 0})</span>
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Job Card Detailed View & Parts Management Modal */}
      {activeJobDetails && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '850px', padding: '2.5rem' }}>
            <button
              onClick={() => setActiveJobDetails(null)}
              style={{
                position: 'absolute',
                top: '1.25rem',
                right: '1.25rem',
                background: '#f1f5f9',
                border: 'none',
                borderRadius: '50%',
                width: '34px',
                height: '34px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: '#64748b'
              }}
            >
              <X size={18} />
            </button>

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', borderBottom: '1px solid #e2e8f0', paddingBottom: '1rem' }}>
              <div>
                <span style={{
                  fontFamily: 'monospace',
                  fontWeight: 800,
                  fontSize: '1.1rem',
                  color: '#2563eb'
                }}>
                  {activeJobDetails.jobCard.job_number}
                </span>
                <h2 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#0f172a', marginTop: '0.2rem' }}>
                  {activeJobDetails.jobCard.service_name}
                </h2>
                <div style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.2rem' }}>
                  Vehicle: <strong>{activeJobDetails.jobCard.make} {activeJobDetails.jobCard.model}</strong> ({activeJobDetails.jobCard.reg_number}) | Customer: {activeJobDetails.jobCard.customer_name}
                </div>
              </div>

              <div style={{ textAlign: 'right' }}>
                <StatusBadge status={activeJobDetails.jobCard.status} />
                {activeJobDetails.jobCard.total_amount && (
                  <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#2563eb', marginTop: '0.4rem' }}>
                    Total: ₹{Number(activeJobDetails.jobCard.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </div>
                )}
              </div>
            </div>

            {/* Diagnostic & Work Notes Form */}
            <form onSubmit={handleUpdateJobCard} style={{ marginBottom: '2rem' }}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Technician Assigned</label>
                  <input
                    type="text"
                    className="form-input"
                    value={technicianName}
                    onChange={(e) => setTechnicianName(e.target.value)}
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Job Status</label>
                  <select
                    className="form-select"
                    value={jobStatus}
                    onChange={(e) => setJobStatus(e.target.value)}
                  >
                    <option value="QUEUED">QUEUED</option>
                    <option value="INSPECTION">INSPECTION</option>
                    <option value="SERVICE_IN_PROGRESS">SERVICE_IN_PROGRESS</option>
                    <option value="QUALITY_CHECK">QUALITY_CHECK</option>
                    <option value="COMPLETED">COMPLETED</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Diagnosis Findings & Faults Detected</label>
                <textarea
                  className="form-textarea"
                  rows={2}
                  value={diagnosisNotes}
                  onChange={(e) => setDiagnosisNotes(e.target.value)}
                  placeholder="e.g. Engine oil degraded, brake pad thickness 2mm..."
                />
              </div>

              <div className="form-group">
                <label className="form-label">Work Summary & Actions Completed</label>
                <textarea
                  className="form-textarea"
                  rows={2}
                  value={workSummary}
                  onChange={(e) => setWorkSummary(e.target.value)}
                  placeholder="e.g. Flushed oil, replaced cartridge filter, bled brake lines..."
                />
              </div>

              <button
                type="submit"
                disabled={updatingCard}
                className="btn btn-secondary btn-sm"
              >
                {updatingCard ? 'Saving...' : 'Update Job Card Notes'}
              </button>
            </form>

            {/* Parts & Extra Labor Table */}
            <div style={{ borderTop: '2px solid #e2e8f0', paddingTop: '1.5rem', marginBottom: '1.5rem' }}>
              <h4 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
                Replaced Parts & Additional Labor Items
              </h4>
              <p style={{ fontSize: '0.8rem', color: '#64748b', marginBottom: '1rem' }}>
                Any parts or labor added here will immediately update the customer's GST invoice.
              </p>

              <table className="custom-table" style={{ marginBottom: '1.5rem' }}>
                <thead>
                  <tr>
                    <th>Item Description</th>
                    <th>Type</th>
                    <th>Qty</th>
                    <th>Unit Price (₹)</th>
                    <th>Total Price (₹)</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {activeJobDetails.items.length === 0 ? (
                    <tr>
                      <td colSpan={6} style={{ textAlign: 'center', color: '#94a3b8', padding: '1.5rem' }}>
                        No additional parts or labor added yet.
                      </td>
                    </tr>
                  ) : (
                    activeJobDetails.items.map((item) => (
                      <tr key={item.id}>
                        <td style={{ fontWeight: 600 }}>{item.item_description}</td>
                        <td>
                          <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#2563eb' }}>
                            {item.item_type}
                          </span>
                        </td>
                        <td>{item.quantity}</td>
                        <td>{Number(item.unit_price).toFixed(2)}</td>
                        <td style={{ fontWeight: 700 }}>{Number(item.total_price).toFixed(2)}</td>
                        <td>
                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer' }}
                            title="Delete Item"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>

              {/* Add Item Inline Form */}
              <div style={{ background: '#f8fafc', padding: '1.25rem', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                <h5 style={{ fontSize: '0.9rem', fontWeight: 700, color: '#1e293b', marginBottom: '0.75rem' }}>
                  + Add Part or Extra Labor Charge
                </h5>
                <form onSubmit={handleAddItem} style={{ display: 'grid', gridTemplateColumns: '1.2fr 2fr 0.8fr 1fr auto', gap: '0.75rem', alignItems: 'end' }}>
                  <div>
                    <label className="form-label" style={{ fontSize: '0.75rem' }}>Type</label>
                    <select
                      className="form-select"
                      style={{ fontSize: '0.85rem' }}
                      value={itemType}
                      onChange={(e) => setItemType(e.target.value)}
                    >
                      <option value="PART">PART</option>
                      <option value="LABOR">LABOR</option>
                      <option value="CONSUMABLE">CONSUMABLE</option>
                    </select>
                  </div>

                  <div>
                    <label className="form-label" style={{ fontSize: '0.75rem' }}>Item Description</label>
                    <input
                      type="text"
                      className="form-input"
                      style={{ fontSize: '0.85rem' }}
                      placeholder="e.g. Synthetic Oil 5W-30"
                      value={itemDesc}
                      onChange={(e) => setItemDesc(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <label className="form-label" style={{ fontSize: '0.75rem' }}>Qty</label>
                    <input
                      type="number"
                      className="form-input"
                      style={{ fontSize: '0.85rem' }}
                      min="1"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <label className="form-label" style={{ fontSize: '0.75rem' }}>Unit Price (₹)</label>
                    <input
                      type="number"
                      className="form-input"
                      style={{ fontSize: '0.85rem' }}
                      placeholder="e.g. 1850"
                      value={unitPrice}
                      onChange={(e) => setUnitPrice(e.target.value)}
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={addingItem}
                    className="btn btn-primary btn-sm"
                    style={{ height: '38px', padding: '0 1.25rem' }}
                  >
                    {addingItem ? 'Adding...' : 'Add Item'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
