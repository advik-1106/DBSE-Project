import React, { useState, useEffect } from 'react';
import { 
  Users, Car, Calendar, CreditCard, Wrench, 
  TrendingUp, Clock, CheckCircle2, ArrowRight, Search, AlertCircle 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';

export default function AdminDashboard({ setActivePage, setSelectedJobId }) {
  const [stats, setStats] = useState(null);
  const [recentBookings, setRecentBookings] = useState([]);
  const [popularServices, setPopularServices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAdminData() {
      try {
        setLoading(true);
        const res = await api.getAdminStats();
        if (res.success) {
          setStats(res.stats);
          setRecentBookings(res.recentBookings);
          setPopularServices(res.popularServices);
        }
      } catch (err) {
        console.error('Failed to load admin stats:', err);
      } finally {
        setLoading(false);
      }
    }
    loadAdminData();
  }, []);

  return (
    <div>
      {/* Header */}
      <div style={{
        background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 100%)',
        color: '#ffffff',
        borderRadius: '20px',
        padding: '2.25rem 2rem',
        marginBottom: '2rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1.5rem',
        boxShadow: '0 4px 12px rgba(15, 23, 42, 0.2)'
      }}>
        <div>
          <span style={{ fontSize: '0.85rem', color: '#38bdf8', fontWeight: 700, textTransform: 'uppercase' }}>
            Service Center Control Center
          </span>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, marginTop: '0.2rem' }}>
            Workshop Analytics & Operations
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.9rem', marginTop: '0.25rem' }}>
            Course: 25CS1302E | Team 30 (M.Manasa & T.Advik)
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button
            onClick={() => setActivePage('admin-bookings')}
            className="btn btn-primary"
          >
            <Calendar size={18} />
            <span>Manage Appointments</span>
          </button>
          <button
            onClick={() => setActivePage('admin-jobs')}
            className="btn btn-secondary"
          >
            <Wrench size={18} />
            <span>Workshop Job Cards</span>
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
          Loading service center operational data...
        </div>
      ) : stats ? (
        <div>
          {/* Key Metrics Grid */}
          <div className="grid-4" style={{ marginBottom: '2rem' }}>
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Total Bookings</span>
                <div style={{ background: '#eff6ff', color: '#2563eb', padding: '0.5rem', borderRadius: '10px' }}>
                  <Calendar size={20} />
                </div>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>{stats.total_bookings}</div>
              <div style={{ fontSize: '0.8rem', color: '#2563eb', marginTop: '0.25rem', fontWeight: 600 }}>
                {stats.pending_bookings} Pending Confirmation
              </div>
            </div>

            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Active in Workshop</span>
                <div style={{ background: '#fffbeb', color: '#f59e0b', padding: '0.5rem', borderRadius: '10px' }}>
                  <Wrench size={20} />
                </div>
              </div>
              <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f59e0b' }}>{stats.active_jobs}</div>
              <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
                Vehicles currently in bays
              </div>
            </div>

            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Settled Revenue</span>
                <div style={{ background: '#ecfdf5', color: '#10b981', padding: '0.5rem', borderRadius: '10px' }}>
                  <TrendingUp size={20} />
                </div>
              </div>
              <div style={{ fontSize: '1.85rem', fontWeight: 800, color: '#10b981' }}>
                ₹{Number(stats.total_revenue).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
                {stats.paid_invoices_count} Paid Invoices
              </div>
            </div>

            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
                <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Pending Receivables</span>
                <div style={{ background: '#fef2f2', color: '#ef4444', padding: '0.5rem', borderRadius: '10px' }}>
                  <CreditCard size={20} />
                </div>
              </div>
              <div style={{ fontSize: '1.85rem', fontWeight: 800, color: '#ef4444' }}>
                ₹{Number(stats.pending_payments).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
                {stats.unpaid_invoices_count} Unpaid Invoices
              </div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', marginBottom: '2.5rem' }}>
            {/* Recent Bookings Table */}
            <div className="card" style={{ padding: '1.75rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.25rem' }}>
                <div>
                  <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
                    Recent Service Bookings
                  </h3>
                  <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
                    Latest vehicle requests submitted to the service center
                  </p>
                </div>

                <button
                  onClick={() => setActivePage('admin-bookings')}
                  className="btn btn-secondary btn-sm"
                >
                  <span>View All Bookings</span>
                  <ArrowRight size={14} />
                </button>
              </div>

              <div className="table-responsive">
                <table className="custom-table">
                  <thead>
                    <tr>
                      <th>Ref & Customer</th>
                      <th>Vehicle</th>
                      <th>Service</th>
                      <th>Status</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentBookings.map((b) => (
                      <tr key={b.id}>
                        <td>
                          <div style={{ fontWeight: 700, fontFamily: 'monospace', color: '#2563eb' }}>
                            {b.booking_reference}
                          </div>
                          <div style={{ fontSize: '0.8rem', color: '#475569' }}>{b.customer_name}</div>
                        </td>
                        <td>
                          <div style={{ fontWeight: 600 }}>{b.make} {b.model}</div>
                          <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{b.reg_number}</div>
                        </td>
                        <td>{b.service_name}</td>
                        <td>
                          <StatusBadge status={b.status} />
                        </td>
                        <td>
                          <div style={{ fontWeight: 700 }}>
                            {b.total_amount ? `₹${Number(b.total_amount).toLocaleString('en-IN')}` : '—'}
                          </div>
                          <StatusBadge status={b.payment_status || 'UNPAID'} type="payment" />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Popular Services & Center Summary */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              <div className="card" style={{ padding: '1.75rem' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0f172a', marginBottom: '1rem' }}>
                  Popular Service Packages
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                  {popularServices.map((s, idx) => (
                    <div key={idx} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#1e293b' }}>{s.name}</div>
                        <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{s.category}</div>
                      </div>
                      <div style={{ textAlign: 'right' }}>
                        <span className="badge badge-confirmed" style={{ fontSize: '0.75rem' }}>
                          {s.booking_count} Bookings
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card" style={{ padding: '1.75rem', background: '#f8fafc' }}>
                <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.75rem' }}>
                  Center Registered Assets
                </h3>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', fontSize: '0.9rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#64748b' }}>Registered Customers:</span>
                    <strong style={{ color: '#0f172a' }}>{stats.total_customers}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#64748b' }}>Enrolled Vehicles:</span>
                    <strong style={{ color: '#0f172a' }}>{stats.total_vehicles}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#64748b' }}>Active Services Catalog:</span>
                    <strong style={{ color: '#0f172a' }}>{stats.total_services}</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
