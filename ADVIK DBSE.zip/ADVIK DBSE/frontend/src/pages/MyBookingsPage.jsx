import React, { useState, useEffect } from 'react';
import { 
  Calendar, Wrench, CreditCard, Clock, FileText, 
  Car, AlertCircle, CheckCircle2, XCircle, ChevronDown, ChevronUp 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';
import JobTracker from '../components/JobTracker';
import PaymentModal from '../components/PaymentModal';
import InvoiceModal from '../components/InvoiceModal';

export default function MyBookingsPage({ setActivePage, selectedBookingId }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('ALL');
  const [expandedId, setExpandedId] = useState(selectedBookingId || null);

  const [payInvoice, setPayInvoice] = useState(null);
  const [viewInvoiceId, setViewInvoiceId] = useState(null);

  const loadBookings = async () => {
    try {
      setLoading(true);
      const res = await api.getMyBookings();
      if (res.success) {
        setBookings(res.bookings);
        if (!expandedId && res.bookings.length > 0) {
          setExpandedId(res.bookings[0].id);
        }
      }
    } catch (err) {
      console.error('Failed to load bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, []);

  useEffect(() => {
    if (selectedBookingId) {
      setExpandedId(selectedBookingId);
    }
  }, [selectedBookingId]);

  const handleCancel = async (id) => {
    if (window.confirm('Are you sure you want to cancel this service appointment?')) {
      try {
        await api.cancelBooking(id);
        loadBookings();
      } catch (err) {
        alert(err.message || 'Failed to cancel booking.');
      }
    }
  };

  const filteredBookings = bookings.filter((b) => {
    if (filter === 'ACTIVE') return ['PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY'].includes(b.status);
    if (filter === 'COMPLETED') return b.status === 'COMPLETED';
    if (filter === 'CANCELLED') return b.status === 'CANCELLED';
    return true;
  });

  return (
    <div>
      {/* Page Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem',
        marginBottom: '2rem'
      }}>
        <div>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
            Live Service Job Tracking & Bookings
          </h1>
          <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
            Real-time status updates from the service bay, inspection logs, and invoice payment
          </p>
        </div>

        <button
          onClick={() => setActivePage('book-service')}
          className="btn btn-primary"
        >
          <Calendar size={16} />
          <span>Book Another Service</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' }}>
        {[
          { key: 'ALL', label: `All Bookings (${bookings.length})` },
          { key: 'ACTIVE', label: `In Progress (${bookings.filter(b => ['PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY'].includes(b.status)).length})` },
          { key: 'COMPLETED', label: `Completed (${bookings.filter(b => b.status === 'COMPLETED').length})` },
          { key: 'CANCELLED', label: `Cancelled (${bookings.filter(b => b.status === 'CANCELLED').length})` }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`btn btn-sm ${filter === tab.key ? 'btn-primary' : 'btn-secondary'}`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
          Loading your service bookings...
        </div>
      ) : filteredBookings.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem' }}>
          <Clock size={44} color="#94a3b8" style={{ margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#1e293b' }}>
            No Bookings Found
          </h3>
          <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.5rem' }}>
            {filter === 'ALL'
              ? "You haven't scheduled any automotive service appointments yet."
              : `No bookings found under the "${filter}" filter.`}
          </p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {filteredBookings.map((b) => {
            const isExpanded = expandedId === b.id;

            return (
              <div
                key={b.id}
                className="card"
                style={{
                  border: isExpanded ? '2px solid #2563eb' : '1px solid #e2e8f0',
                  padding: '1.75rem',
                  borderRadius: '16px',
                  transition: 'all 0.2s ease'
                }}
              >
                {/* Header Row */}
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  flexWrap: 'wrap',
                  gap: '1rem',
                  cursor: 'pointer'
                }}
                onClick={() => setExpandedId(isExpanded ? null : b.id)}
                >
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.4rem' }}>
                      <span style={{
                        fontFamily: 'monospace',
                        fontWeight: 800,
                        fontSize: '1rem',
                        color: '#2563eb',
                        background: '#eff6ff',
                        padding: '0.2rem 0.6rem',
                        borderRadius: '6px'
                      }}>
                        {b.booking_reference}
                      </span>
                      <StatusBadge status={b.status} />
                    </div>

                    <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
                      {b.service_name}
                    </h3>

                    <div style={{ fontSize: '0.85rem', color: '#64748b', display: 'flex', gap: '1rem', marginTop: '0.35rem', flexWrap: 'wrap' }}>
                      <span>🚗 <strong>{b.make} {b.model}</strong> ({b.reg_number})</span>
                      <span>📅 {b.booking_date}</span>
                      <span>⏰ {b.time_slot}</span>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a' }}>
                        ₹{Number(b.total_amount || b.base_price).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <StatusBadge status={b.payment_status || 'UNPAID'} type="payment" />
                    </div>

                    <button
                      type="button"
                      style={{
                        background: '#f1f5f9',
                        border: 'none',
                        borderRadius: '50%',
                        width: '36px',
                        height: '36px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: '#64748b'
                      }}
                    >
                      {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
                    </button>
                  </div>
                </div>

                {/* Collapsible Detail Section */}
                {isExpanded && (
                  <div style={{ marginTop: '1.75rem', borderTop: '1px solid #e2e8f0', paddingTop: '1.75rem' }}>
                    {/* Live Tracker */}
                    <div style={{ marginBottom: '1.75rem' }}>
                      <JobTracker currentStatus={b.status} />
                    </div>

                    {/* Workshop Meta info */}
                    <div className="grid-3" style={{ marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
                      <div>
                        <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600 }}>Assigned Technician</span>
                        <div style={{ fontWeight: 700, color: '#1e293b', fontSize: '0.9rem' }}>
                          {b.technician_name || 'Senior Workshop Specialist'}
                        </div>
                      </div>

                      <div>
                        <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600 }}>Job Card Number</span>
                        <div style={{ fontWeight: 700, fontFamily: 'monospace', color: '#1e293b', fontSize: '0.9rem' }}>
                          {b.job_number || 'JOB-PENDING'}
                        </div>
                      </div>

                      <div>
                        <span style={{ fontSize: '0.75rem', color: '#64748b', textTransform: 'uppercase', fontWeight: 600 }}>Service Notes</span>
                        <div style={{ color: '#475569', fontSize: '0.85rem' }}>
                          {b.customer_notes || 'Standard vehicle check requested.'}
                        </div>
                      </div>
                    </div>

                    {/* Action Bar */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
                      <div>
                        {['PENDING', 'CONFIRMED'].includes(b.status) && (
                          <button
                            onClick={() => handleCancel(b.id)}
                            className="btn btn-secondary btn-sm"
                            style={{ color: '#ef4444' }}
                          >
                            <XCircle size={15} />
                            <span>Cancel Appointment</span>
                          </button>
                        )}
                      </div>

                      <div style={{ display: 'flex', gap: '0.75rem' }}>
                        {b.invoice_id && (
                          <button
                            onClick={() => setViewInvoiceId(b.invoice_id)}
                            className="btn btn-secondary"
                          >
                            <FileText size={16} />
                            <span>View Full GST Invoice</span>
                          </button>
                        )}

                        {b.payment_status === 'UNPAID' && b.invoice_id && (
                          <button
                            onClick={() => setPayInvoice({
                              id: b.invoice_id,
                              invoice_number: b.invoice_number,
                              total_amount: b.total_amount,
                              service_name: b.service_name
                            })}
                            className="btn btn-primary"
                          >
                            <CreditCard size={16} />
                            <span>Pay ₹{Number(b.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })} Now</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Payment Gateway Modal */}
      {payInvoice && (
        <PaymentModal
          invoice={payInvoice}
          onClose={() => setPayInvoice(null)}
          onPaymentSuccess={() => {
            loadBookings();
          }}
        />
      )}

      {/* Invoice Modal */}
      {viewInvoiceId && (
        <InvoiceModal
          invoiceId={viewInvoiceId}
          onClose={() => setViewInvoiceId(null)}
          onPayClick={(inv) => setPayInvoice(inv)}
        />
      )}
    </div>
  );
}
