import React, { useState, useEffect } from 'react';
import { 
  Car, Calendar, CreditCard, Clock, Wrench, 
  PlusCircle, ArrowRight, CheckCircle2, AlertCircle, FileText 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';
import PaymentModal from '../components/PaymentModal';
import InvoiceModal from '../components/InvoiceModal';

export default function CustomerDashboard({ setActivePage, setSelectedBookingId }) {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  const [selectedInvoiceForPay, setSelectedInvoiceForPay] = useState(null);
  const [selectedInvoiceViewId, setSelectedInvoiceViewId] = useState(null);

  const loadData = async () => {
    try {
      setLoading(true);
      const [vRes, bRes] = await Promise.all([
        api.getMyVehicles(),
        api.getMyBookings()
      ]);
      if (vRes.success) setVehicles(vRes.vehicles);
      if (bRes.success) setBookings(bRes.bookings);
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const activeBookings = bookings.filter(b => ['PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY'].includes(b.status));
  const unpaidInvoices = bookings.filter(b => b.payment_status === 'UNPAID' && b.invoice_id);

  return (
    <div>
      {/* Welcome Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #1e293b 0%, #0f172a 100%)',
        color: '#ffffff',
        borderRadius: '20px',
        padding: '2.25rem 2rem',
        marginBottom: '2rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1.5rem',
        boxShadow: '0 4px 12px rgba(15, 23, 42, 0.15)'
      }}>
        <div>
          <span style={{ fontSize: '0.85rem', color: '#60a5fa', fontWeight: 700, textTransform: 'uppercase' }}>
            Customer Portal
          </span>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, marginTop: '0.2rem' }}>
            Welcome back, {user?.full_name}!
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.9rem', marginTop: '0.25rem' }}>
            Registered Phone: {user?.phone} | Account: Active
          </p>
        </div>

        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button
            onClick={() => setActivePage('book-service')}
            className="btn btn-primary"
            style={{ padding: '0.75rem 1.25rem' }}
          >
            <Calendar size={18} />
            <span>Book New Service</span>
          </button>
          <button
            onClick={() => setActivePage('my-vehicles')}
            className="btn btn-secondary"
            style={{ padding: '0.75rem 1.25rem' }}
          >
            <Car size={18} />
            <span>Manage Vehicles</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid-4" style={{ marginBottom: '2.5rem' }}>
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>My Vehicles</span>
            <div style={{ background: '#eff6ff', color: '#2563eb', padding: '0.5rem', borderRadius: '10px' }}>
              <Car size={20} />
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>{vehicles.length}</div>
          <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>Registered with Service Hub</div>
        </div>

        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Active Jobs</span>
            <div style={{ background: '#fffbeb', color: '#f59e0b', padding: '0.5rem', borderRadius: '10px' }}>
              <Wrench size={20} />
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#f59e0b' }}>{activeBookings.length}</div>
          <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>Currently in workshop</div>
        </div>

        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Completed Services</span>
            <div style={{ background: '#ecfdf5', color: '#10b981', padding: '0.5rem', borderRadius: '10px' }}>
              <CheckCircle2 size={20} />
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: '#10b981' }}>
            {bookings.filter(b => b.status === 'COMPLETED').length}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>Full history preserved</div>
        </div>

        <div className="card" style={{ borderColor: unpaidInvoices.length > 0 ? '#fecaca' : '#e2e8f0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
            <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Pending Invoices</span>
            <div style={{ background: '#fef2f2', color: '#ef4444', padding: '0.5rem', borderRadius: '10px' }}>
              <CreditCard size={20} />
            </div>
          </div>
          <div style={{ fontSize: '2rem', fontWeight: 800, color: unpaidInvoices.length > 0 ? '#ef4444' : '#10b981' }}>
            {unpaidInvoices.length}
          </div>
          <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
            {unpaidInvoices.length > 0 ? 'Payment required' : 'All accounts settled'}
          </div>
        </div>
      </div>

      {/* Unpaid Invoices Alert Banner (if any) */}
      {unpaidInvoices.length > 0 && (
        <div style={{
          background: '#fff1f2',
          border: '1px solid #fecdd3',
          borderRadius: '16px',
          padding: '1.25rem 1.5rem',
          marginBottom: '2rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '1rem'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <AlertCircle size={24} color="#e11d48" />
            <div>
              <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#9f1239' }}>
                You have {unpaidInvoices.length} pending service invoice(s)
              </h4>
              <p style={{ fontSize: '0.85rem', color: '#be123c' }}>
                Complete your payment online via UPI, Credit/Debit card, or Net Banking.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              const inv = unpaidInvoices[0];
              setSelectedInvoiceForPay({
                id: inv.invoice_id,
                invoice_number: inv.invoice_number,
                total_amount: inv.total_amount,
                service_name: inv.service_name
              });
            }}
            className="btn btn-primary"
            style={{ background: '#e11d48', borderColor: '#e11d48' }}
          >
            <CreditCard size={16} />
            <span>Pay Due Invoice (₹{unpaidInvoices[0].total_amount})</span>
          </button>
        </div>
      )}

      {/* Recent Bookings and Status Table */}
      <div className="card" style={{ padding: '1.75rem' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '1.25rem'
        }}>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
              My Vehicle Service Appointments
            </h3>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Track live workshop execution and access itemized invoices
            </p>
          </div>

          <button
            onClick={() => setActivePage('my-bookings')}
            className="btn btn-secondary btn-sm"
          >
            <span>View All & Live Tracker</span>
            <ArrowRight size={14} />
          </button>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '3rem 0', color: '#64748b' }}>
            Loading bookings...
          </div>
        ) : bookings.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem 0' }}>
            <Car size={40} color="#cbd5e1" style={{ margin: '0 auto 1rem' }} />
            <h4 style={{ fontSize: '1.1rem', fontWeight: 700, color: '#334155' }}>
              No service bookings found
            </h4>
            <p style={{ fontSize: '0.875rem', color: '#64748b', marginBottom: '1.25rem' }}>
              You haven't scheduled any automotive service appointments yet.
            </p>
            <button
              onClick={() => setActivePage('book-service')}
              className="btn btn-primary btn-sm"
            >
              Book Your First Service
            </button>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Booking Ref</th>
                  <th>Vehicle</th>
                  <th>Service Package</th>
                  <th>Date & Time</th>
                  <th>Status</th>
                  <th>Invoice & Payment</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {bookings.slice(0, 5).map((b) => (
                  <tr key={b.id}>
                    <td>
                      <span style={{ fontWeight: 700, fontFamily: 'monospace', color: '#2563eb' }}>
                        {b.booking_reference}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 700 }}>{b.make} {b.model}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{b.reg_number}</div>
                    </td>
                    <td>{b.service_name}</td>
                    <td>
                      <div>{b.booking_date}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{b.time_slot}</div>
                    </td>
                    <td>
                      <StatusBadge status={b.status} />
                    </td>
                    <td>
                      {b.total_amount ? (
                        <div>
                          <div style={{ fontWeight: 700 }}>₹{Number(b.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</div>
                          <StatusBadge status={b.payment_status} type="payment" />
                        </div>
                      ) : (
                        <span style={{ color: '#94a3b8', fontSize: '0.8rem' }}>Pending Inspection</span>
                      )}
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                        <button
                          onClick={() => {
                            if (setSelectedBookingId) setSelectedBookingId(b.id);
                            setActivePage('my-bookings');
                          }}
                          className="btn btn-secondary btn-sm"
                          title="Track Live Status"
                        >
                          <Clock size={14} />
                          <span>Track</span>
                        </button>

                        {b.invoice_id && (
                          <button
                            onClick={() => setSelectedInvoiceViewId(b.invoice_id)}
                            className="btn btn-secondary btn-sm"
                            title="View Invoice"
                          >
                            <FileText size={14} />
                          </button>
                        )}

                        {b.payment_status === 'UNPAID' && b.invoice_id && (
                          <button
                            onClick={() => setSelectedInvoiceForPay({
                              id: b.invoice_id,
                              invoice_number: b.invoice_number,
                              total_amount: b.total_amount,
                              service_name: b.service_name
                            })}
                            className="btn btn-primary btn-sm"
                          >
                            <CreditCard size={14} />
                            <span>Pay</span>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Payment Gateway Modal */}
      {selectedInvoiceForPay && (
        <PaymentModal
          invoice={selectedInvoiceForPay}
          onClose={() => setSelectedInvoiceForPay(null)}
          onPaymentSuccess={() => {
            loadData();
          }}
        />
      )}

      {/* Invoice Viewer Modal */}
      {selectedInvoiceViewId && (
        <InvoiceModal
          invoiceId={selectedInvoiceViewId}
          onClose={() => setSelectedInvoiceViewId(null)}
          onPayClick={(inv) => setSelectedInvoiceForPay(inv)}
        />
      )}
    </div>
  );
}
