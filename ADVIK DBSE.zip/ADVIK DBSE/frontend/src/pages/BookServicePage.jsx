import React, { useState, useEffect } from 'react';
import { 
  Calendar, Car, Wrench, Clock, CheckCircle2, 
  AlertCircle, ShieldCheck, ArrowRight 
} from 'lucide-react';
import { api } from '../api';

const TIME_SLOTS = [
  '09:00 AM - 11:00 AM',
  '11:00 AM - 01:00 PM',
  '02:00 PM - 04:00 PM',
  '04:00 PM - 06:00 PM'
];

export default function BookServicePage({ 
  setActivePage, 
  preSelectedVehicleId, 
  preSelectedServiceId,
  setSelectedBookingId 
}) {
  const [vehicles, setVehicles] = useState([]);
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);

  // Form State
  const [vehicleId, setVehicleId] = useState(preSelectedVehicleId || '');
  const [serviceId, setServiceId] = useState(preSelectedServiceId || '');
  const [bookingDate, setBookingDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  const [timeSlot, setTimeSlot] = useState(TIME_SLOTS[0]);
  const [notes, setNotes] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(null);

  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const [vRes, sRes] = await Promise.all([
          api.getMyVehicles(),
          api.getServices()
        ]);

        if (vRes.success) {
          setVehicles(vRes.vehicles);
          if (!vehicleId && vRes.vehicles.length > 0) {
            setVehicleId(vRes.vehicles[0].id);
          }
        }

        if (sRes.success) {
          setServices(sRes.services);
          if (!serviceId && sRes.services.length > 0) {
            setServiceId(sRes.services[0].id);
          }
        }
      } catch (err) {
        setError(err.message || 'Failed to load booking dependencies.');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const selectedService = services.find(s => String(s.id) === String(serviceId));
  const selectedVehicle = vehicles.find(v => String(v.id) === String(vehicleId));

  const basePrice = selectedService ? Number(selectedService.base_price) : 0;
  const tax = Number((basePrice * 0.18).toFixed(2));
  const totalEstimated = Number((basePrice + tax).toFixed(2));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!vehicleId || !serviceId) {
      setError('Please select both a vehicle and a service.');
      return;
    }

    setSubmitting(true);
    setError('');

    try {
      const res = await api.createBooking({
        vehicle_id: vehicleId,
        service_id: serviceId,
        booking_date: bookingDate,
        time_slot: timeSlot,
        customer_notes: notes
      });

      if (res.success) {
        setBookingSuccess(res.booking);
        if (setSelectedBookingId) {
          setSelectedBookingId(res.booking.id);
        }
      }
    } catch (err) {
      setError(err.message || 'Booking submission failed.');
    } finally {
      setSubmitting(false);
    }
  };

  if (bookingSuccess) {
    return (
      <div style={{ maxWidth: '600px', margin: '2rem auto' }}>
        <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem' }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            background: '#dcfce7',
            color: '#15803d',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1.5rem'
          }}>
            <CheckCircle2 size={36} />
          </div>

          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
            Appointment Booked Successfully!
          </h2>
          <p style={{ color: '#64748b', fontSize: '0.95rem', marginBottom: '1.5rem' }}>
            Your service bay reservation has been scheduled and entered into the workshop queue.
          </p>

          <div style={{
            background: '#f8fafc',
            border: '1px solid #e2e8f0',
            borderRadius: '12px',
            padding: '1.25rem',
            textAlign: 'left',
            marginBottom: '1.75rem',
            fontSize: '0.9rem'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ color: '#64748b' }}>Booking Reference:</span>
              <span style={{ fontWeight: 800, fontFamily: 'monospace', color: '#2563eb' }}>
                {bookingSuccess.booking_reference}
              </span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ color: '#64748b' }}>Service Scheduled:</span>
              <span style={{ fontWeight: 700 }}>{bookingSuccess.service_name}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
              <span style={{ color: '#64748b' }}>Date & Slot:</span>
              <span>{bookingSuccess.booking_date} ({bookingSuccess.time_slot})</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: '#64748b' }}>Estimated Bill:</span>
              <span style={{ fontWeight: 800, color: '#0f172a' }}>
                ₹{Number(bookingSuccess.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem', justifyContent: 'center' }}>
            <button
              onClick={() => setActivePage('my-bookings')}
              className="btn btn-primary"
            >
              <span>Track Live Workshop Progress</span>
              <ArrowRight size={16} />
            </button>
            <button
              onClick={() => {
                setBookingSuccess(null);
                setNotes('');
              }}
              className="btn btn-secondary"
            >
              Book Another Service
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
          Schedule Vehicle Service Appointment
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.95rem', marginTop: '0.25rem' }}>
          Select your registered vehicle, desired service package, and preferred time slot.
        </p>
      </div>

      {error && (
        <div style={{
          background: '#fef2f2',
          border: '1px solid #fecaca',
          color: '#b91c1c',
          padding: '0.85rem 1.25rem',
          borderRadius: '10px',
          fontSize: '0.9rem',
          marginBottom: '1.5rem'
        }}>
          {error}
        </div>
      )}

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem 0', color: '#64748b' }}>
          Loading service options...
        </div>
      ) : vehicles.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3rem 2rem' }}>
          <Car size={42} color="#94a3b8" style={{ margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#0f172a' }}>
            No Vehicles in Your Profile
          </h3>
          <p style={{ color: '#64748b', fontSize: '0.9rem', margin: '0.5rem auto 1.5rem', maxWidth: '400px' }}>
            You need to register at least one vehicle before scheduling a service appointment.
          </p>
          <button
            onClick={() => setActivePage('my-vehicles')}
            className="btn btn-primary"
          >
            Register a Vehicle First
          </button>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '2rem' }}>
          {/* Booking Form */}
          <div className="card" style={{ padding: '2rem' }}>
            <form onSubmit={handleSubmit}>
              {/* Step 1: Select Vehicle */}
              <div className="form-group">
                <label className="form-label" style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span>1. Select Vehicle</span>
                  <button
                    type="button"
                    onClick={() => setActivePage('my-vehicles')}
                    style={{ background: 'none', border: 'none', color: '#2563eb', fontSize: '0.8rem', fontWeight: 600, cursor: 'pointer' }}
                  >
                    + Add New Vehicle
                  </button>
                </label>
                <select
                  className="form-select"
                  value={vehicleId}
                  onChange={(e) => setVehicleId(e.target.value)}
                  required
                >
                  {vehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.make} {v.model} ({v.year}) - [{v.reg_number}]
                    </option>
                  ))}
                </select>
              </div>

              {/* Step 2: Select Service */}
              <div className="form-group">
                <label className="form-label">2. Select Service Package</label>
                <select
                  className="form-select"
                  value={serviceId}
                  onChange={(e) => setServiceId(e.target.value)}
                  required
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category}) — ₹{Number(s.base_price).toLocaleString('en-IN')}
                    </option>
                  ))}
                </select>
                {selectedService && (
                  <p style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.4rem', lineHeight: 1.4 }}>
                    {selectedService.description}
                  </p>
                )}
              </div>

              {/* Step 3: Date & Time */}
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">3. Appointment Date</label>
                  <input
                    type="date"
                    className="form-input"
                    min={new Date().toISOString().split('T')[0]}
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Preferred Time Slot</label>
                  <select
                    className="form-select"
                    value={timeSlot}
                    onChange={(e) => setTimeSlot(e.target.value)}
                  >
                    {TIME_SLOTS.map((slot) => (
                      <option key={slot} value={slot}>
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Step 4: Notes & Symptoms */}
              <div className="form-group">
                <label className="form-label">4. Vehicle Issues / Special Requests (Optional)</label>
                <textarea
                  className="form-textarea"
                  rows={3}
                  placeholder="e.g. Unusual noise from suspension, AC not cooling efficiently, squeaking brakes..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="btn btn-primary"
                style={{ width: '100%', padding: '0.85rem', fontSize: '1rem' }}
              >
                {submitting ? 'Confirming Appointment...' : 'Confirm & Reserve Service Slot'}
              </button>
            </form>
          </div>

          {/* Live Cost Estimation Summary Sidebar */}
          <div>
            <div className="card" style={{ padding: '1.75rem', position: 'sticky', top: '100px' }}>
              <h3 style={{ fontSize: '1.15rem', fontWeight: 800, color: '#0f172a', marginBottom: '1.25rem', borderBottom: '1px solid #e2e8f0', paddingBottom: '0.75rem' }}>
                Booking Summary
              </h3>

              {selectedVehicle && (
                <div style={{ marginBottom: '1rem', fontSize: '0.875rem' }}>
                  <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>VEHICLE</span>
                  <strong>{selectedVehicle.make} {selectedVehicle.model}</strong>
                  <div style={{ color: '#475569', fontSize: '0.8rem' }}>Reg: {selectedVehicle.reg_number}</div>
                </div>
              )}

              {selectedService && (
                <div style={{ marginBottom: '1.25rem', fontSize: '0.875rem' }}>
                  <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>SERVICE PACKAGE</span>
                  <strong>{selectedService.name}</strong>
                  <div style={{ color: '#475569', fontSize: '0.8rem' }}>Est. Duration: ~{selectedService.estimated_duration_hours} Hours</div>
                </div>
              )}

              <div style={{ borderTop: '1px solid #f1f5f9', paddingTop: '1rem', marginBottom: '1rem', fontSize: '0.875rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem', color: '#64748b' }}>
                  <span>Base Package Cost:</span>
                  <span>₹{basePrice.toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.4rem', color: '#64748b' }}>
                  <span>GST (18%):</span>
                  <span>₹{tax.toFixed(2)}</span>
                </div>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  borderTop: '2px solid #0f172a',
                  paddingTop: '0.65rem',
                  marginTop: '0.5rem',
                  fontSize: '1.1rem',
                  fontWeight: 800,
                  color: '#0f172a'
                }}>
                  <span>Estimated Total:</span>
                  <span style={{ color: '#2563eb' }}>
                    ₹{totalEstimated.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div style={{
                background: '#eff6ff',
                padding: '0.75rem',
                borderRadius: '8px',
                fontSize: '0.775rem',
                color: '#1e40af',
                lineHeight: 1.4,
                display: 'flex',
                gap: '0.5rem'
              }}>
                <ShieldCheck size={18} style={{ flexShrink: 0 }} />
                <span>
                  No immediate advance payment needed. Pay online after service completion or pickup!
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
