import React, { useState, useEffect } from 'react';
import { 
  CreditCard, FileText, CheckCircle2, AlertCircle, 
  Search, Printer, TrendingUp, DollarSign 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';
import InvoiceModal from '../components/InvoiceModal';

export default function AdminInvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [viewInvoiceId, setViewInvoiceId] = useState(null);

  const loadInvoices = async () => {
    try {
      setLoading(true);
      const query = statusFilter !== 'ALL' ? `status=${statusFilter}` : '';
      const res = await api.getAllInvoices(query);
      if (res.success) {
        setInvoices(res.invoices);
        setSummary(res.summary);
      }
    } catch (err) {
      console.error('Failed to load invoices:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, [statusFilter]);

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
          Billing, Invoices & Payment Ledger
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
          Real-time financial tracking, GST calculations, and payment gateway transaction logs
        </p>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid-3" style={{ marginBottom: '2rem' }}>
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Total Collected Revenue</span>
              <div style={{ background: '#ecfdf5', color: '#10b981', padding: '0.5rem', borderRadius: '10px' }}>
                <TrendingUp size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.85rem', fontWeight: 800, color: '#10b981' }}>
              ₹{Number(summary.total_revenue).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
              {summary.paid_count} Settled Invoices
            </div>
          </div>

          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Pending Receivables</span>
              <div style={{ background: '#fef2f2', color: '#ef4444', padding: '0.5rem', borderRadius: '10px' }}>
                <CreditCard size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.85rem', fontWeight: 800, color: '#ef4444' }}>
              ₹{Number(summary.pending_revenue).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
              {summary.unpaid_count} Awaiting Customer Payment
            </div>
          </div>

          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <span style={{ fontSize: '0.85rem', color: '#64748b', fontWeight: 600 }}>Total Invoices</span>
              <div style={{ background: '#eff6ff', color: '#2563eb', padding: '0.5rem', borderRadius: '10px' }}>
                <FileText size={20} />
              </div>
            </div>
            <div style={{ fontSize: '1.85rem', fontWeight: 800, color: '#0f172a' }}>
              {summary.total_invoices}
            </div>
            <div style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.25rem' }}>
              Includes Base Packages + Extra Parts + 18% GST
            </div>
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
        {['ALL', 'PAID', 'UNPAID'].map((status) => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`btn btn-sm ${statusFilter === status ? 'btn-primary' : 'btn-secondary'}`}
          >
            {status} Invoices
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="card" style={{ padding: '1rem' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '3.5rem 0', color: '#64748b' }}>
            Loading invoices...
          </div>
        ) : invoices.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem 0', color: '#64748b' }}>
            No invoices found under this category.
          </div>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Invoice Number</th>
                  <th>Booking Ref</th>
                  <th>Customer</th>
                  <th>Vehicle</th>
                  <th>Base Service</th>
                  <th>Total Amount</th>
                  <th>Payment Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv) => (
                  <tr key={inv.id}>
                    <td>
                      <span style={{ fontFamily: 'monospace', fontWeight: 800, color: '#2563eb' }}>
                        {inv.invoice_number}
                      </span>
                    </td>
                    <td>
                      <span style={{ fontFamily: 'monospace', color: '#475569' }}>
                        {inv.booking_reference}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{inv.customer_name}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{inv.customer_phone}</div>
                    </td>
                    <td>
                      <div>{inv.make} {inv.model}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{inv.reg_number}</div>
                    </td>
                    <td>{inv.service_name}</td>
                    <td>
                      <div style={{ fontWeight: 800, fontSize: '0.95rem' }}>
                        ₹{Number(inv.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>
                        (Tax: ₹{Number(inv.tax_amount).toFixed(2)})
                      </div>
                    </td>
                    <td>
                      <StatusBadge status={inv.payment_status} type="payment" />
                    </td>
                    <td>
                      <button
                        onClick={() => setViewInvoiceId(inv.id)}
                        className="btn btn-secondary btn-sm"
                      >
                        <FileText size={14} />
                        <span>Print Bill</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Invoice Viewer Modal */}
      {viewInvoiceId && (
        <InvoiceModal
          invoiceId={viewInvoiceId}
          onClose={() => setViewInvoiceId(null)}
        />
      )}
    </div>
  );
}
