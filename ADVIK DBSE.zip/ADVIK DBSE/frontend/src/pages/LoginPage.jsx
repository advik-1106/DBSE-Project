import React, { useState } from 'react';
import { LogIn, KeyRound, Mail, ShieldAlert, Sparkles, UserCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function LoginPage({ setActivePage }) {
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const user = await login(email, password);
      if (user.role === 'admin') {
        setActivePage('admin-dashboard');
      } else {
        setActivePage('customer-dashboard');
      }
    } catch (err) {
      setError(err.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickLogin = async (quickEmail, quickPassword) => {
    setEmail(quickEmail);
    setPassword(quickPassword);
    setError('');
    setLoading(true);
    try {
      const user = await login(quickEmail, quickPassword);
      if (user.role === 'admin') {
        setActivePage('admin-dashboard');
      } else {
        setActivePage('customer-dashboard');
      }
    } catch (err) {
      setError(err.message || 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '480px', margin: '2rem auto' }}>
      <div className="card" style={{ padding: '2.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '54px',
            height: '54px',
            borderRadius: '14px',
            background: '#eff6ff',
            color: '#2563eb',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto 1rem'
          }}>
            <LogIn size={26} />
          </div>
          <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a' }}>
            Sign In to AutoCare Pro
          </h2>
          <p style={{ color: '#64748b', fontSize: '0.875rem', marginTop: '0.25rem' }}>
            Access vehicle bookings, live tracking & digital billing
          </p>
        </div>

        {error && (
          <div style={{
            background: '#fef2f2',
            border: '1px solid #fecaca',
            color: '#b91c1c',
            padding: '0.75rem 1rem',
            borderRadius: '8px',
            fontSize: '0.875rem',
            marginBottom: '1.25rem'
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div style={{ position: 'relative' }}>
              <input
                type="email"
                className="form-input"
                placeholder="name@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div style={{ position: 'relative' }}>
              <input
                type="password"
                className="form-input"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{ width: '100%', padding: '0.8rem', fontSize: '0.95rem', marginTop: '0.5rem' }}
          >
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        {/* 1-Click Evaluation / Demo Buttons */}
        <div style={{ marginTop: '2rem', borderTop: '1px solid #e2e8f0', paddingTop: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.8rem', fontWeight: 700, color: '#475569', marginBottom: '0.75rem' }}>
            <Sparkles size={14} color="#f59e0b" />
            <span>Quick 1-Click Demo Accounts:</span>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={() => handleQuickLogin('advik@example.com', 'password123')}
              className="btn btn-secondary btn-sm"
              style={{ justifyContent: 'space-between', width: '100%', fontSize: '0.8rem' }}
            >
              <span>🚗 Customer: T. Advik</span>
              <span style={{ color: '#2563eb', fontWeight: 600 }}>Login as Advik →</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('manasa@example.com', 'password123')}
              className="btn btn-secondary btn-sm"
              style={{ justifyContent: 'space-between', width: '100%', fontSize: '0.8rem' }}
            >
              <span>🚗 Customer: M. Manasa</span>
              <span style={{ color: '#2563eb', fontWeight: 600 }}>Login as Manasa →</span>
            </button>

            <button
              type="button"
              onClick={() => handleQuickLogin('admin@autocare.com', 'admin123')}
              className="btn btn-dark btn-sm"
              style={{ justifyContent: 'space-between', width: '100%', fontSize: '0.8rem' }}
            >
              <span>🛡️ Admin: Service Center Hub</span>
              <span style={{ color: '#60a5fa', fontWeight: 600 }}>Login as Admin →</span>
            </button>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '1.5rem', fontSize: '0.875rem', color: '#64748b' }}>
          Don't have an account?{' '}
          <button
            type="button"
            onClick={() => setActivePage('register')}
            style={{ color: '#2563eb', fontWeight: 700, background: 'none', border: 'none', padding: 0 }}
          >
            Register Here
          </button>
        </div>
      </div>
    </div>
  );
}
