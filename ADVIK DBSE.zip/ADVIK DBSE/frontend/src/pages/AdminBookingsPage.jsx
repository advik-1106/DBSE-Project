import React, { useState, useEffect } from 'react';
import { 
  Calendar, Wrench, Search, Filter, Edit3, 
  CheckCircle2, Clock, X, User, Car 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';
import InvoiceModal from '../components/InvoiceModal';

export default function AdminBookingsPage({ setActivePage, setSelectedJobId }) {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Status Update Modal State
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [newStatus, setNewStatus] = useState('');
  const [technicianName, setTechnicianName] = useState('');
  const [bayNumber, setBayNumber] = useState('');
  const [remarks, setRemarks] = useState('');
  const [updating, setUpdating] = useState(false);
  const [viewInvoiceId, setViewInvoiceId] = useState(null);

  const loadBookings = async () => {
    try {
      setLoading(true);
      let queryParams = [];
      if (statusFilter && statusFilter !== 'ALL') queryParams.push(`status=${statusFilter}`);
      if (searchTerm) queryParams.push(`search=${encodeURIComponent(searchTerm)}`);

      const res = await api.getAllBookings(queryParams.join('&'));
      if (res.success) {
        setBookings(res.bookings);
      }
    } catch (err) {
      console.error('Failed to load bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [statusFilter, searchTerm]);

  const openStatusModal = (booking) => {
    setSelectedBooking(booking);
    setNewStatus(booking.status);
    setTechnicianName(booking.technician_name || 'Vikram Sharma');
    setBayNumber('Bay-1');
    setRemarks('');
  };

  const handleStatusSubmit = async (e) => {
    e.preventDefault();
    if (!selectedBooking) return;

    setUpdating(true);
    try {
      await api.updateBookingStatus(selectedBooking.id, {
        status: newStatus,
        technician_name: technicianName,
        bay_number: bayNumber,
        remarks: remarks || `Status transitioned to ${newStatus}`
      });
      setSelectedBooking(null);
      loadBookings();
    } catch (err) {
      alert(err.message || 'Failed to update booking status.');
    } finally {
      setUpdating(false);
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
          Customer Appointments & Service Requests
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
          Approve customer bookings, assign workshop technicians, and update job progress
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div style={{
        display: 'flex',
        flexWrap: 'wrap',
        gap: '1rem',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '1.5rem'
      }}>
        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
          {['ALL', 'PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY', 'COMPLETED'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`btn btn-sm ${statusFilter === status ? 'btn-primary' : 'btn-secondary'}`}
            >
              {status.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        <div style={{ position: 'relative', width: '300px' }}>
          <Search size={18} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
          <input
            type="text"
            className="form-input"
            style={{ paddingLeft: '2.5rem' }}
            placeholder="Search ref, customer, or car..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Bookings Table */}
      <div className="card" style={{ padding: '1rem' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '3.5rem 0', color: '#64748b' }}>
            Loading bookings...
          </div>
        ) : bookings.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '3rem 0', color: '#64748b' }}>
            No bookings found matching current filters.
          </div>
        ) : (
          <div className="table-responsive">
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Booking Ref</th>
                  <th>Customer Info</th>
                  <th>Vehicle Details</th>
                  <th>Service Requested</th>
                  <th>Scheduled Date</th>
                  <th>Current Status</th>
                  <th>Total / Payment</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr key={b.id}>
                    <td>
                      <span style={{ fontWeight: 800, fontFamily: 'monospace', color: '#2563eb' }}>
                        {b.booking_reference}
                      </span>
                    </td>
                    <td>
                      <div style={{ fontWeight: 700 }}>{b.customer_name}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{b.customer_phone}</div>
                    </td>
                    <td>
                      <div style={{ fontWeight: 600 }}>{b.make} {b.model}</div>
                      <span style={{
                        fontSize: '0.75rem',
                        fontFamily: 'monospace',
                        background: '#f1f5f9',
                        padding: '0.15rem 0.4rem',
                        borderRadius: '4px'
                      }}>
                        {b.reg_number}
                      </span>
                    </td>
                    <td>{b.service_name}</td>
                    <td>
                      <div>{b.booking_date}</div>
                      <div style={{ fontSize: '0.75rem', color: '#64748b' }}>{b.time_slot}</div>
                    </td>
                    <td>
                      <StatusBadge status={b.status} />
                    </td>
                    <td>
                      <div style={{ fontWeight: 700 }}>
                        {b.total_amount ? `₹${Number(b.total_amount).toLocaleString('en-IN')}` : '—'}
                      </div>
                      <StatusBadge status={b.payment_status || 'UNPAID'} type="payment" />
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '0.4rem' }}>
                        <button
                          onClick={() => openStatusModal(b)}
                          className="btn btn-secondary btn-sm"
                          title="Update Status & Technician"
                        >
                          <Edit3 size={14} />
                          <span>Status</span>
                        </button>

                        {b.invoice_id && (
                          <button
                            onClick={() => setViewInvoiceId(b.invoice_id)}
                            className="btn btn-secondary btn-sm"
                            title="Invoice Details"
                          >
                            Bill
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Update Status Modal */}
      {selectedBooking && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '2rem' }}>
            <button
              onClick={() => setSelectedBooking(null)}
              style={{
                position: 'absolute',
                top: '1.25rem',
                right: '1.25rem',
                background: '#f1f5f9',
                border: 'none',
                borderRadius: '50%',
                width: '32px',
                height: '32px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                color: '#64748b'
              }}
            >
              <X size={16} />
            </button>

            <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
              Update Booking Status & Workshop Allocation
            </h3>
            <p style={{ color: '#64748b', fontSize: '0.85rem', marginBottom: '1.25rem' }}>
              Ref: <strong style={{ color: '#2563eb' }}>{selectedBooking.booking_reference}</strong> | {selectedBooking.customer_name} ({selectedBooking.reg_number})
            </p>

            <form onSubmit={handleStatusSubmit}>
              <div className="form-group">
                <label className="form-label">Service Status Pipeline *</label>
                <select
                  className="form-select"
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value)}
                  required
                >
                  <option value="PENDING">PENDING (Awaiting Approval)</option>
                  <option value="CONFIRMED">CONFIRMED (Slot Reserved)</option>
                  <option value="IN_INSPECTION">IN_INSPECTION (Vehicle Received in Bay)</option>
                  <option value="IN_PROGRESS">IN_PROGRESS (Mechanics at Work)</option>
                  <option value="READY_FOR_DELIVERY">READY_FOR_DELIVERY (Quality Tested)</option>
                  <option value="COMPLETED">COMPLETED (Delivered to Customer)</option>
                  <option value="CANCELLED">CANCELLED</option>
                </select>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Assigned Technician</label>
                  <input
                    type="text"
                    className="form-input"
                    value={technicianName}
                    onChange={(e) => setTechnicianName(e.target.value)}
                    placeholder="e.g. Vikram Sharma"
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Workshop Bay</label>
                  <select
                    className="form-select"
                    value={bayNumber}
                    onChange={(e) => setBayNumber(e.target.value)}
                  >
                    <option value="Bay-1">Bay-1 (General)</option>
                    <option value="Bay-2">Bay-2 (Mechanical)</option>
                    <option value="Bay-3">Bay-3 (Electrical / AC)</option>
                    <option value="Bay-4">Bay-4 (Express)</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Service Log Remarks / Audit Note</label>
                <textarea
                  className="form-textarea"
                  rows={3}
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  placeholder="e.g. Vehicle check-in complete. Starting engine flush & filter replacement."
                />
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
                <button
                  type="button"
                  onClick={() => setSelectedBooking(null)}
                  className="btn btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updating}
                  className="btn btn-primary"
                >
                  {updating ? 'Updating...' : 'Save & Publish Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Modal */}
      {viewInvoiceId && (
        <InvoiceModal
          invoiceId={viewInvoiceId}
          onClose={() => setViewInvoiceId(null)}
        />
      )}
    </div>
  );
}
