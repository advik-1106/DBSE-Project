import React, { useState, useEffect } from 'react';
import { 
  Car, Plus, History, Calendar, Trash2, 
  Fuel, Gauge, Shield, AlertCircle, CheckCircle2 
} from 'lucide-react';
import { api } from '../api';
import VehicleHistoryModal from '../components/VehicleHistoryModal';

export default function MyVehiclesPage({ setActivePage, setSelectedVehicleId }) {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [historyVehicleId, setHistoryVehicleId] = useState(null);

  const [formData, setFormData] = useState({
    reg_number: '',
    make: '',
    model: '',
    year: new Date().getFullYear(),
    fuel_type: 'Petrol',
    mileage_km: '',
    vin_number: ''
  });

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const loadVehicles = async () => {
    try {
      setLoading(true);
      const res = await api.getMyVehicles();
      if (res.success) {
        setVehicles(res.vehicles);
      }
    } catch (err) {
      console.error('Failed to load vehicles:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleAddSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const res = await api.addVehicle(formData);
      if (res.success) {
        setSuccess('Vehicle registered successfully!');
        setFormData({
          reg_number: '',
          make: '',
          model: '',
          year: new Date().getFullYear(),
          fuel_type: 'Petrol',
          mileage_km: '',
          vin_number: ''
        });
        setShowAddModal(false);
        loadVehicles();
      }
    } catch (err) {
      setError(err.message || 'Failed to add vehicle.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id, reg) => {
    if (window.confirm(`Are you sure you want to remove vehicle ${reg} from your account?`)) {
      try {
        await api.deleteVehicle(id);
        loadVehicles();
      } catch (err) {
        alert(err.message || 'Failed to delete vehicle.');
      }
    }
  };

  const handleBookForVehicle = (vehicleId) => {
    if (setSelectedVehicleId) {
      setSelectedVehicleId(vehicleId);
    }
    setActivePage('book-service');
  };

  return (
    <div>
      {/* Header */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '1rem',
        marginBottom: '2rem'
      }}>
        <div>
          <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
            My Registered Vehicles
          </h1>
          <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
            Manage your garage, view maintenance logs, and initiate instant service bookings
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="btn btn-primary"
        >
          <Plus size={18} />
          <span>Register New Vehicle</span>
        </button>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '4rem 0', color: '#64748b' }}>
          Loading your vehicles...
        </div>
      ) : vehicles.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '3.5rem 1.5rem' }}>
          <Car size={48} color="#94a3b8" style={{ margin: '0 auto 1rem' }} />
          <h3 style={{ fontSize: '1.25rem', fontWeight: 700, color: '#1e293b' }}>
            No Vehicles Registered Yet
          </h3>
          <p style={{ color: '#64748b', fontSize: '0.9rem', maxWidth: '400px', margin: '0.5rem auto 1.5rem' }}>
            Add your car or two-wheeler details to enable one-click service bookings and digital service logs.
          </p>
          <button
            onClick={() => setShowAddModal(true)}
            className="btn btn-primary"
          >
            <Plus size={16} />
            <span>Add Vehicle Now</span>
          </button>
        </div>
      ) : (
        <div className="grid-3">
          {vehicles.map((v) => (
            <div
              key={v.id}
              className="card"
              style={{
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                border: '1px solid #e2e8f0',
                borderRadius: '16px'
              }}
            >
              <div>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '1rem'
                }}>
                  <span style={{
                    fontFamily: 'monospace',
                    fontWeight: 800,
                    fontSize: '0.95rem',
                    background: '#f1f5f9',
                    color: '#0f172a',
                    padding: '0.3rem 0.75rem',
                    borderRadius: '8px',
                    border: '1px solid #cbd5e1'
                  }}>
                    {v.reg_number}
                  </span>

                  <button
                    onClick={() => handleDelete(v.id, v.reg_number)}
                    style={{
                      background: 'none',
                      border: 'none',
                      color: '#94a3b8',
                      cursor: 'pointer',
                      padding: '4px'
                    }}
                    title="Remove Vehicle"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.35rem' }}>
                  {v.make} {v.model}
                </h3>
                <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '1.25rem' }}>
                  Model Year: {v.year}
                </div>

                <div style={{
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '0.75rem',
                  background: '#f8fafc',
                  padding: '0.85rem',
                  borderRadius: '10px',
                  marginBottom: '1.25rem',
                  fontSize: '0.825rem'
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#475569' }}>
                    <Fuel size={15} color="#2563eb" />
                    <span>{v.fuel_type}</span>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', color: '#475569' }}>
                    <Gauge size={15} color="#2563eb" />
                    <span>{Number(v.mileage_km || 0).toLocaleString()} km</span>
                  </div>
                  <div style={{ gridColumn: 'span 2', color: '#64748b', fontSize: '0.75rem' }}>
                    Past Services: <strong>{v.total_services || 0} times</strong>
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <button
                  onClick={() => setHistoryVehicleId(v.id)}
                  className="btn btn-secondary btn-sm"
                  style={{ width: '100%' }}
                >
                  <History size={14} />
                  <span>View Service History</span>
                </button>

                <button
                  onClick={() => handleBookForVehicle(v.id)}
                  className="btn btn-primary btn-sm"
                  style={{ width: '100%' }}
                >
                  <Calendar size={14} />
                  <span>Book Service Appointment</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Vehicle Modal */}
      {showAddModal && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ padding: '2rem' }}>
            <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
              Register Vehicle with Service Center
            </h3>
            <p style={{ color: '#64748b', fontSize: '0.875rem', marginBottom: '1.5rem' }}>
              Enter your vehicle details to link it to your automotive account
            </p>

            {error && (
              <div style={{
                background: '#fef2f2',
                color: '#b91c1c',
                padding: '0.75rem',
                borderRadius: '8px',
                fontSize: '0.875rem',
                marginBottom: '1rem'
              }}>
                {error}
              </div>
            )}

            <form onSubmit={handleAddSubmit}>
              <div className="form-group">
                <label className="form-label">Registration Number *</label>
                <input
                  type="text"
                  name="reg_number"
                  className="form-input"
                  placeholder="e.g. TS 09 EQ 4038"
                  value={formData.reg_number}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Vehicle Make (Manufacturer) *</label>
                  <input
                    type="text"
                    name="make"
                    className="form-input"
                    placeholder="e.g. Honda, Hyundai, Toyota"
                    value={formData.make}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label className="form-label">Model Name & Variant *</label>
                  <input
                    type="text"
                    name="model"
                    className="form-input"
                    placeholder="e.g. City ZX i-VTEC"
                    value={formData.model}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="grid-3">
                <div className="form-group">
                  <label className="form-label">Year of Manufacture *</label>
                  <input
                    type="number"
                    name="year"
                    className="form-input"
                    min="1990"
                    max={new Date().getFullYear() + 1}
                    value={formData.year}
                    onChange={handleChange}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Fuel Type</label>
                  <select
                    name="fuel_type"
                    className="form-select"
                    value={formData.fuel_type}
                    onChange={handleChange}
                  >
                    <option value="Petrol">Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Electric">Electric</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="CNG">CNG</option>
                  </select>
                </div>

                <div className="form-group">
                  <label className="form-label">Current Odometer (km)</label>
                  <input
                    type="number"
                    name="mileage_km"
                    className="form-input"
                    placeholder="e.g. 24500"
                    value={formData.mileage_km}
                    onChange={handleChange}
                  />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">VIN / Chassis Number (Optional)</label>
                <input
                  type="text"
                  name="vin_number"
                  className="form-input"
                  placeholder="e.g. MAKGM2650N400129"
                  value={formData.vin_number}
                  onChange={handleChange}
                />
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '1.5rem' }}>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="btn btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="btn btn-primary"
                >
                  {saving ? 'Registering...' : 'Register Vehicle'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyVehicleId && (
        <VehicleHistoryModal
          vehicleId={historyVehicleId}
          onClose={() => setHistoryVehicleId(null)}
        />
      )}
    </div>
  );
}
