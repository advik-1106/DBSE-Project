import React, { useState, useEffect } from 'react';
import { 
  Search, History, Car, Calendar, Wrench, 
  CheckCircle2, Fuel, Gauge, User, FileText, ArrowRight 
} from 'lucide-react';
import { api } from '../api';
import StatusBadge from '../components/StatusBadge';
import InvoiceModal from '../components/InvoiceModal';

export default function AdminVehicleSearchPage() {
  const [searchTerm, setSearchTerm] = useState('TS 09 EQ 4038');
  const [vehicleData, setVehicleData] = useState(null);
  const [allVehicles, setAllVehicles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewInvoiceId, setViewInvoiceId] = useState(null);

  // Load all vehicles for quick chips
  useEffect(() => {
    async function loadAll() {
      try {
        const res = await api.getAllVehicles();
        if (res.success) {
          setAllVehicles(res.vehicles);
        }
      } catch (err) {
        console.error('Failed to load fleet:', err);
      }
    }
    loadAll();
    handleSearch('TS 09 EQ 4038');
  }, []);

  const handleSearch = async (regToSearch) => {
    const reg = (regToSearch || searchTerm).trim();
    if (!reg) return;

    setLoading(true);
    setError('');
    try {
      const res = await api.searchVehicleHistory(reg);
      if (res.success) {
        setVehicleData(res);
      }
    } catch (err) {
      setError(err.message || `No service records found for registration "${reg}".`);
      setVehicleData(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
          Vehicle Master Service History Database
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.9rem', marginTop: '0.2rem' }}>
          Query any vehicle's complete historical maintenance timeline, past diagnostics, replaced parts, and invoices
        </p>
      </div>

      {/* Search Input Bar */}
      <div className="card" style={{ padding: '1.75rem', marginBottom: '2rem' }}>
        <form onSubmit={(e) => { e.preventDefault(); handleSearch(); }} style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative', flex: 1, minWidth: '260px' }}>
            <Search size={20} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
            <input
              type="text"
              className="form-input"
              style={{ paddingLeft: '2.75rem', fontSize: '1rem', textTransform: 'uppercase', fontWeight: 700 }}
              placeholder="Enter Registration No. (e.g. TS 09 EQ 4038)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-primary"
            style={{ padding: '0 1.75rem' }}
          >
            {loading ? 'Searching Database...' : 'Search History'}
          </button>
        </form>

        {/* Quick Sample Vehicles Pills */}
        <div style={{ marginTop: '1.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap', fontSize: '0.85rem' }}>
          <span style={{ color: '#64748b', fontWeight: 600 }}>Quick select from database:</span>
          {allVehicles.map((v) => (
            <button
              key={v.id}
              type="button"
              onClick={() => {
                setSearchTerm(v.reg_number);
                handleSearch(v.reg_number);
              }}
              style={{
                background: searchTerm === v.reg_number ? '#eff6ff' : '#f8fafc',
                border: `1px solid ${searchTerm === v.reg_number ? '#2563eb' : '#cbd5e1'}`,
                color: searchTerm === v.reg_number ? '#2563eb' : '#334155',
                padding: '0.25rem 0.65rem',
                borderRadius: '6px',
                fontFamily: 'monospace',
                fontWeight: 700,
                fontSize: '0.8rem',
                cursor: 'pointer'
              }}
            >
              {v.reg_number} ({v.make})
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div style={{
          background: '#fef2f2',
          border: '1px solid #fecaca',
          color: '#b91c1c',
          padding: '1rem 1.25rem',
          borderRadius: '12px',
          marginBottom: '2rem'
        }}>
          {error}
        </div>
      )}

      {/* Result Display */}
      {vehicleData && (
        <div>
          {/* Vehicle Metadata Header Card */}
          <div className="card" style={{ padding: '2rem', marginBottom: '2rem', border: '1px solid #cbd5e1' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1.5rem' }}>
              <div>
                <span style={{
                  background: '#0f172a',
                  color: '#ffffff',
                  fontFamily: 'monospace',
                  fontWeight: 800,
                  fontSize: '1.1rem',
                  padding: '0.35rem 0.85rem',
                  borderRadius: '8px',
                  display: 'inline-block',
                  marginBottom: '0.75rem'
                }}>
                  {vehicleData.vehicle.reg_number}
                </span>

                <h2 style={{ fontSize: '1.75rem', fontWeight: 800, color: '#0f172a' }}>
                  {vehicleData.vehicle.make} {vehicleData.vehicle.model} ({vehicleData.vehicle.year})
                </h2>

                <div style={{ fontSize: '0.875rem', color: '#64748b', marginTop: '0.35rem' }}>
                  Owner: <strong>{vehicleData.vehicle.owner_name}</strong> | Phone: {vehicleData.vehicle.owner_phone} | Email: {vehicleData.vehicle.owner_email}
                </div>
              </div>

              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: '1.25rem',
                background: '#f8fafc',
                padding: '1rem 1.5rem',
                borderRadius: '12px',
                border: '1px solid #e2e8f0',
                fontSize: '0.85rem'
              }}>
                <div>
                  <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>FUEL TYPE</span>
                  <strong>{vehicleData.vehicle.fuel_type}</strong>
                </div>
                <div>
                  <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>ODOMETER</span>
                  <strong>{Number(vehicleData.vehicle.mileage_km || 0).toLocaleString()} km</strong>
                </div>
                <div>
                  <span style={{ color: '#64748b', display: 'block', fontSize: '0.75rem' }}>TOTAL SERVICES</span>
                  <strong style={{ color: '#2563eb' }}>{vehicleData.history.length} Visits</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Historical Timeline */}
          <h3 style={{ fontSize: '1.35rem', fontWeight: 800, color: '#0f172a', marginBottom: '1.25rem' }}>
            Chronological Service History ({vehicleData.history.length} Entries)
          </h3>

          {vehicleData.history.length === 0 ? (
            <div className="card" style={{ textAlign: 'center', padding: '3rem', color: '#64748b' }}>
              No service visits recorded for this vehicle.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
              {vehicleData.history.map((record, index) => (
                <div
                  key={index}
                  className="card"
                  style={{
                    padding: '1.75rem',
                    borderRadius: '16px',
                    border: '1px solid #e2e8f0'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '0.35rem' }}>
                        <h4 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
                          {record.service_name}
                        </h4>
                        <span style={{ fontSize: '0.75rem', background: '#eff6ff', color: '#2563eb', padding: '0.2rem 0.5rem', borderRadius: '4px', fontWeight: 600 }}>
                          {record.service_category}
                        </span>
                        <StatusBadge status={record.booking_status} />
                      </div>

                      <div style={{ fontSize: '0.85rem', color: '#64748b', display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
                        <span>📅 Visit Date: <strong>{record.booking_date}</strong></span>
                        <span>Ref: <strong style={{ fontFamily: 'monospace' }}>{record.booking_reference}</strong></span>
                        {record.job_number && <span>Job Card: <strong style={{ fontFamily: 'monospace' }}>{record.job_number}</strong></span>}
                      </div>
                    </div>

                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
                        ₹{Number(record.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <StatusBadge status={record.payment_status} type="payment" />
                    </div>
                  </div>

                  {record.work_summary && (
                    <div style={{
                      background: '#f8fafc',
                      border: '1px solid #e2e8f0',
                      borderRadius: '10px',
                      padding: '1rem',
                      fontSize: '0.875rem',
                      marginBottom: '1rem',
                      color: '#334155'
                    }}>
                      <strong>Technician Diagnoses & Work Executed:</strong>
                      <p style={{ marginTop: '0.25rem' }}>{record.work_summary}</p>
                      {record.technician_name && (
                        <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.4rem' }}>
                          Lead Specialist: {record.technician_name}
                        </div>
                      )}
                    </div>
                  )}

                  {record.invoice_number && (
                    <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                      <button
                        onClick={() => setViewInvoiceId(record.booking_id)}
                        className="btn btn-secondary btn-sm"
                      >
                        <FileText size={14} />
                        <span>Inspect Stored Invoice ({record.invoice_number})</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Invoice Viewer Modal */}
      {viewInvoiceId && (
        <InvoiceModal
          invoiceId={viewInvoiceId}
          onClose={() => setViewInvoiceId(null)}
        />
      )}
    </div>
  );
}
