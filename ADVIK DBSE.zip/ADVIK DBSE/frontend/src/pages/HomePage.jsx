import React from 'react';
import { 
  Calendar, ShieldCheck, Clock, CreditCard, 
  Wrench, CheckCircle2, ArrowRight, Star, ChevronRight, Activity
} from 'lucide-react';

export default function HomePage({ setActivePage }) {
  return (
    <div>
      {/* Hero Section */}
      <section style={{
        background: 'radial-gradient(circle at top right, #1e3a8a 0%, #0f172a 100%)',
        color: '#ffffff',
        borderRadius: '24px',
        padding: '4rem 2.5rem',
        marginBottom: '3rem',
        position: 'relative',
        overflow: 'hidden',
        boxShadow: '0 20px 25px -5px rgba(15, 23, 42, 0.3)'
      }}>
        <div style={{ maxWidth: '720px', position: 'relative', zIndex: 2 }}>
          <div style={{
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.5rem',
            background: 'rgba(255, 255, 255, 0.1)',
            padding: '0.4rem 1rem',
            borderRadius: '9999px',
            fontSize: '0.85rem',
            fontWeight: 600,
            marginBottom: '1.5rem',
            backdropFilter: 'blur(4px)',
            border: '1px solid rgba(255, 255, 255, 0.15)'
          }}>
            <Activity size={16} color="#60a5fa" />
            <span>Next-Gen Automotive Service Job & Payment Platform</span>
          </div>

          <h1 style={{
            fontSize: '3rem',
            fontWeight: 800,
            letterSpacing: '-0.03em',
            lineHeight: 1.15,
            marginBottom: '1.25rem'
          }}>
            Hassle-Free Vehicle Care. <br />
            <span style={{ color: '#60a5fa' }}>Book Online, Track Live & Pay.</span>
          </h1>

          <p style={{
            fontSize: '1.1rem',
            color: '#cbd5e1',
            lineHeight: 1.6,
            marginBottom: '2rem'
          }}>
            Eliminate long queues, phone calls, and unexpected repair bills. Register your vehicle, pick a time slot, monitor workshop job progress in real-time, and pay securely via UPI, Cards, or Net Banking.
          </p>

          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
            <button
              onClick={() => setActivePage('book-service')}
              className="btn btn-primary"
              style={{ padding: '0.85rem 1.75rem', fontSize: '1rem', background: '#2563eb' }}
            >
              <span>Book Service Appointment</span>
              <ArrowRight size={18} />
            </button>
            <button
              onClick={() => setActivePage('services')}
              className="btn"
              style={{
                background: 'rgba(255,255,255,0.1)',
                color: '#ffffff',
                border: '1px solid rgba(255,255,255,0.2)',
                padding: '0.85rem 1.5rem'
              }}
            >
              Browse Services & Pricing
            </button>
          </div>
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section style={{ marginBottom: '3.5rem' }}>
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <h2 style={{ fontSize: '2rem', fontWeight: 800, color: '#0f172a' }}>
            Why Choose AutoCare Pro?
          </h2>
          <p style={{ color: '#64748b', fontSize: '1rem' }}>
            Engineered for complete transparency, efficiency, and customer satisfaction
          </p>
        </div>

        <div className="grid-4">
          <div className="card" style={{ textAlign: 'center', padding: '2rem 1.5rem' }}>
            <div style={{
              width: '56px',
              height: '56px',
              borderRadius: '16px',
              background: '#eff6ff',
              color: '#2563eb',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem'
            }}>
              <Calendar size={28} />
            </div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '0.5rem' }}>
              Online Booking
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b' }}>
              Schedule service appointments anytime with instant bay reservation and zero waiting time.
            </p>
          </div>

          <div className="card" style={{ textAlign: 'center', padding: '2rem 1.5rem' }}>
            <div style={{
              width: '56px',
              height: '56px',
              borderRadius: '16px',
              background: '#ecfdf5',
              color: '#10b981',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem'
            }}>
              <Clock size={28} />
            </div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '0.5rem' }}>
              Live Job Tracking
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b' }}>
              Track vehicle status step-by-step from inspection, servicing, to final quality check.
            </p>
          </div>

          <div className="card" style={{ textAlign: 'center', padding: '2rem 1.5rem' }}>
            <div style={{
              width: '56px',
              height: '56px',
              borderRadius: '16px',
              background: '#fef3c7',
              color: '#b45309',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem'
            }}>
              <Wrench size={28} />
            </div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '0.5rem' }}>
              Digital Job Cards
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b' }}>
              Detailed itemized records of parts replaced, labor charges, and technician diagnosis logs.
            </p>
          </div>

          <div className="card" style={{ textAlign: 'center', padding: '2rem 1.5rem' }}>
            <div style={{
              width: '56px',
              height: '56px',
              borderRadius: '16px',
              background: '#f3e8ff',
              color: '#7e22ce',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem'
            }}>
              <CreditCard size={28} />
            </div>
            <h3 style={{ fontSize: '1.15rem', fontWeight: 700, marginBottom: '0.5rem' }}>
              Instant Payment
            </h3>
            <p style={{ fontSize: '0.875rem', color: '#64748b' }}>
              Pay bills securely online via UPI QR code, Credit/Debit cards, or Net Banking with GST invoices.
            </p>
          </div>
        </div>
      </section>

      {/* How it Works Workflow Section */}
      <section style={{
        background: '#ffffff',
        border: '1px solid #e2e8f0',
        borderRadius: '24px',
        padding: '3rem 2rem',
        marginBottom: '3rem'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
          <span style={{ fontSize: '0.85rem', fontWeight: 700, color: '#2563eb', textTransform: 'uppercase' }}>
            Seamless Workflow
          </span>
          <h2 style={{ fontSize: '1.85rem', fontWeight: 800, color: '#0f172a', marginTop: '0.25rem' }}>
            How AutoCare Pro Works
          </h2>
        </div>

        <div className="grid-4">
          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#e2e8f0', lineHeight: 1 }}>01</div>
            <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0.5rem 0' }}>Register Vehicle</h4>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Save your car details once (make, model, fuel type, registration number) for future instant bookings.
            </p>
          </div>

          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#e2e8f0', lineHeight: 1 }}>02</div>
            <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0.5rem 0' }}>Pick Service & Slot</h4>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Select from periodic maintenance, AC recharge, brake servicing, or custom repair packages.
            </p>
          </div>

          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#e2e8f0', lineHeight: 1 }}>03</div>
            <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0.5rem 0' }}>Live Tracking</h4>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Watch technicians inspect, service, and road-test your vehicle directly on your dashboard.
            </p>
          </div>

          <div style={{ position: 'relative' }}>
            <div style={{ fontSize: '2.5rem', fontWeight: 800, color: '#e2e8f0', lineHeight: 1 }}>04</div>
            <h4 style={{ fontSize: '1.1rem', fontWeight: 700, margin: '0.5rem 0' }}>Pay & Drive</h4>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Inspect the transparent GST invoice, pay via the online payment gateway, and collect your vehicle.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
