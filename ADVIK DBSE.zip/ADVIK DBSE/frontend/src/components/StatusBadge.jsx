import React from 'react';
import { 
  Clock, CheckCircle, Wrench, AlertCircle, 
  CheckCheck, XCircle, CreditCard, Sparkles 
} from 'lucide-react';

export default function StatusBadge({ status, type = 'booking' }) {
  if (!status) return null;

  const normalized = status.toUpperCase();

  const config = {
    // Booking / Job Statuses
    PENDING: { label: 'Pending Approval', class: 'badge-pending', icon: Clock },
    CONFIRMED: { label: 'Confirmed', class: 'badge-confirmed', icon: CheckCircle },
    IN_INSPECTION: { label: 'In Inspection', class: 'badge-inspection', icon: Sparkles },
    IN_PROGRESS: { label: 'Work In Progress', class: 'badge-in_progress', icon: Wrench },
    SERVICE_IN_PROGRESS: { label: 'Work In Progress', class: 'badge-in_progress', icon: Wrench },
    READY_FOR_DELIVERY: { label: 'Ready for Delivery', class: 'badge-ready', icon: CheckCheck },
    QUALITY_CHECK: { label: 'Quality Check', class: 'badge-ready', icon: CheckCheck },
    COMPLETED: { label: 'Completed', class: 'badge-completed', icon: CheckCircle },
    CANCELLED: { label: 'Cancelled', class: 'badge-cancelled', icon: XCircle },
    QUEUED: { label: 'Queued', class: 'badge-pending', icon: Clock },
    
    // Payment Statuses
    PAID: { label: 'Paid', class: 'badge-paid', icon: CheckCircle },
    UNPAID: { label: 'Payment Due', class: 'badge-unpaid', icon: AlertCircle },
    REFUNDED: { label: 'Refunded', class: 'badge-cancelled', icon: XCircle }
  };

  const current = config[normalized] || {
    label: normalized.replace(/_/g, ' '),
    class: 'badge-pending',
    icon: Clock
  };

  const Icon = current.icon;

  return (
    <span className={`badge ${current.class}`}>
      <Icon size={13} />
      <span>{current.label}</span>
    </span>
  );
}
