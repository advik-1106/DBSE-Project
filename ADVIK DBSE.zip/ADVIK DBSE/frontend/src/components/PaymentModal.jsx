import React, { useState } from 'react';
import { X, CreditCard, QrCode, Building, CheckCircle2, ShieldCheck, Loader2 } from 'lucide-react';
import { api } from '../api';

export default function PaymentModal({ invoice, onClose, onPaymentSuccess }) {
  const [method, setMethod] = useState('UPI');
  const [upiId, setUpiId] = useState('advik@oksbi');
  const [cardNumber, setCardNumber] = useState('4532 8901 2345 6789');
  const [cardHolder, setCardHolder] = useState('T. Advik');
  const [expiry, setExpiry] = useState('12/28');
  const [cvv, setCvv] = useState('789');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  
  const [processing, setProcessing] = useState(false);
  const [successResult, setSuccessResult] = useState(null);
  const [error, setError] = useState('');

  if (!invoice) return null;

  const handlePay = async (e) => {
    e.preventDefault();
    setProcessing(true);
    setError('');

    try {
      // Simulate real gateway processing delay
      await new Promise(r => setTimeout(r, 1200));

      const payload = {
        invoice_id: invoice.id,
        payment_method: method === 'UPI' ? 'UPI' : (method === 'CARD' ? 'CREDIT_CARD' : 'NET_BANKING'),
        upi_id: method === 'UPI' ? upiId : null,
        card_number: method === 'CARD' ? cardNumber.replace(/\s/g, '') : null,
        card_holder: method === 'CARD' ? cardHolder : null
      };

      const res = await api.processPayment(payload);
      if (res.success) {
        setSuccessResult(res.payment);
        if (onPaymentSuccess) {
          onPaymentSuccess(res.payment);
        }
      }
    } catch (err) {
      setError(err.message || 'Payment transaction failed.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '580px', padding: '2rem' }}>
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: '#f1f5f9',
            border: 'none',
            borderRadius: '50%',
            width: '34px',
            height: '34px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: '#64748b'
          }}
        >
          <X size={18} />
        </button>

        {successResult ? (
          <div style={{ textAlign: 'center', padding: '1.5rem 0' }}>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '50%',
              background: '#dcfce7',
              color: '#15803d',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              margin: '0 auto 1.25rem'
            }}>
              <CheckCircle2 size={38} />
            </div>

            <h3 style={{ fontSize: '1.4rem', fontWeight: 800, color: '#0f172a', marginBottom: '0.5rem' }}>
              Payment Successful!
            </h3>
            <p style={{ color: '#64748b', fontSize: '0.925rem', marginBottom: '1.5rem' }}>
              Your automotive service invoice has been settled in full.
            </p>

            <div style={{
              background: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1.25rem',
              textAlign: 'left',
              marginBottom: '1.5rem',
              fontSize: '0.9rem'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ color: '#64748b' }}>Amount Paid:</span>
                <span style={{ fontWeight: 800, color: '#0f172a' }}>₹{Number(successResult.amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ color: '#64748b' }}>Transaction Ref:</span>
                <span style={{ fontFamily: 'monospace', fontWeight: 600 }}>{successResult.payment_reference}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ color: '#64748b' }}>Gateway Txn ID:</span>
                <span style={{ fontFamily: 'monospace', color: '#475569' }}>{successResult.transaction_id}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: '#64748b' }}>Payment Mode:</span>
                <span style={{ fontWeight: 600 }}>{successResult.payment_method}</span>
              </div>
            </div>

            <button onClick={onClose} className="btn btn-primary" style={{ width: '100%' }}>
              Done & Return to Bookings
            </button>
          </div>
        ) : (
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1rem' }}>
              <div style={{
                background: '#eff6ff',
                color: '#2563eb',
                padding: '0.65rem',
                borderRadius: '10px'
              }}>
                <ShieldCheck size={26} />
              </div>
              <div>
                <h3 style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a' }}>
                  Secure Payment Gateway
                </h3>
                <span style={{ fontSize: '0.825rem', color: '#64748b' }}>
                  Invoice Ref: {invoice.invoice_number}
                </span>
              </div>
            </div>

            {/* Bill Summary Strip */}
            <div style={{
              background: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1rem',
              marginBottom: '1.5rem',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <div>
                <div style={{ fontSize: '0.8rem', color: '#64748b' }}>Total Payable Amount</div>
                <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#2563eb' }}>
                  ₹{Number(invoice.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                </div>
              </div>
              <div style={{ textAlign: 'right', fontSize: '0.775rem', color: '#64748b' }}>
                Includes 18% GST<br />
                {invoice.service_name || 'Vehicle Service'}
              </div>
            </div>

            {error && (
              <div style={{
                background: '#fef2f2',
                color: '#b91c1c',
                padding: '0.75rem 1rem',
                borderRadius: '8px',
                fontSize: '0.875rem',
                marginBottom: '1rem'
              }}>
                {error}
              </div>
            )}

            {/* Payment Method Selector */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '0.75rem',
              marginBottom: '1.5rem'
            }}>
              <button
                type="button"
                onClick={() => setMethod('UPI')}
                style={{
                  padding: '0.85rem 0.5rem',
                  borderRadius: '10px',
                  border: `2px solid ${method === 'UPI' ? '#2563eb' : '#e2e8f0'}`,
                  background: method === 'UPI' ? '#eff6ff' : '#ffffff',
                  color: method === 'UPI' ? '#2563eb' : '#475569',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.35rem'
                }}
              >
                <QrCode size={20} />
                <span>UPI / QR</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('CARD')}
                style={{
                  padding: '0.85rem 0.5rem',
                  borderRadius: '10px',
                  border: `2px solid ${method === 'CARD' ? '#2563eb' : '#e2e8f0'}`,
                  background: method === 'CARD' ? '#eff6ff' : '#ffffff',
                  color: method === 'CARD' ? '#2563eb' : '#475569',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.35rem'
                }}
              >
                <CreditCard size={20} />
                <span>Card (Debit/Credit)</span>
              </button>

              <button
                type="button"
                onClick={() => setMethod('NET_BANKING')}
                style={{
                  padding: '0.85rem 0.5rem',
                  borderRadius: '10px',
                  border: `2px solid ${method === 'NET_BANKING' ? '#2563eb' : '#e2e8f0'}`,
                  background: method === 'NET_BANKING' ? '#eff6ff' : '#ffffff',
                  color: method === 'NET_BANKING' ? '#2563eb' : '#475569',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.35rem'
                }}
              >
                <Building size={20} />
                <span>Net Banking</span>
              </button>
            </div>

            <form onSubmit={handlePay}>
              {method === 'UPI' && (
                <div>
                  <div style={{
                    background: '#f8fafc',
                    border: '1px dashed #cbd5e1',
                    borderRadius: '12px',
                    padding: '1.25rem',
                    textAlign: 'center',
                    marginBottom: '1rem'
                  }}>
                    {/* SVG QR Code Simulation */}
                    <div style={{
                      width: '130px',
                      height: '130px',
                      margin: '0 auto 0.75rem',
                      background: '#ffffff',
                      padding: '8px',
                      borderRadius: '8px',
                      border: '1px solid #e2e8f0',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=upi://pay?pa=autocare@icici&pn=AutoCare%20Pro&am=${invoice.total_amount}&cu=INR`} 
                        alt="UPI QR Code" 
                        style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                        onError={(e) => {
                          e.target.style.display = 'none';
                        }}
                      />
                    </div>
                    <div style={{ fontSize: '0.8rem', color: '#64748b' }}>
                      Scan using Google Pay, PhonePe, Paytm, or BHIM
                    </div>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Or Enter UPI VPA ID</label>
                    <input
                      type="text"
                      className="form-input"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      placeholder="e.g. yourname@oksbi"
                      required
                    />
                  </div>
                </div>
              )}

              {method === 'CARD' && (
                <div>
                  <div className="form-group">
                    <label className="form-label">Card Number</label>
                    <input
                      type="text"
                      className="form-input"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      placeholder="4532 8901 2345 6789"
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Cardholder Name</label>
                    <input
                      type="text"
                      className="form-input"
                      value={cardHolder}
                      onChange={(e) => setCardHolder(e.target.value)}
                      placeholder="Name on card"
                      required
                    />
                  </div>
                  <div className="grid-2">
                    <div className="form-group">
                      <label className="form-label">Expiry (MM/YY)</label>
                      <input
                        type="text"
                        className="form-input"
                        value={expiry}
                        onChange={(e) => setExpiry(e.target.value)}
                        placeholder="12/28"
                        required
                      />
                    </div>
                    <div className="form-group">
                      <label className="form-label">CVV Code</label>
                      <input
                        type="password"
                        className="form-input"
                        value={cvv}
                        onChange={(e) => setCvv(e.target.value)}
                        placeholder="•••"
                        maxLength={4}
                        required
                      />
                    </div>
                  </div>
                </div>
              )}

              {method === 'NET_BANKING' && (
                <div className="form-group">
                  <label className="form-label">Select Your Bank</label>
                  <select
                    className="form-select"
                    value={selectedBank}
                    onChange={(e) => setSelectedBank(e.target.value)}
                  >
                    <option value="HDFC Bank">HDFC Bank</option>
                    <option value="State Bank of India">State Bank of India (SBI)</option>
                    <option value="ICICI Bank">ICICI Bank</option>
                    <option value="Axis Bank">Axis Bank</option>
                    <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                    <option value="Punjab National Bank">Punjab National Bank</option>
                  </select>
                  <p style={{ fontSize: '0.8rem', color: '#64748b', marginTop: '0.5rem' }}>
                    You will be securely routed through your bank's encrypted internet banking portal.
                  </p>
                </div>
              )}

              <button
                type="submit"
                disabled={processing}
                className="btn btn-primary"
                style={{ width: '100%', padding: '0.85rem', fontSize: '1rem', marginTop: '0.5rem' }}
              >
                {processing ? (
                  <>
                    <Loader2 size={18} className="spin" />
                    <span>Processing Secure Payment...</span>
                  </>
                ) : (
                  <span>Pay ₹{Number(invoice.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })} Now</span>
                )}
              </button>

              <div style={{
                textAlign: 'center',
                fontSize: '0.75rem',
                color: '#94a3b8',
                marginTop: '1rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.4rem'
              }}>
                <ShieldCheck size={14} color="#10b981" />
                256-Bit SSL Encrypted Automotive Payment Simulation Gateway
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
