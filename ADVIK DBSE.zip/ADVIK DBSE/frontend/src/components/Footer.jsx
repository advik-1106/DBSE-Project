import React from 'react';
import { Database, Server, ShieldCheck, Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer style={{
      background: '#0f172a',
      color: '#94a3b8',
      padding: '3rem 1.5rem 2rem',
      marginTop: 'auto',
      borderTop: '1px solid #1e293b'
    }}>
      <div style={{
        maxWidth: '1280px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '2.5rem',
        marginBottom: '2.5rem'
      }}>
        {/* Col 1 */}
        <div>
          <h4 style={{ color: '#ffffff', fontSize: '1.15rem', fontWeight: 800, marginBottom: '0.75rem' }}>
            AutoCare Pro System
          </h4>
          <p style={{ fontSize: '0.85rem', lineHeight: 1.6, color: '#94a3b8' }}>
            A full-stack, distributed web-based solution for automotive service job booking, live workshop tracking, automated billing, and integrated payment processing.
          </p>
          <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', fontSize: '0.8rem', color: '#cbd5e1' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              <Database size={14} color="#60a5fa" /> MySQL 8.0
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
              <Server size={14} color="#34d399" /> Node.js & Express
            </span>
          </div>
        </div>

        {/* Col 2 */}
        <div>
          <h4 style={{ color: '#ffffff', fontSize: '0.95rem', fontWeight: 700, marginBottom: '0.75rem' }}>
            Academic Project Submission
          </h4>
          <div style={{ fontSize: '0.85rem', lineHeight: 1.6 }}>
            <div style={{ color: '#38bdf8', fontWeight: 600 }}>Course:</div>
            <div>DATABASE SYSTEMS ENGINEERING & DISTRIBUTED BACKEND DEVELOPMENT (25CS1302E)</div>
            <div style={{ marginTop: '0.5rem', color: '#cbd5e1' }}>
              KLH Deemed to be University, Hyderabad
            </div>
          </div>
        </div>

        {/* Col 3 */}
        <div>
          <h4 style={{ color: '#ffffff', fontSize: '0.95rem', fontWeight: 700, marginBottom: '0.75rem' }}>
            Project Team Members
          </h4>
          <div style={{ fontSize: '0.85rem', lineHeight: 1.7 }}>
            <div>
              <strong style={{ color: '#ffffff' }}>T. Advik</strong> - Roll No: <span style={{ fontFamily: 'monospace', color: '#60a5fa' }}>2520039623</span>
            </div>
            <div>
              <strong style={{ color: '#ffffff' }}>M. Manasa</strong> - Roll No: <span style={{ fontFamily: 'monospace', color: '#60a5fa' }}>2520030438</span>
            </div>
            <div style={{ marginTop: '0.4rem', color: '#94a3b8' }}>
              Section 02 | Team No. 30 | Y25 Trimester-4
            </div>
          </div>
        </div>
      </div>

      <div style={{
        borderTop: '1px solid #1e293b',
        paddingTop: '1.5rem',
        textAlign: 'center',
        fontSize: '0.8rem',
        color: '#64748b'
      }}>
        © 2026-2027 AutoCare Pro Automotive Service & Payment System. All rights reserved.
      </div>
    </footer>
  );
}
