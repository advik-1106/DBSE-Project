import React from 'react';
import { CalendarCheck, Search, Wrench, CheckCircle, Car } from 'lucide-react';

const STEPS = [
  { key: 'CONFIRMED', title: 'Booking Confirmed', desc: 'Appointment slot locked in', icon: CalendarCheck },
  { key: 'IN_INSPECTION', title: 'Inspection & Diagnostics', desc: 'Bay check & parts inspection', icon: Search },
  { key: 'IN_PROGRESS', title: 'Service In Progress', desc: 'Mechanics working on vehicle', icon: Wrench },
  { key: 'READY_FOR_DELIVERY', title: 'Ready for Delivery', desc: 'Final testing & wash complete', icon: CheckCircle },
  { key: 'COMPLETED', title: 'Delivered & Closed', desc: 'Invoiced & handed over', icon: Car }
];

export default function JobTracker({ currentStatus }) {
  const statusRank = {
    PENDING: 0,
    CONFIRMED: 1,
    IN_INSPECTION: 2,
    IN_PROGRESS: 3,
    SERVICE_IN_PROGRESS: 3,
    READY_FOR_DELIVERY: 4,
    QUALITY_CHECK: 4,
    COMPLETED: 5,
    CANCELLED: -1
  };

  const currentRank = statusRank[currentStatus?.toUpperCase()] ?? 0;

  if (currentStatus === 'CANCELLED') {
    return (
      <div style={{
        padding: '1.25rem',
        borderRadius: '12px',
        background: '#fef2f2',
        border: '1px solid #fecaca',
        color: '#991b1b',
        fontWeight: 600,
        textAlign: 'center'
      }}>
        ⚠️ This service booking has been cancelled.
      </div>
    );
  }

  return (
    <div style={{
      background: '#ffffff',
      borderRadius: '16px',
      padding: '1.5rem',
      border: '1px solid #e2e8f0',
      boxShadow: '0 2px 4px rgba(0,0,0,0.04)'
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '1.5rem'
      }}>
        <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#1e293b' }}>
          Live Service Job Tracker
        </h4>
        <span style={{ fontSize: '0.825rem', color: '#64748b' }}>
          Real-time Workshop Updates
        </span>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        gap: '0.75rem',
        position: 'relative'
      }}>
        {STEPS.map((step, idx) => {
          const stepRank = idx + 1;
          const isDone = currentRank >= stepRank;
          const isCurrent = currentRank === stepRank || (currentRank === 0 && idx === 0);
          const Icon = step.icon;

          return (
            <div
              key={step.key}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                textAlign: 'center',
                position: 'relative',
                zIndex: 2
              }}
            >
              <div
                style={{
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '0.75rem',
                  transition: 'all 0.3s ease',
                  background: isCurrent 
                    ? '#2563eb' 
                    : isDone 
                      ? '#10b981' 
                      : '#f1f5f9',
                  color: (isCurrent || isDone) ? '#ffffff' : '#94a3b8',
                  boxShadow: isCurrent ? '0 0 0 4px rgba(37, 99, 235, 0.2)' : 'none'
                }}
              >
                <Icon size={20} />
              </div>

              <div style={{
                fontSize: '0.825rem',
                fontWeight: isCurrent ? 700 : 600,
                color: isCurrent ? '#2563eb' : isDone ? '#1e293b' : '#94a3b8',
                marginBottom: '0.2rem'
              }}>
                {step.title}
              </div>

              <div style={{
                fontSize: '0.725rem',
                color: '#64748b',
                lineHeight: 1.2
              }}>
                {step.desc}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
