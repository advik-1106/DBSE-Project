import React, { useState, useEffect } from 'react';
import { X, Printer, CreditCard, CheckCircle2, AlertCircle } from 'lucide-react';
import { api } from '../api';

export default function InvoiceModal({ invoiceId, onClose, onPayClick }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchInvoice() {
      try {
        setLoading(true);
        const res = await api.getInvoiceDetails(invoiceId);
        if (res.success) {
          setData(res);
        }
      } catch (err) {
        setError(err.message || 'Failed to load invoice details.');
      } finally {
        setLoading(false);
      }
    }
    if (invoiceId) {
      fetchInvoice();
    }
  }, [invoiceId]);

  if (!invoiceId) return null;

  const invoice = data?.invoice;
  const items = data?.items || [];
  const payments = data?.payments || [];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '750px', padding: '2.5rem' }}>
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: '#f1f5f9',
            border: 'none',
            borderRadius: '50%',
            width: '34px',
            height: '34px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: '#64748b'
          }}
        >
          <X size={18} />
        </button>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '3rem 0', color: '#64748b' }}>
            Loading formal automotive invoice...
          </div>
        ) : error ? (
          <div style={{ color: '#ef4444', textAlign: 'center', padding: '2rem 0' }}>
            {error}
          </div>
        ) : invoice ? (
          <div>
            {/* Invoice Header */}
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              borderBottom: '2px solid #e2e8f0',
              paddingBottom: '1.5rem',
              marginBottom: '1.5rem'
            }}>
              <div>
                <h2 style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a' }}>
                  AutoCare Pro Service Hub
                </h2>
                <p style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.2rem' }}>
                  Department of Database Systems Engineering & Distributed Systems<br />
                  KLH Bachupally, Hyderabad, Telangana - 500043<br />
                  GSTIN: 36AAACL1234F1Z8 | Phone: +91 98765 43210
                </p>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span style={{
                  display: 'inline-block',
                  background: invoice.payment_status === 'PAID' ? '#dcfce7' : '#fee2e2',
                  color: invoice.payment_status === 'PAID' ? '#15803d' : '#b91c1c',
                  padding: '0.35rem 0.85rem',
                  borderRadius: '20px',
                  fontWeight: 800,
                  fontSize: '0.85rem',
                  letterSpacing: '0.05em'
                }}>
                  {invoice.payment_status === 'PAID' ? 'TAX INVOICE - PAID' : 'TAX INVOICE - PAYMENT DUE'}
                </span>
                <div style={{ fontSize: '0.95rem', fontWeight: 700, marginTop: '0.5rem', color: '#1e293b' }}>
                  #{invoice.invoice_number}
                </div>
                <div style={{ fontSize: '0.825rem', color: '#64748b' }}>
                  Date: {invoice.created_at ? new Date(invoice.created_at).toLocaleDateString() : 'Today'}
                </div>
              </div>
            </div>

            {/* Billed To & Vehicle Details Strip */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '1.5rem',
              marginBottom: '1.75rem',
              background: '#f8fafc',
              padding: '1.25rem',
              borderRadius: '12px',
              border: '1px solid #e2e8f0'
            }}>
              <div>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>
                  Customer Details
                </span>
                <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', marginTop: '0.2rem' }}>
                  {invoice.customer_name}
                </h4>
                <p style={{ fontSize: '0.85rem', color: '#475569' }}>
                  Phone: {invoice.customer_phone}<br />
                  Email: {invoice.customer_email}<br />
                  {invoice.customer_address && `Address: ${invoice.customer_address}`}
                </p>
              </div>

              <div>
                <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#64748b', textTransform: 'uppercase' }}>
                  Vehicle & Job Info
                </span>
                <h4 style={{ fontSize: '1rem', fontWeight: 700, color: '#0f172a', marginTop: '0.2rem' }}>
                  {invoice.make} {invoice.model} ({invoice.year})
                </h4>
                <p style={{ fontSize: '0.85rem', color: '#475569' }}>
                  Registration: <strong>{invoice.reg_number}</strong><br />
                  Booking Ref: {invoice.booking_reference}<br />
                  Job Card: {invoice.job_number || 'N/A'} (Tech: {invoice.technician_name || 'Staff'})
                </p>
              </div>
            </div>

            {/* Itemized Table */}
            <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
              <thead>
                <tr style={{ background: '#f1f5f9', textAlign: 'left', borderBottom: '2px solid #cbd5e1' }}>
                  <th style={{ padding: '0.75rem 1rem' }}>Description</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>Type</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>Qty</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Unit Price (₹)</th>
                  <th style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>Amount (₹)</th>
                </tr>
              </thead>
              <tbody>
                {/* 1. Base Service Package */}
                <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                  <td style={{ padding: '0.75rem 1rem' }}>
                    <strong>{invoice.service_name}</strong>
                    <div style={{ fontSize: '0.775rem', color: '#64748b' }}>Scheduled Periodic Maintenance Package</div>
                  </td>
                  <td style={{ padding: '0.75rem 1rem', textAlign: 'center', color: '#2563eb', fontWeight: 600, fontSize: '0.8rem' }}>
                    SERVICE
                  </td>
                  <td style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>1</td>
                  <td style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>
                    {Number(invoice.service_base_amount).toFixed(2)}
                  </td>
                  <td style={{ padding: '0.75rem 1rem', textAlign: 'right', fontWeight: 600 }}>
                    {Number(invoice.service_base_amount).toFixed(2)}
                  </td>
                </tr>

                {/* 2. Parts and Additional Labor Items */}
                {items.map((item, idx) => (
                  <tr key={idx} style={{ borderBottom: '1px solid #e2e8f0' }}>
                    <td style={{ padding: '0.75rem 1rem' }}>
                      {item.item_description}
                    </td>
                    <td style={{ padding: '0.75rem 1rem', textAlign: 'center', fontSize: '0.8rem', color: '#059669', fontWeight: 600 }}>
                      {item.item_type}
                    </td>
                    <td style={{ padding: '0.75rem 1rem', textAlign: 'center' }}>
                      {item.quantity}
                    </td>
                    <td style={{ padding: '0.75rem 1rem', textAlign: 'right' }}>
                      {Number(item.unit_price).toFixed(2)}
                    </td>
                    <td style={{ padding: '0.75rem 1rem', textAlign: 'right', fontWeight: 600 }}>
                      {Number(item.total_price).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Calculations Breakdown */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '2rem' }}>
              <div style={{ width: '280px', fontSize: '0.9rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.35rem 0', color: '#475569' }}>
                  <span>Service Package:</span>
                  <span>₹{Number(invoice.service_base_amount).toFixed(2)}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.35rem 0', color: '#475569' }}>
                  <span>Parts & Extra Labor:</span>
                  <span>₹{Number(invoice.additional_parts_labor).toFixed(2)}</span>
                </div>
                {Number(invoice.discount_amount) > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.35rem 0', color: '#16a34a' }}>
                    <span>Special Discount:</span>
                    <span>-₹{Number(invoice.discount_amount).toFixed(2)}</span>
                  </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '0.35rem 0', color: '#475569' }}>
                  <span>GST (18% Total):</span>
                  <span>₹{Number(invoice.tax_amount).toFixed(2)}</span>
                </div>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  padding: '0.75rem 0 0.25rem',
                  borderTop: '2px solid #0f172a',
                  marginTop: '0.5rem',
                  fontSize: '1.15rem',
                  fontWeight: 800,
                  color: '#0f172a'
                }}>
                  <span>Grand Total:</span>
                  <span style={{ color: '#2563eb' }}>
                    ₹{Number(invoice.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>

            {/* Payment history if paid */}
            {payments.length > 0 && (
              <div style={{
                background: '#ecfdf5',
                border: '1px solid #a7f3d0',
                borderRadius: '8px',
                padding: '0.85rem 1rem',
                marginBottom: '1.5rem',
                fontSize: '0.85rem',
                color: '#065f46'
              }}>
                <CheckCircle2 size={16} style={{ display: 'inline', marginRight: '6px', verticalAlign: '-3px' }} />
                Paid via {payments[0].payment_method} (Txn: {payments[0].transaction_id}) on {new Date(payments[0].payment_date).toLocaleString()}
              </div>
            )}

            {/* Modal Actions */}
            <div style={{ display: 'flex', gap: '1rem', justifyContent: 'flex-end', borderTop: '1px solid #e2e8f0', paddingTop: '1.5rem' }}>
              <button onClick={handlePrint} className="btn btn-secondary">
                <Printer size={16} />
                <span>Print Invoice</span>
              </button>

              {invoice.payment_status === 'UNPAID' && onPayClick && (
                <button
                  onClick={() => {
                    onClose();
                    onPayClick(invoice);
                  }}
                  className="btn btn-primary"
                >
                  <CreditCard size={16} />
                  <span>Pay Now Online</span>
                </button>
              )}
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
