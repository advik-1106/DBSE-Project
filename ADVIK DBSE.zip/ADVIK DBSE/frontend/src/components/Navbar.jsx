import React from 'react';
import { 
  Wrench, Car, Calendar, CreditCard, LogOut, 
  LogIn, User, Shield, LayoutDashboard, History, CheckSquare
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar({ activePage, setActivePage }) {
  const { user, isAuthenticated, isAdmin, logout } = useAuth();

  return (
    <header style={{
      background: '#ffffff',
      borderBottom: '1px solid #e2e8f0',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      boxShadow: '0 1px 3px rgba(0,0,0,0.03)'
    }}>
      <div style={{
        maxWidth: '1280px',
        margin: '0 auto',
        padding: '0.85rem 1.5rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '1rem'
      }}>
        {/* Logo and Brand */}
        <div 
          onClick={() => setActivePage(isAdmin ? 'admin-dashboard' : 'home')}
          style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', cursor: 'pointer' }}
        >
          <div style={{
            background: 'linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%)',
            color: '#ffffff',
            width: '38px',
            height: '38px',
            borderRadius: '10px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: '0 4px 8px rgba(37, 99, 235, 0.25)'
          }}>
            <Wrench size={20} />
          </div>
          <div>
            <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#0f172a', letterSpacing: '-0.02em', lineHeight: 1.1 }}>
              AutoCare <span style={{ color: '#2563eb' }}>Pro</span>
            </div>
            <div style={{ fontSize: '0.7rem', color: '#64748b', fontWeight: 600 }}>
              Automotive Service & Payment Hub
            </div>
          </div>
        </div>

        {/* Navigation Links */}
        <nav style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', flexWrap: 'wrap' }}>
          {!isAuthenticated ? (
            <>
              <button
                onClick={() => setActivePage('home')}
                className={`btn btn-sm ${activePage === 'home' ? 'btn-primary' : 'btn-secondary'}`}
              >
                Home
              </button>
              <button
                onClick={() => setActivePage('services')}
                className={`btn btn-sm ${activePage === 'services' ? 'btn-primary' : 'btn-secondary'}`}
              >
                Services & Pricing
              </button>
              <button
                onClick={() => setActivePage('login')}
                className="btn btn-sm btn-outline"
                style={{ marginLeft: '0.5rem' }}
              >
                <LogIn size={15} />
                <span>Sign In</span>
              </button>
              <button
                onClick={() => setActivePage('register')}
                className="btn btn-sm btn-primary"
              >
                Get Started
              </button>
            </>
          ) : isAdmin ? (
            /* Admin Navigation */
            <>
              <button
                onClick={() => setActivePage('admin-dashboard')}
                className={`btn btn-sm ${activePage === 'admin-dashboard' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <LayoutDashboard size={15} />
                <span>Overview</span>
              </button>
              <button
                onClick={() => setActivePage('admin-bookings')}
                className={`btn btn-sm ${activePage === 'admin-bookings' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <Calendar size={15} />
                <span>Bookings</span>
              </button>
              <button
                onClick={() => setActivePage('admin-jobs')}
                className={`btn btn-sm ${activePage === 'admin-jobs' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <Wrench size={15} />
                <span>Workshop Jobs</span>
              </button>
              <button
                onClick={() => setActivePage('admin-invoices')}
                className={`btn btn-sm ${activePage === 'admin-invoices' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <CreditCard size={15} />
                <span>Billing</span>
              </button>
              <button
                onClick={() => setActivePage('admin-search')}
                className={`btn btn-sm ${activePage === 'admin-search' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <History size={15} />
                <span>Vehicle Search</span>
              </button>
            </>
          ) : (
            /* Customer Navigation */
            <>
              <button
                onClick={() => setActivePage('customer-dashboard')}
                className={`btn btn-sm ${activePage === 'customer-dashboard' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <LayoutDashboard size={15} />
                <span>Dashboard</span>
              </button>
              <button
                onClick={() => setActivePage('book-service')}
                className={`btn btn-sm ${activePage === 'book-service' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <Calendar size={15} />
                <span>Book Service</span>
              </button>
              <button
                onClick={() => setActivePage('my-vehicles')}
                className={`btn btn-sm ${activePage === 'my-vehicles' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <Car size={15} />
                <span>My Vehicles</span>
              </button>
              <button
                onClick={() => setActivePage('my-bookings')}
                className={`btn btn-sm ${activePage === 'my-bookings' ? 'btn-primary' : 'btn-secondary'}`}
              >
                <CheckSquare size={15} />
                <span>Track Jobs</span>
              </button>
            </>
          )}

          {/* User info & Logout */}
          {isAuthenticated && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginLeft: '0.75rem', paddingLeft: '0.75rem', borderLeft: '1px solid #e2e8f0' }}>
              <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: '0.85rem', fontWeight: 700, color: '#1e293b' }}>
                  {user.full_name}
                </span>
                <span style={{
                  fontSize: '0.7rem',
                  fontWeight: 700,
                  color: isAdmin ? '#b45309' : '#2563eb',
                  textTransform: 'uppercase'
                }}>
                  {isAdmin ? 'Admin / Staff' : 'Customer'}
                </span>
              </div>
              <button
                onClick={() => {
                  logout();
                  setActivePage('home');
                }}
                className="btn btn-sm btn-secondary"
                title="Log Out"
                style={{ color: '#ef4444' }}
              >
                <LogOut size={16} />
              </button>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
}
