import React, { useState, useEffect } from 'react';
import { X, Wrench, Calendar, CheckCircle2, History, Car } from 'lucide-react';
import { api } from '../api';
import StatusBadge from './StatusBadge';

export default function VehicleHistoryModal({ vehicleId, onClose }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchHistory() {
      try {
        setLoading(true);
        const res = await api.getVehicleHistory(vehicleId);
        if (res.success) {
          setData(res);
        }
      } catch (err) {
        setError(err.message || 'Failed to load vehicle history');
      } finally {
        setLoading(false);
      }
    }
    if (vehicleId) {
      fetchHistory();
    }
  }, [vehicleId]);

  if (!vehicleId) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content" style={{ maxWidth: '750px', padding: '2rem' }}>
        <button
          onClick={onClose}
          style={{
            position: 'absolute',
            top: '1.25rem',
            right: '1.25rem',
            background: '#f1f5f9',
            border: 'none',
            borderRadius: '50%',
            width: '34px',
            height: '34px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            color: '#64748b'
          }}
        >
          <X size={18} />
        </button>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '1.5rem' }}>
          <div style={{ background: '#eff6ff', color: '#2563eb', padding: '0.75rem', borderRadius: '12px' }}>
            <History size={26} />
          </div>
          <div>
            <h3 style={{ fontSize: '1.3rem', fontWeight: 800, color: '#0f172a' }}>
              Vehicle Service History Log
            </h3>
            <p style={{ fontSize: '0.85rem', color: '#64748b' }}>
              Complete chronological maintenance log stored in database
            </p>
          </div>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: '2.5rem 0', color: '#64748b' }}>
            Retrieving vehicle service timeline...
          </div>
        ) : error ? (
          <div style={{ color: '#ef4444', textAlign: 'center', padding: '2rem 0' }}>{error}</div>
        ) : data ? (
          <div>
            {/* Vehicle Card Header */}
            <div style={{
              background: '#f8fafc',
              border: '1px solid #e2e8f0',
              borderRadius: '12px',
              padding: '1.25rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '1.5rem'
            }}>
              <div>
                <h4 style={{ fontSize: '1.1rem', fontWeight: 800, color: '#0f172a' }}>
                  {data.vehicle.make} {data.vehicle.model}
                </h4>
                <div style={{ fontSize: '0.85rem', color: '#64748b', marginTop: '0.2rem' }}>
                  Registration: <span style={{ fontWeight: 700, color: '#1e293b' }}>{data.vehicle.reg_number}</span>
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span className="badge badge-confirmed" style={{ fontSize: '0.8rem', padding: '0.35rem 0.75rem' }}>
                  {data.history.length} Past Service(s)
                </span>
              </div>
            </div>

            {data.history.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '2rem', color: '#64748b', background: '#f8fafc', borderRadius: '12px' }}>
                No past service records recorded for this vehicle yet.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                {data.history.map((record, index) => (
                  <div
                    key={index}
                    style={{
                      border: '1px solid #e2e8f0',
                      borderRadius: '12px',
                      padding: '1.25rem',
                      background: '#ffffff',
                      boxShadow: '0 1px 3px rgba(0,0,0,0.02)'
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                      <div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
                          <h5 style={{ fontSize: '1.05rem', fontWeight: 700, color: '#0f172a' }}>
                            {record.service_name}
                          </h5>
                          <span style={{ fontSize: '0.75rem', background: '#f1f5f9', color: '#475569', padding: '0.2rem 0.5rem', borderRadius: '4px', fontWeight: 600 }}>
                            {record.service_category}
                          </span>
                        </div>
                        <div style={{ fontSize: '0.825rem', color: '#64748b', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                          <Calendar size={14} />
                          <span>Date: {record.booking_date} | Ref: {record.booking_reference}</span>
                        </div>
                      </div>

                      <div style={{ textAlign: 'right' }}>
                        <StatusBadge status={record.booking_status} />
                        {record.total_amount && (
                          <div style={{ fontWeight: 800, color: '#2563eb', fontSize: '0.95rem', marginTop: '0.35rem' }}>
                            ₹{Number(record.total_amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </div>
                        )}
                      </div>
                    </div>

                    {record.work_summary && (
                      <div style={{
                        background: '#f8fafc',
                        padding: '0.75rem 1rem',
                        borderRadius: '8px',
                        fontSize: '0.85rem',
                        color: '#334155',
                        marginTop: '0.5rem'
                      }}>
                        <strong>Workshop Findings & Work Performed:</strong> {record.work_summary}
                        {record.technician_name && (
                          <div style={{ fontSize: '0.75rem', color: '#64748b', marginTop: '0.3rem' }}>
                            Serviced by: {record.technician_name}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
}
