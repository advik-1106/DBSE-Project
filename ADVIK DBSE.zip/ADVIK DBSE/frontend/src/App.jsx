import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Pages
import HomePage from './pages/HomePage';
import ServicesPage from './pages/ServicesPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import CustomerDashboard from './pages/CustomerDashboard';
import BookServicePage from './pages/BookServicePage';
import MyVehiclesPage from './pages/MyVehiclesPage';
import MyBookingsPage from './pages/MyBookingsPage';
import AdminDashboard from './pages/AdminDashboard';
import AdminBookingsPage from './pages/AdminBookingsPage';
import AdminJobCardsPage from './pages/AdminJobCardsPage';
import AdminInvoicesPage from './pages/AdminInvoicesPage';
import AdminVehicleSearchPage from './pages/AdminVehicleSearchPage';

function AppContent() {
  const { user, isAuthenticated, isAdmin, loading } = useAuth();
  const [activePage, setActivePage] = useState('home');

  // Shared selection context
  const [selectedServiceId, setSelectedServiceId] = useState(null);
  const [selectedVehicleId, setSelectedVehicleId] = useState(null);
  const [selectedBookingId, setSelectedBookingId] = useState(null);
  const [selectedJobId, setSelectedJobId] = useState(null);

  // If user logs in, set default dashboard if currently on login/register/home
  useEffect(() => {
    if (isAuthenticated) {
      if (['login', 'register', 'home'].includes(activePage)) {
        setActivePage(isAdmin ? 'admin-dashboard' : 'customer-dashboard');
      }
    }
  }, [isAuthenticated, isAdmin]);

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#64748b'
      }}>
        Initializing AutoCare Pro System...
      </div>
    );
  }

  return (
    <div className="app-container">
      <Navbar activePage={activePage} setActivePage={setActivePage} />

      <main className="main-content">
        {activePage === 'home' && (
          <HomePage setActivePage={setActivePage} />
        )}

        {activePage === 'services' && (
          <ServicesPage 
            setActivePage={setActivePage} 
            setSelectedServiceId={setSelectedServiceId} 
          />
        )}

        {activePage === 'login' && (
          <LoginPage setActivePage={setActivePage} />
        )}

        {activePage === 'register' && (
          <RegisterPage setActivePage={setActivePage} />
        )}

        {/* Customer Protected Pages */}
        {activePage === 'customer-dashboard' && (
          <CustomerDashboard 
            setActivePage={setActivePage} 
            setSelectedBookingId={setSelectedBookingId} 
          />
        )}

        {activePage === 'book-service' && (
          <BookServicePage 
            setActivePage={setActivePage}
            preSelectedVehicleId={selectedVehicleId}
            preSelectedServiceId={selectedServiceId}
            setSelectedBookingId={setSelectedBookingId}
          />
        )}

        {activePage === 'my-vehicles' && (
          <MyVehiclesPage 
            setActivePage={setActivePage} 
            setSelectedVehicleId={setSelectedVehicleId} 
          />
        )}

        {activePage === 'my-bookings' && (
          <MyBookingsPage 
            setActivePage={setActivePage} 
            selectedBookingId={selectedBookingId} 
          />
        )}

        {/* Admin Protected Pages */}
        {activePage === 'admin-dashboard' && (
          <AdminDashboard 
            setActivePage={setActivePage} 
            setSelectedJobId={setSelectedJobId} 
          />
        )}

        {activePage === 'admin-bookings' && (
          <AdminBookingsPage 
            setActivePage={setActivePage} 
            setSelectedJobId={setSelectedJobId} 
          />
        )}

        {activePage === 'admin-jobs' && (
          <AdminJobCardsPage />
        )}

        {activePage === 'admin-invoices' && (
          <AdminInvoicesPage />
        )}

        {activePage === 'admin-search' && (
          <AdminVehicleSearchPage />
        )}
      </main>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
