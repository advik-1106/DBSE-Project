const API_BASE_URL = '/api';

export function getAuthToken() {
  return localStorage.getItem('autocare_token');
}

export function setAuthToken(token) {
  if (token) {
    localStorage.setItem('autocare_token', token);
  } else {
    localStorage.removeItem('autocare_token');
  }
}

export function getCurrentUser() {
  const user = localStorage.getItem('autocare_user');
  return user ? JSON.parse(user) : null;
}

export function setCurrentUser(user) {
  if (user) {
    localStorage.setItem('autocare_user', JSON.stringify(user));
  } else {
    localStorage.removeItem('autocare_user');
  }
}

async function request(endpoint, options = {}) {
  const token = getAuthToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: 'Bearer ' + token } : {}),
    ...options.headers
  };

  const response = await fetch(API_BASE_URL + endpoint, {
    ...options,
    headers
  });

  const text = await response.text();
  let data = {};

  if (text) {
    try {
      data = JSON.parse(text);
    } catch (err) {
      console.error('Invalid JSON from ' + endpoint + ':', text);
      data = { message: 'Server returned an invalid response.' };
    }
  }

  if (!response.ok) {
    const errorMsg = data.message || data.error || ('Request failed with status ' + response.status);
    throw new Error(errorMsg);
  }

  return data;
}

export const api = {
  login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
  register: (userData) => request('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
  getProfile: () => request('/auth/profile'),
  getUsers: () => request('/auth/users'),
  getServices: (params = '') => request('/services' + (params ? '?'+params : '')),
  getServiceById: (id) => request('/services/' + id),
  createService: (data) => request('/services', { method: 'POST', body: JSON.stringify(data) }),
  updateService: (id, data) => request('/services/' + id, { method: 'PUT', body: JSON.stringify(data) }),
  getMyVehicles: () => request('/vehicles/my-vehicles'),
  getAllVehicles: () => request('/vehicles/all'),
  addVehicle: (data) => request('/vehicles', { method: 'POST', body: JSON.stringify(data) }),
  getVehicleById: (id) => request('/vehicles/' + id),
  getVehicleHistory: (id) => request('/vehicles/' + id + '/history'),
  deleteVehicle: (id) => request('/vehicles/' + id, { method: 'DELETE' }),
  createBooking: (data) => request('/bookings', { method: 'POST', body: JSON.stringify(data) }),
  getMyBookings: () => request('/bookings/my-bookings'),
  getAllBookings: (params = '') => request('/bookings/all' + (params ? '?'+params : '')),
  getBookingDetails: (id) => request('/bookings/' + id),
  updateBookingStatus: (id, data) => request('/bookings/' + id + '/status', { method: 'PUT', body: JSON.stringify(data) }),
  cancelBooking: (id) => request('/bookings/' + id + '/cancel', { method: 'PUT' }),
  getAllJobCards: (params = '') => request('/jobs' + (params ? '?'+params : '')),
  getJobCardById: (id) => request('/jobs/' + id),
  updateJobCard: (id, data) => request('/jobs/' + id, { method: 'PUT', body: JSON.stringify(data) }),
  addJobItem: (jobCardId, itemData) => request('/jobs/' + jobCardId + '/items', { method: 'POST', body: JSON.stringify(itemData) }),
  deleteJobItem: (itemId) => request('/jobs/items/' + itemId, { method: 'DELETE' }),
  getMyInvoices: () => request('/billing/my-invoices'),
  getAllInvoices: (params = '') => request('/billing/all-invoices' + (params ? '?'+params : '')),
  getInvoiceDetails: (id) => request('/billing/invoice/' + id),
  processPayment: (paymentData) => request('/billing/pay', { method: 'POST', body: JSON.stringify(paymentData) }),
  getAdminStats: () => request('/dashboard/admin-stats'),
  searchVehicleHistory: (regNumber) => request('/dashboard/vehicle-history/' + encodeURIComponent(regNumber))
};
