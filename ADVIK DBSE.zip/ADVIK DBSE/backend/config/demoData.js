const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/authMiddleware');

const demoUsers = [
  {
    id: 1,
    full_name: 'Service Center Admin',
    email: 'admin@autocare.com',
    phone: '+91 9876543210',
    role: 'admin',
    address: 'AutoCare Service Hub, KLH Tech Park, Hyderabad',
    created_at: '2026-01-01T00:00:00.000Z'
  },
  {
    id: 2,
    full_name: 'T. Advik',
    email: 'advik@example.com',
    phone: '+91 9848012345',
    role: 'customer',
    address: 'Hitech City, Hyderabad, Telangana',
    created_at: '2026-01-02T00:00:00.000Z'
  },
  {
    id: 3,
    full_name: 'M. Manasa',
    email: 'manasa@example.com',
    phone: '+91 9988776655',
    role: 'customer',
    address: 'Gachibowli, Hyderabad, Telangana',
    created_at: '2026-01-03T00:00:00.000Z'
  }
];

const demoServices = [
  { id: 1, service_code: 'SVC-GEN-01', name: 'General Periodic Service', category: 'Periodic Maintenance', description: 'Engine oil flush & replacement, oil filter change, air filter cleaning, 50-point full vehicle safety inspection & fluid top-ups.', estimated_duration_hours: 3.0, base_price: 3499.00, is_active: true },
  { id: 2, service_code: 'SVC-OIL-02', name: 'Synthetic Oil & Filter Service', category: 'Periodic Maintenance', description: '100% Synthetic 5W-30 engine oil change, genuine OEM oil filter replacement, chassis lubrication & computer diagnostics.', estimated_duration_hours: 1.5, base_price: 2199.00, is_active: true },
  { id: 3, service_code: 'SVC-BRK-03', name: 'Complete Brake System Overhaul', category: 'Tyres & Brakes', description: 'Front & rear brake pad replacement, rotor skimming/polishing, brake fluid bleeding, ABS sensor calibration & caliper greasing.', estimated_duration_hours: 2.5, base_price: 2899.00, is_active: true },
  { id: 4, service_code: 'SVC-AC-04', name: 'HVAC & Climate Control Service', category: 'Electrical & AC', description: 'AC gas recharging (R134a/R1234yf), evaporator coil cleaning, cabin pollen filter replacement, cooling performance benchmark test.', estimated_duration_hours: 2.0, base_price: 2499.00, is_active: true },
  { id: 5, service_code: 'SVC-WHL-05', name: 'Wheel Alignment & 3D Balancing', category: 'Tyres & Brakes', description: 'Laser computer wheel alignment, 4-wheel dynamic balancing, tyre rotation and nitrogen tire inflation.', estimated_duration_hours: 1.0, base_price: 1199.00, is_active: true }
];

const demoVehicles = [
  { id: 1, user_id: 2, reg_number: 'TS 09 EQ 4038', make: 'Honda', model: 'City ZX i-VTEC', year: 2022, fuel_type: 'Petrol', mileage_km: 24500, vin_number: 'MAKGM2650N400129', created_at: '2026-01-10T00:00:00.000Z' },
  { id: 2, user_id: 2, reg_number: 'TS 07 HK 9623', make: 'Hyundai', model: 'Creta SX(O)', year: 2023, fuel_type: 'Diesel', mileage_km: 18200, vin_number: 'MALC381CLPM10928', created_at: '2026-02-05T00:00:00.000Z' },
  { id: 3, user_id: 3, reg_number: 'TS 08 FA 1102', make: 'Tata', model: 'Nexon EV Empowered', year: 2024, fuel_type: 'Electric', mileage_km: 11300, vin_number: 'MAT621422R901923', created_at: '2026-02-11T00:00:00.000Z' }
];

const demoBookings = [
  {
    id: 1,
    booking_reference: 'BK-2026-001',
    user_id: 2,
    vehicle_id: 1,
    service_id: 1,
    booking_date: '2026-10-01',
    time_slot: '09:00 AM - 11:00 AM',
    customer_notes: 'Periodic 25,000 km general service. Slight noise from front suspension during bumps.',
    status: 'COMPLETED',
    created_at: '2026-10-01T00:00:00.000Z',
    updated_at: '2026-10-01T00:00:00.000Z',
    invoice_id: 1,
    invoice_number: 'INV-2026-9001',
    total_amount: 7963.82,
    payment_status: 'PAID',
    service_name: 'General Periodic Service',
    service_base_price: 3499.00,
    vehicle_reg_number: 'TS 09 EQ 4038',
    technician_name: 'Vikram Sharma'
  },
  {
    id: 2,
    booking_reference: 'BK-2026-002',
    user_id: 2,
    vehicle_id: 2,
    service_id: 4,
    booking_date: '2026-10-03',
    time_slot: '11:00 AM - 01:00 PM',
    customer_notes: 'AC cooling is insufficient during afternoon driving.',
    status: 'IN_PROGRESS',
    created_at: '2026-10-03T00:00:00.000Z',
    updated_at: '2026-10-03T00:00:00.000Z',
    invoice_id: 2,
    invoice_number: 'INV-2026-9002',
    total_amount: 4282.22,
    payment_status: 'UNPAID',
    service_name: 'HVAC & Climate Control Service',
    service_base_price: 2499.00,
    vehicle_reg_number: 'TS 07 HK 9623',
    technician_name: 'Vikram Sharma'
  },
  {
    id: 3,
    booking_reference: 'BK-2026-003',
    user_id: 3,
    vehicle_id: 3,
    service_id: 5,
    booking_date: '2026-10-04',
    time_slot: '02:00 PM - 04:00 PM',
    customer_notes: 'Steering vibrates at speeds over 80 km/h. Please balance all 4 wheels.',
    status: 'CONFIRMED',
    created_at: '2026-10-04T00:00:00.000Z',
    updated_at: '2026-10-04T00:00:00.000Z',
    invoice_id: 3,
    invoice_number: 'INV-2026-9003',
    total_amount: 1450.00,
    payment_status: 'UNPAID',
    service_name: 'Wheel Alignment & 3D Balancing',
    service_base_price: 1199.00,
    vehicle_reg_number: 'TS 08 FA 1102',
    technician_name: 'Vikram Sharma'
  }
];

const demoInvoices = [
  { id: 1, invoice_number: 'INV-2026-9001', booking_id: 1, job_card_id: 1, service_base_amount: 3499.00, additional_parts_labor: 3550.00, discount_amount: 300.00, tax_amount: 1214.82, total_amount: 7963.82, payment_status: 'PAID', paid_at: '2026-10-01T13:30:00.000Z', booking_reference: 'BK-2026-001' },
  { id: 2, invoice_number: 'INV-2026-9002', booking_id: 2, job_card_id: 2, service_base_amount: 2499.00, additional_parts_labor: 1130.00, discount_amount: 0.00, tax_amount: 653.22, total_amount: 4282.22, payment_status: 'UNPAID', paid_at: null, booking_reference: 'BK-2026-002' },
  { id: 3, invoice_number: 'INV-2026-9003', booking_id: 3, job_card_id: 3, service_base_amount: 1199.00, additional_parts_labor: 0.00, discount_amount: 0.00, tax_amount: 251.00, total_amount: 1450.00, payment_status: 'UNPAID', paid_at: null, booking_reference: 'BK-2026-003' }
];

const demoStats = {
  total_bookings: 3,
  active_jobs: 2,
  completed_jobs: 1,
  pending_payments: 2,
  total_revenue: 12246.04,
  today_bookings: 2
};

function getDemoUserByEmail(email) {
  return demoUsers.find((user) => user.email.toLowerCase() === String(email || '').trim().toLowerCase()) || null;
}

function createDemoToken(user) {
  return jwt.sign({
    id: user.id,
    email: user.email,
    role: user.role,
    full_name: user.full_name
  }, JWT_SECRET, { expiresIn: '7d' });
}

function getUserFromToken(req) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return null;
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return demoUsers.find((user) => user.id === decoded.id) || null;
  } catch (error) {
    return null;
  }
}

function normalizeDemoUser(user) {
  return {
    id: user.id,
    full_name: user.full_name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    address: user.address
  };
}

function handleDemoRequest(req, res, next) {
  const path = req.path || '/';
  const method = req.method.toUpperCase();

  if (path === '/api/health') {
    return next();
  }

  if (req.path === '/api/auth/login' && method === 'POST') {
    const { email, password } = req.body || {};
    const user = getDemoUserByEmail(email);
    const validPasswordByUser = {
      'admin@autocare.com': 'admin123',
      'advik@example.com': 'password123',
      'manasa@example.com': 'password123'
    };

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    if ((validPasswordByUser[user.email] || '') !== String(password || '')) {
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }

    const token = createDemoToken(user);
    return res.json({
      success: true,
      message: 'Login successful',
      token,
      user: normalizeDemoUser(user)
    });
  }

  if (req.path === '/api/auth/register' && method === 'POST') {
    const { full_name, email, password, phone, role, address } = req.body || {};
    if (!full_name || !email || !password || !phone) {
      return res.status(400).json({ success: false, message: 'Please provide full name, email, password, and phone number.' });
    }

    const existing = getDemoUserByEmail(email);
    if (existing) {
      return res.status(409).json({ success: false, message: 'An account with this email address already exists.' });
    }

    const newUser = {
      id: demoUsers.length + 1,
      full_name: String(full_name).trim(),
      email: String(email).trim().toLowerCase(),
      phone: String(phone).trim(),
      role: ['customer', 'admin', 'technician'].includes(role) ? role : 'customer',
      address: address || '',
      created_at: new Date().toISOString()
    };

    demoUsers.push(newUser);
    const token = createDemoToken(newUser);

    return res.status(201).json({
      success: true,
      message: 'Account registered successfully',
      token,
      user: normalizeDemoUser(newUser)
    });
  }

  if (req.path === '/api/auth/profile' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user) {
      return res.status(401).json({ success: false, message: 'Access denied. No authentication token provided.' });
    }
    return res.json({ success: true, user: normalizeDemoUser(user) });
  }

  if (req.path === '/api/auth/users' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Forbidden: requires one of the following roles: [admin]' });
    }
    return res.json({ success: true, users: demoUsers.map(normalizeDemoUser) });
  }

  if (req.path === '/api/services' && method === 'GET') {
    return res.json({ success: true, services: demoServices });
  }

  if (req.path.startsWith('/api/services/') && method === 'GET') {
    const serviceId = Number(req.path.split('/').pop());
    const found = demoServices.find((item) => item.id === serviceId);
    if (!found) return res.status(404).json({ success: false, message: 'Service not found.' });
    return res.json({ success: true, service: found });
  }

  if (req.path === '/api/vehicles/my-vehicles' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user) return res.status(401).json({ success: false, message: 'Access denied. No authentication token provided.' });
    const vehicles = demoVehicles.filter((vehicle) => vehicle.user_id === user.id);
    return res.json({ success: true, vehicles });
  }

  if (req.path === '/api/vehicles/all' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ success: false, message: 'Forbidden: requires one of the following roles: [admin]' });
    return res.json({ success: true, vehicles: demoVehicles });
  }

  if (req.path.startsWith('/api/vehicles/') && req.path.endsWith('/history') && method === 'GET') {
    const vehicleId = Number(req.path.split('/')[2]);
    const vehicle = demoVehicles.find((item) => item.id === vehicleId);
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    return res.json({ success: true, vehicle, history: demoBookings.filter((booking) => booking.vehicle_id === vehicleId) });
  }

  if (req.path.startsWith('/api/vehicles/') && method === 'GET') {
    const vehicleId = Number(req.path.split('/').pop());
    const vehicle = demoVehicles.find((item) => item.id === vehicleId);
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    return res.json({ success: true, vehicle });
  }

  if (req.path === '/api/bookings/my-bookings' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user) return res.status(401).json({ success: false, message: 'Access denied. No authentication token provided.' });
    return res.json({ success: true, bookings: demoBookings.filter((booking) => booking.user_id === user.id) });
  }

  if (req.path === '/api/bookings/all' && method === 'GET') {
    return res.json({ success: true, bookings: demoBookings });
  }

  if (req.path.startsWith('/api/bookings/') && req.path.endsWith('/status') && method === 'PUT') {
    return res.json({ success: true, message: 'Booking status updated successfully.', booking: demoBookings[0] });
  }

  if (req.path.startsWith('/api/bookings/') && req.path.endsWith('/cancel') && method === 'PUT') {
    return res.json({ success: true, message: 'Booking cancelled successfully.' });
  }

  if (req.path.startsWith('/api/bookings/') && method === 'GET') {
    const bookingId = Number(req.path.split('/').pop());
    const booking = demoBookings.find((item) => item.id === bookingId);
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found.' });
    return res.json({ success: true, booking });
  }

  if (req.path === '/api/jobs' && method === 'GET') {
    const jobs = [
      { id: 1, job_number: 'JOB-2026-101', booking_id: 1, technician_name: 'Vikram Sharma', bay_number: 'Bay-3', status: 'COMPLETED', job_items: [], booking_reference: 'BK-2026-001' },
      { id: 2, job_number: 'JOB-2026-102', booking_id: 2, technician_name: 'Vikram Sharma', bay_number: 'Bay-1', status: 'SERVICE_IN_PROGRESS', job_items: [], booking_reference: 'BK-2026-002' }
    ];
    return res.json({ success: true, jobs });
  }

  if (req.path.startsWith('/api/jobs/') && method === 'GET') {
    const jobId = Number(req.path.split('/').pop());
    const job = { id: jobId, job_number: 'JOB-2026-101', booking_id: 1, technician_name: 'Vikram Sharma', bay_number: 'Bay-3', status: 'COMPLETED', job_items: [], booking_reference: 'BK-2026-001' };
    return res.json({ success: true, job });
  }

  if (req.path === '/api/billing/my-invoices' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user) return res.status(401).json({ success: false, message: 'Access denied. No authentication token provided.' });
    return res.json({ success: true, invoices: demoInvoices.filter((invoice) => demoBookings.some((booking) => booking.id === invoice.booking_id && booking.user_id === user.id)) });
  }

  if (req.path === '/api/billing/all-invoices' && method === 'GET') {
    return res.json({ success: true, invoices: demoInvoices });
  }

  if (req.path.startsWith('/api/billing/invoice/') && method === 'GET') {
    const invoiceId = Number(req.path.split('/').pop());
    const invoice = demoInvoices.find((item) => item.id === invoiceId);
    if (!invoice) return res.status(404).json({ success: false, message: 'Invoice not found.' });
    return res.json({ success: true, invoice });
  }

  if (req.path === '/api/billing/pay' && method === 'POST') {
    return res.json({ success: true, message: 'Payment processed successfully', payment: { status: 'SUCCESS' } });
  }

  if (req.path === '/api/dashboard/admin-stats' && method === 'GET') {
    const user = getUserFromToken(req);
    if (!user || user.role !== 'admin') return res.status(403).json({ success: false, message: 'Forbidden: requires one of the following roles: [admin]' });
    return res.json({ success: true, stats: demoStats });
  }

  if (req.path.startsWith('/api/dashboard/vehicle-history/') && method === 'GET') {
    const regNumber = decodeURIComponent(req.path.split('/').pop() || '');
    const vehicle = demoVehicles.find((item) => item.reg_number.toLowerCase() === regNumber.toLowerCase());
    if (!vehicle) return res.status(404).json({ success: false, message: 'Vehicle history not found.' });
    return res.json({ success: true, vehicle, history: demoBookings.filter((booking) => booking.vehicle_id === vehicle.id) });
  }

  return res.status(404).json({ success: false, message: 'Endpoint unavailable in demo mode.' });
}

module.exports = {
  demoUsers,
  demoServices,
  demoVehicles,
  demoBookings,
  demoInvoices,
  demoStats,
  handleDemoRequest,
  createDemoToken,
  getUserFromToken,
  normalizeDemoUser,
  getDemoUserByEmail,
  demoMode: true
};
