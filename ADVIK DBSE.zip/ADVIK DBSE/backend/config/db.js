const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.resolve(__dirname, '..', '.env') });

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'automotive_service_db',
  port: Number(process.env.DB_PORT) || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 10000,
  dateStrings: true
};

let pool;
try {
  pool = mysql.createPool(dbConfig);
} catch (error) {
  console.error('[DB] Failed to initialize MySQL pool:', error.message);
  pool = null;
}

const ensureDatabase = async () => {
  if (!pool) {
    return false;
  }

  try {
    const connection = await pool.getConnection();
    connection.release();
    return true;
  } catch (error) {
    return false;
  }
};

const fallbackPool = {
  async query() {
    throw new Error('MySQL database is unavailable. Please update backend/.env with the correct DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, and DB_PORT values, then restart the backend.');
  },
  async getConnection() {
    throw new Error('MySQL database is unavailable. Please update backend/.env with the correct DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, and DB_PORT values, then restart the backend.');
  },
  async end() {
    return true;
  }
};

module.exports = pool || fallbackPool;
module.exports.isDatabaseAvailable = ensureDatabase;
module.exports.dbConfig = dbConfig;
