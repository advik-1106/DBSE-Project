const express = require('express');
const router = express.Router();
const jobController = require('../controllers/jobController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

router.get('/', authenticateToken, requireRole('admin', 'technician'), jobController.getAllJobCards);
router.get('/:id', authenticateToken, jobController.getJobCardById);
router.put('/:id', authenticateToken, requireRole('admin', 'technician'), jobController.updateJobCard);
router.post('/:id/items', authenticateToken, requireRole('admin', 'technician'), jobController.addJobItem);
router.delete('/items/:itemId', authenticateToken, requireRole('admin', 'technician'), jobController.deleteJobItem);

module.exports = router;
