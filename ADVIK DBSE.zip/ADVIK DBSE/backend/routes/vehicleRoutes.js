const express = require('express');
const router = express.Router();
const vehicleController = require('../controllers/vehicleController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

router.get('/my-vehicles', authenticateToken, vehicleController.getMyVehicles);
router.get('/all', authenticateToken, requireRole('admin'), vehicleController.getAllVehicles);
router.post('/', authenticateToken, vehicleController.addVehicle);
router.get('/:id', authenticateToken, vehicleController.getVehicleById);
router.get('/:id/history', authenticateToken, vehicleController.getVehicleServiceHistory);
router.delete('/:id', authenticateToken, vehicleController.deleteVehicle);

module.exports = router;
