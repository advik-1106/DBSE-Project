const express = require('express');
const router = express.Router();
const bookingController = require('../controllers/bookingController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

router.post('/', authenticateToken, bookingController.createBooking);
router.get('/my-bookings', authenticateToken, bookingController.getMyBookings);
router.get('/all', authenticateToken, requireRole('admin', 'technician'), bookingController.getAllBookings);
router.get('/:id', authenticateToken, bookingController.getBookingDetails);
router.put('/:id/status', authenticateToken, requireRole('admin', 'technician'), bookingController.updateBookingStatus);
router.put('/:id/cancel', authenticateToken, bookingController.cancelBooking);

module.exports = router;
