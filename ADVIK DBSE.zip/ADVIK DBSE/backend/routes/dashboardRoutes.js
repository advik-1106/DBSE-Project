const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

router.get('/admin-stats', authenticateToken, requireRole('admin'), dashboardController.getAdminDashboardStats);
router.get('/vehicle-history/:regNumber', authenticateToken, dashboardController.searchVehicleHistoryByReg);

module.exports = router;
