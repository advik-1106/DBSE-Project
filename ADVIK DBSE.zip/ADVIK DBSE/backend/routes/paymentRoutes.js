const express = require('express');
const router = express.Router();
const paymentController = require('../controllers/paymentController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

router.get('/my-invoices', authenticateToken, paymentController.getMyInvoices);
router.get('/all-invoices', authenticateToken, requireRole('admin'), paymentController.getAllInvoices);
router.get('/invoice/:id', authenticateToken, paymentController.getInvoiceDetails);
router.post('/pay', authenticateToken, paymentController.processPayment);

module.exports = router;
