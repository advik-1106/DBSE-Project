const express = require('express');
const router = express.Router();
const serviceController = require('../controllers/serviceController');
const { authenticateToken, requireRole } = require('../middleware/authMiddleware');

// Public listing
router.get('/', serviceController.getAllServices);
router.get('/:id', serviceController.getServiceById);

// Admin service catalog management
router.post('/', authenticateToken, requireRole('admin'), serviceController.createService);
router.put('/:id', authenticateToken, requireRole('admin'), serviceController.updateService);

module.exports = router;
