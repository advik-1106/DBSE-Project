const pool = require('../config/db');

exports.getInvoiceDetails = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `SELECT 
        inv.*,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status as booking_status,
        u.id as customer_id,
        u.full_name as customer_name,
        u.email as customer_email,
        u.phone as customer_phone,
        u.address as customer_address,
        v.reg_number,
        v.make,
        v.model,
        v.year,
        s.name as service_name,
        s.category as service_category,
        j.job_number,
        j.technician_name
       FROM invoices inv
       JOIN service_bookings b ON inv.booking_id = b.id
       JOIN users u ON b.user_id = u.id
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       LEFT JOIN job_cards j ON b.id = j.booking_id
       WHERE inv.id = ? OR inv.invoice_number = ? OR b.id = ?`,
      [id, id, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Invoice not found.' });
    }

    const invoice = rows[0];

    // Authorization
    if (req.user.role !== 'admin' && invoice.customer_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    // Get itemized parts & labor
    let items = [];
    if (invoice.job_card_id) {
      const [iRows] = await pool.query('SELECT * FROM job_items WHERE job_card_id = ?', [invoice.job_card_id]);
      items = iRows;
    }

    // Get payments recorded for this invoice
    const [payments] = await pool.query('SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC', [invoice.id]);

    res.json({
      success: true,
      invoice,
      items,
      payments
    });
  } catch (error) {
    console.error('[PaymentController.getInvoiceDetails] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.processPayment = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { invoice_id, payment_method, upi_id, card_number, card_holder } = req.body;

    if (!invoice_id || !payment_method) {
      return res.status(400).json({ success: false, message: 'Invoice ID and payment method are required.' });
    }

    const [invRows] = await connection.query(
      `SELECT inv.*, b.id as booking_id, b.status as booking_status, b.user_id
       FROM invoices inv
       JOIN service_bookings b ON inv.booking_id = b.id
       WHERE inv.id = ?`,
      [invoice_id]
    );

    if (invRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Invoice not found.' });
    }

    const invoice = invRows[0];

    if (req.user.role !== 'admin' && invoice.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    if (invoice.payment_status === 'PAID') {
      return res.status(400).json({ success: false, message: 'This invoice has already been paid.' });
    }

    await connection.beginTransaction();

    // Generate Payment Transaction Details (Simulating Payment Gateway like Razorpay / Stripe)
    const paymentRef = 'PAY-TXN-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    const txnId = 'GW-' + Date.now() + '-' + Math.floor(1000 + Math.random() * 9000);
    const gatewayResponse = JSON.stringify({
      gateway: 'Secure Automotive Payment Gateway',
      status: 'CAPTURED',
      method: payment_method,
      account_identifier: payment_method === 'UPI' ? upi_id : (card_number ? `**** **** **** ${card_number.slice(-4)}` : 'NET_BANKING'),
      currency: 'INR',
      timestamp: new Date().toISOString()
    });

    // 1. Insert Payment Record
    const [pResult] = await connection.query(
      `INSERT INTO payments (payment_reference, invoice_id, amount, payment_method, transaction_id, gateway_response, status)
       VALUES (?, ?, ?, ?, ?, ?, 'SUCCESS')`,
      [paymentRef, invoice.id, invoice.total_amount, payment_method, txnId, gatewayResponse]
    );

    // 2. Update Invoice to PAID
    await connection.query(
      `UPDATE invoices 
       SET payment_status = 'PAID', paid_at = NOW() 
       WHERE id = ?`,
      [invoice.id]
    );

    // 3. If booking was READY_FOR_DELIVERY, mark as COMPLETED
    if (invoice.booking_status === 'READY_FOR_DELIVERY') {
      await connection.query(
        'UPDATE service_bookings SET status = "COMPLETED" WHERE id = ?',
        [invoice.booking_id]
      );
      await connection.query(
        'UPDATE job_cards SET status = "COMPLETED", completed_at = NOW() WHERE booking_id = ?',
        [invoice.booking_id]
      );
    }

    // 4. Audit Log
    await connection.query(
      `INSERT INTO service_status_logs (booking_id, previous_status, new_status, updated_by, remarks)
       VALUES (?, ?, ?, ?, ?)`,
      [
        invoice.booking_id,
        invoice.booking_status,
        invoice.booking_status === 'READY_FOR_DELIVERY' ? 'COMPLETED' : invoice.booking_status,
        req.user.full_name || 'Customer Payment',
        `Online payment of ₹${invoice.total_amount} received via ${payment_method} (Ref: ${paymentRef})`
      ]
    );

    await connection.commit();

    res.json({
      success: true,
      message: 'Payment completed successfully!',
      payment: {
        payment_reference: paymentRef,
        transaction_id: txnId,
        amount: invoice.total_amount,
        payment_method,
        payment_date: new Date(),
        status: 'SUCCESS'
      }
    });
  } catch (error) {
    await connection.rollback();
    console.error('[PaymentController.processPayment] error:', error);
    res.status(500).json({ success: false, message: 'Server error processing payment: ' + error.message });
  } finally {
    connection.release();
  }
};

exports.getMyInvoices = async (req, res) => {
  try {
    const userId = req.user.id;
    const [rows] = await pool.query(
      `SELECT 
        inv.*,
        b.booking_reference,
        b.booking_date,
        v.reg_number,
        v.make,
        v.model,
        s.name as service_name
       FROM invoices inv
       JOIN service_bookings b ON inv.booking_id = b.id
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       WHERE b.user_id = ?
       ORDER BY inv.created_at DESC`,
      [userId]
    );

    res.json({ success: true, invoices: rows });
  } catch (error) {
    console.error('[PaymentController.getMyInvoices] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getAllInvoices = async (req, res) => {
  try {
    const { status } = req.query;
    let query = `
      SELECT 
        inv.*,
        b.booking_reference,
        b.booking_date,
        u.full_name as customer_name,
        u.phone as customer_phone,
        v.reg_number,
        v.make,
        v.model,
        s.name as service_name
       FROM invoices inv
       JOIN service_bookings b ON inv.booking_id = b.id
       JOIN users u ON b.user_id = u.id
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       WHERE 1=1
    `;
    const params = [];

    if (status && status !== 'ALL') {
      query += ' AND inv.payment_status = ?';
      params.push(status);
    }

    query += ' ORDER BY inv.created_at DESC';

    const [rows] = await pool.query(query, params);

    // Summary statistics
    const [stats] = await pool.query(`
      SELECT 
        COUNT(*) as total_invoices,
        COALESCE(SUM(CASE WHEN payment_status = 'PAID' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COALESCE(SUM(CASE WHEN payment_status = 'UNPAID' THEN total_amount ELSE 0 END), 0) as pending_revenue,
        COUNT(CASE WHEN payment_status = 'PAID' THEN 1 END) as paid_count,
        COUNT(CASE WHEN payment_status = 'UNPAID' THEN 1 END) as unpaid_count
      FROM invoices
    `);

    res.json({
      success: true,
      invoices: rows,
      summary: stats[0]
    });
  } catch (error) {
    console.error('[PaymentController.getAllInvoices] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};
