const pool = require('../config/db');

exports.getAllServices = async (req, res) => {
  try {
    const { category, search } = req.query;
    let query = 'SELECT * FROM services WHERE 1=1';
    const params = [];

    // Customers only see active services unless admin requested all
    if (req.user?.role !== 'admin') {
      query += ' AND is_active = TRUE';
    }

    if (category) {
      query += ' AND category = ?';
      params.push(category);
    }

    if (search) {
      query += ' AND (name LIKE ? OR description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY category ASC, base_price ASC';

    const [services] = await pool.query(query, params);

    // Also get categories list
    const [categories] = await pool.query('SELECT DISTINCT category FROM services WHERE is_active = TRUE');

    res.json({
      success: true,
      services,
      categories: categories.map(c => c.category)
    });
  } catch (error) {
    console.error('[ServiceController.getAllServices] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getServiceById = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM services WHERE id = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Service not found.' });
    }
    res.json({ success: true, service: rows[0] });
  } catch (error) {
    console.error('[ServiceController.getServiceById] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.createService = async (req, res) => {
  try {
    const { name, category, description, estimated_duration_hours, base_price } = req.body;

    if (!name || !category || !base_price) {
      return res.status(400).json({ success: false, message: 'Name, category, and base price are required.' });
    }

    const serviceCode = 'SVC-' + Math.random().toString(36).substring(2, 7).toUpperCase();

    const [result] = await pool.query(
      `INSERT INTO services (service_code, name, category, description, estimated_duration_hours, base_price, is_active)
       VALUES (?, ?, ?, ?, ?, ?, TRUE)`,
      [serviceCode, name.trim(), category, description || '', Number(estimated_duration_hours) || 2.0, Number(base_price)]
    );

    const [created] = await pool.query('SELECT * FROM services WHERE id = ?', [result.insertId]);

    res.status(201).json({ success: true, message: 'Service created successfully', service: created[0] });
  } catch (error) {
    console.error('[ServiceController.createService] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.updateService = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, description, estimated_duration_hours, base_price, is_active } = req.body;

    await pool.query(
      `UPDATE services 
       SET name = COALESCE(?, name),
           category = COALESCE(?, category),
           description = COALESCE(?, description),
           estimated_duration_hours = COALESCE(?, estimated_duration_hours),
           base_price = COALESCE(?, base_price),
           is_active = COALESCE(?, is_active)
       WHERE id = ?`,
      [name, category, description, estimated_duration_hours, base_price, is_active, id]
    );

    const [updated] = await pool.query('SELECT * FROM services WHERE id = ?', [id]);
    res.json({ success: true, message: 'Service updated successfully', service: updated[0] });
  } catch (error) {
    console.error('[ServiceController.updateService] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};
