const pool = require('../config/db');

// Helper to recalculate invoice amounts based on base service and job items
async function recalculateInvoice(connection, bookingId) {
  // Get base service price
  const [bRows] = await connection.query(
    `SELECT s.base_price, inv.id as invoice_id, inv.discount_amount
     FROM service_bookings b
     JOIN services s ON b.service_id = s.id
     JOIN invoices inv ON b.id = inv.booking_id
     WHERE b.id = ?`,
    [bookingId]
  );

  if (bRows.length === 0) return;
  const basePrice = Number(bRows[0].base_price);
  const discount = Number(bRows[0].discount_amount || 0);

  // Get sum of all job items
  const [itemsSum] = await connection.query(
    `SELECT COALESCE(SUM(total_price), 0) AS parts_labor_total
     FROM job_items ji
     JOIN job_cards jc ON ji.job_card_id = jc.id
     WHERE jc.booking_id = ?`,
    [bookingId]
  );

  const partsTotal = Number(itemsSum[0].parts_labor_total);
  const taxableSubtotal = (basePrice + partsTotal) - discount;
  const tax = Number((taxableSubtotal * 0.18).toFixed(2));
  const grandTotal = Number((taxableSubtotal + tax).toFixed(2));

  await connection.query(
    `UPDATE invoices 
     SET service_base_amount = ?,
         additional_parts_labor = ?,
         tax_amount = ?,
         total_amount = ?
     WHERE booking_id = ?`,
    [basePrice, partsTotal, tax, grandTotal, bookingId]
  );
}

exports.getAllJobCards = async (req, res) => {
  try {
    const { status } = req.query;
    let query = `
      SELECT 
        j.*,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status as booking_status,
        u.full_name as customer_name,
        u.phone as customer_phone,
        v.reg_number,
        v.make,
        v.model,
        s.name as service_name,
        (SELECT COUNT(*) FROM job_items WHERE job_card_id = j.id) as item_count
      FROM job_cards j
      JOIN service_bookings b ON j.booking_id = b.id
      JOIN users u ON b.user_id = u.id
      JOIN vehicles v ON b.vehicle_id = v.id
      JOIN services s ON b.service_id = s.id
      WHERE 1=1
    `;
    const params = [];

    if (status && status !== 'ALL') {
      query += ' AND j.status = ?';
      params.push(status);
    }

    query += ' ORDER BY j.created_at DESC';

    const [rows] = await pool.query(query, params);
    res.json({ success: true, jobCards: rows });
  } catch (error) {
    console.error('[JobController.getAllJobCards] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getJobCardById = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `SELECT 
        j.*,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.customer_notes,
        b.status as booking_status,
        u.id as user_id,
        u.full_name as customer_name,
        u.phone as customer_phone,
        u.email as customer_email,
        v.reg_number,
        v.make,
        v.model,
        v.year,
        s.name as service_name,
        s.base_price as service_base_price,
        inv.id as invoice_id,
        inv.invoice_number,
        inv.total_amount,
        inv.payment_status
       FROM job_cards j
       JOIN service_bookings b ON j.booking_id = b.id
       JOIN users u ON b.user_id = u.id
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       LEFT JOIN invoices inv ON b.id = inv.booking_id
       WHERE j.id = ? OR j.booking_id = ?`,
      [id, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Job card not found.' });
    }

    const jobCard = rows[0];

    // Customer can only view their own job card
    if (req.user.role !== 'admin' && req.user.role !== 'technician' && jobCard.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    const [items] = await pool.query('SELECT * FROM job_items WHERE job_card_id = ? ORDER BY id ASC', [jobCard.id]);

    res.json({
      success: true,
      jobCard,
      items
    });
  } catch (error) {
    console.error('[JobController.getJobCardById] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.updateJobCard = async (req, res) => {
  try {
    const { id } = req.params;
    const { technician_name, bay_number, odometer_in, diagnosis_notes, work_summary, status } = req.body;

    const [existing] = await pool.query('SELECT * FROM job_cards WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ success: false, message: 'Job card not found.' });
    }

    await pool.query(
      `UPDATE job_cards 
       SET technician_name = COALESCE(?, technician_name),
           bay_number = COALESCE(?, bay_number),
           odometer_in = COALESCE(?, odometer_in),
           diagnosis_notes = COALESCE(?, diagnosis_notes),
           work_summary = COALESCE(?, work_summary),
           status = COALESCE(?, status)
       WHERE id = ?`,
      [technician_name, bay_number, odometer_in, diagnosis_notes, work_summary, status, id]
    );

    res.json({ success: true, message: 'Job card updated successfully.' });
  } catch (error) {
    console.error('[JobController.updateJobCard] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.addJobItem = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { id } = req.params; // job_card_id
    const { item_type, item_description, quantity, unit_price } = req.body;

    if (!item_type || !item_description || !unit_price) {
      return res.status(400).json({ success: false, message: 'Item type, description, and unit price are required.' });
    }

    const [jobRows] = await connection.query('SELECT id, booking_id FROM job_cards WHERE id = ?', [id]);
    if (jobRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Job card not found.' });
    }
    const bookingId = jobRows[0].booking_id;

    await connection.beginTransaction();

    await connection.query(
      `INSERT INTO job_items (job_card_id, item_type, item_description, quantity, unit_price)
       VALUES (?, ?, ?, ?, ?)`,
      [id, item_type, item_description.trim(), Number(quantity) || 1, Number(unit_price)]
    );

    // Automatically recalculate invoice
    await recalculateInvoice(connection, bookingId);

    await connection.commit();

    const [items] = await connection.query('SELECT * FROM job_items WHERE job_card_id = ?', [id]);
    res.status(201).json({ success: true, message: 'Job item added and invoice updated.', items });
  } catch (error) {
    await connection.rollback();
    console.error('[JobController.addJobItem] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  } finally {
    connection.release();
  }
};

exports.deleteJobItem = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { itemId } = req.params;

    const [itemRows] = await connection.query(
      `SELECT ji.id, jc.booking_id, jc.id as job_card_id 
       FROM job_items ji 
       JOIN job_cards jc ON ji.job_card_id = jc.id 
       WHERE ji.id = ?`,
      [itemId]
    );

    if (itemRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Job item not found.' });
    }

    const { booking_id, job_card_id } = itemRows[0];

    await connection.beginTransaction();

    await connection.query('DELETE FROM job_items WHERE id = ?', [itemId]);
    await recalculateInvoice(connection, booking_id);

    await connection.commit();

    const [items] = await connection.query('SELECT * FROM job_items WHERE job_card_id = ?', [job_card_id]);
    res.json({ success: true, message: 'Job item deleted and invoice updated.', items });
  } catch (error) {
    await connection.rollback();
    console.error('[JobController.deleteJobItem] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  } finally {
    connection.release();
  }
};
