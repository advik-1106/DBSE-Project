const pool = require('../config/db');

exports.getMyVehicles = async (req, res) => {
  try {
    const userId = req.user.role === 'admin' && req.query.user_id ? req.query.user_id : req.user.id;
    const [rows] = await pool.query(
      `SELECT v.*, 
        COUNT(b.id) as total_services,
        MAX(b.booking_date) as last_service_date
       FROM vehicles v
       LEFT JOIN service_bookings b ON v.id = b.vehicle_id
       WHERE v.user_id = ?
       GROUP BY v.id
       ORDER BY v.created_at DESC`,
      [userId]
    );

    res.json({ success: true, vehicles: rows });
  } catch (error) {
    console.error('[VehicleController.getMyVehicles] error:', error);
    res.status(500).json({ success: false, message: 'Server error fetching vehicles: ' + error.message });
  }
};

exports.getAllVehicles = async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT v.*, u.full_name as owner_name, u.phone as owner_phone, u.email as owner_email,
        COUNT(b.id) as total_services
       FROM vehicles v
       JOIN users u ON v.user_id = u.id
       LEFT JOIN service_bookings b ON v.id = b.vehicle_id
       GROUP BY v.id
       ORDER BY v.created_at DESC`
    );

    res.json({ success: true, vehicles: rows });
  } catch (error) {
    console.error('[VehicleController.getAllVehicles] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.addVehicle = async (req, res) => {
  try {
    const { reg_number, make, model, year, fuel_type, mileage_km, vin_number } = req.body;
    const userId = req.user.id;

    if (!reg_number || !make || !model || !year) {
      return res.status(400).json({ success: false, message: 'Registration number, make, model, and year are required.' });
    }

    const cleanReg = reg_number.toUpperCase().trim();

    // Check if registration number already exists
    const [existing] = await pool.query('SELECT id FROM vehicles WHERE reg_number = ?', [cleanReg]);
    if (existing.length > 0) {
      return res.status(409).json({ success: false, message: `Vehicle with registration "${cleanReg}" is already registered in the system.` });
    }

    const [result] = await pool.query(
      `INSERT INTO vehicles (user_id, reg_number, make, model, year, fuel_type, mileage_km, vin_number)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, cleanReg, make.trim(), model.trim(), Number(year), fuel_type || 'Petrol', Number(mileage_km) || 0, vin_number || null]
    );

    const [created] = await pool.query('SELECT * FROM vehicles WHERE id = ?', [result.insertId]);

    res.status(201).json({
      success: true,
      message: 'Vehicle added successfully',
      vehicle: created[0]
    });
  } catch (error) {
    console.error('[VehicleController.addVehicle] error:', error);
    res.status(500).json({ success: false, message: 'Server error adding vehicle: ' + error.message });
  }
};

exports.getVehicleById = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(
      `SELECT v.*, u.full_name as owner_name, u.phone as owner_phone, u.email as owner_email
       FROM vehicles v
       JOIN users u ON v.user_id = u.id
       WHERE v.id = ?`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    }

    const vehicle = rows[0];
    if (req.user.role !== 'admin' && vehicle.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied to this vehicle record.' });
    }

    res.json({ success: true, vehicle });
  } catch (error) {
    console.error('[VehicleController.getVehicleById] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getVehicleServiceHistory = async (req, res) => {
  try {
    const { id } = req.params;

    // Verify access
    const [vRows] = await pool.query('SELECT user_id, reg_number, make, model FROM vehicles WHERE id = ?', [id]);
    if (vRows.length === 0) {
      return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    }

    const vehicle = vRows[0];
    if (req.user.role !== 'admin' && vehicle.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied to this vehicle record.' });
    }

    // Query comprehensive history from view and joins
    const [history] = await pool.query(
      `SELECT 
        b.id AS booking_id,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status AS booking_status,
        b.customer_notes,
        s.name AS service_name,
        s.category AS service_category,
        s.base_price,
        j.job_number,
        j.technician_name,
        j.work_summary,
        j.status AS job_status,
        inv.invoice_number,
        inv.total_amount,
        inv.payment_status,
        inv.paid_at
       FROM service_bookings b
       JOIN services s ON b.service_id = s.id
       LEFT JOIN job_cards j ON b.id = j.booking_id
       LEFT JOIN invoices inv ON b.id = inv.booking_id
       WHERE b.vehicle_id = ?
       ORDER BY b.booking_date DESC, b.created_at DESC`,
      [id]
    );

    res.json({
      success: true,
      vehicle,
      history
    });
  } catch (error) {
    console.error('[VehicleController.getVehicleServiceHistory] error:', error);
    res.status(500).json({ success: false, message: 'Server error fetching history: ' + error.message });
  }
};

exports.deleteVehicle = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT user_id FROM vehicles WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    }

    if (req.user.role !== 'admin' && rows[0].user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized to delete this vehicle.' });
    }

    await pool.query('DELETE FROM vehicles WHERE id = ?', [id]);
    res.json({ success: true, message: 'Vehicle deleted successfully.' });
  } catch (error) {
    console.error('[VehicleController.deleteVehicle] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};
