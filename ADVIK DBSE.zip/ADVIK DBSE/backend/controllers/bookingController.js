const pool = require('../config/db');

exports.createBooking = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { vehicle_id, service_id, booking_date, time_slot, customer_notes } = req.body;
    const userId = req.user.id;

    if (!vehicle_id || !service_id || !booking_date || !time_slot) {
      return res.status(400).json({ success: false, message: 'Vehicle, service, booking date, and time slot are required.' });
    }

    // Verify vehicle belongs to user
    const [vCheck] = await connection.query('SELECT id, reg_number FROM vehicles WHERE id = ? AND user_id = ?', [vehicle_id, userId]);
    if (vCheck.length === 0 && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Invalid vehicle selected.' });
    }

    // Get service details
    const [sCheck] = await connection.query('SELECT id, name, base_price FROM services WHERE id = ?', [service_id]);
    if (sCheck.length === 0) {
      return res.status(404).json({ success: false, message: 'Service not found.' });
    }
    const service = sCheck[0];

    // Generate unique reference
    const bookingRef = 'BK-' + new Date().getFullYear() + '-' + Math.floor(100000 + Math.random() * 900000);
    const jobNumber = 'JOB-' + new Date().getFullYear() + '-' + Math.floor(10000 + Math.random() * 90000);
    const invoiceNumber = 'INV-' + new Date().getFullYear() + '-' + Math.floor(10000 + Math.random() * 90000);

    await connection.beginTransaction();

    // 1. Insert booking
    const [bResult] = await connection.query(
      `INSERT INTO service_bookings (booking_reference, user_id, vehicle_id, service_id, booking_date, time_slot, customer_notes, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING')`,
      [bookingRef, userId, vehicle_id, service_id, booking_date, time_slot, customer_notes || '']
    );
    const bookingId = bResult.insertId;

    // 2. Insert initial job card
    const [jResult] = await connection.query(
      `INSERT INTO job_cards (job_number, booking_id, technician_name, bay_number, diagnosis_notes, status)
       VALUES (?, ?, 'Assigned Service Specialist', 'Bay-1', 'Initial service queue assignment', 'QUEUED')`,
      [jobNumber, bookingId]
    );
    const jobCardId = jResult.insertId;

    // 3. Insert initial invoice (Base service + 18% GST)
    const basePrice = Number(service.base_price);
    const tax = Number((basePrice * 0.18).toFixed(2));
    const total = Number((basePrice + tax).toFixed(2));

    await connection.query(
      `INSERT INTO invoices (invoice_number, booking_id, job_card_id, service_base_amount, additional_parts_labor, discount_amount, tax_amount, total_amount, payment_status)
       VALUES (?, ?, ?, ?, 0.00, 0.00, ?, ?, 'UNPAID')`,
      [invoiceNumber, bookingId, jobCardId, basePrice, tax, total]
    );

    // 4. Log initial status in audit logs
    await connection.query(
      `INSERT INTO service_status_logs (booking_id, previous_status, new_status, updated_by, remarks)
       VALUES (?, NULL, 'PENDING', ?, 'Booking submitted online by customer.')`,
      [bookingId, req.user.full_name || 'Customer']
    );

    await connection.commit();

    res.status(201).json({
      success: true,
      message: 'Service appointment booked successfully!',
      booking: {
        id: bookingId,
        booking_reference: bookingRef,
        booking_date,
        time_slot,
        service_name: service.name,
        total_amount: total,
        status: 'PENDING'
      }
    });
  } catch (error) {
    await connection.rollback();
    console.error('[BookingController.createBooking] error:', error);
    res.status(500).json({ success: false, message: 'Server error creating booking: ' + error.message });
  } finally {
    connection.release();
  }
};

exports.getMyBookings = async (req, res) => {
  try {
    const userId = req.user.id;
    const [rows] = await pool.query(
      `SELECT 
        b.id,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status,
        b.customer_notes,
        b.created_at,
        v.id AS vehicle_id,
        v.reg_number,
        v.make,
        v.model,
        v.year,
        s.id AS service_id,
        s.name AS service_name,
        s.category AS service_category,
        s.base_price,
        j.id AS job_card_id,
        j.job_number,
        j.technician_name,
        j.status AS job_status,
        inv.id AS invoice_id,
        inv.invoice_number,
        inv.total_amount,
        inv.payment_status,
        inv.paid_at
       FROM service_bookings b
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       LEFT JOIN job_cards j ON b.id = j.booking_id
       LEFT JOIN invoices inv ON b.id = inv.booking_id
       WHERE b.user_id = ?
       ORDER BY b.booking_date DESC, b.created_at DESC`,
      [userId]
    );

    res.json({ success: true, bookings: rows });
  } catch (error) {
    console.error('[BookingController.getMyBookings] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getAllBookings = async (req, res) => {
  try {
    const { status, date, search } = req.query;
    let query = `
      SELECT 
        b.id,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status,
        b.customer_notes,
        b.created_at,
        u.id AS customer_id,
        u.full_name AS customer_name,
        u.email AS customer_email,
        u.phone AS customer_phone,
        v.reg_number,
        v.make,
        v.model,
        s.name AS service_name,
        s.base_price,
        j.id AS job_card_id,
        j.job_number,
        j.technician_name,
        j.status AS job_status,
        inv.id AS invoice_id,
        inv.invoice_number,
        inv.total_amount,
        inv.payment_status
      FROM service_bookings b
      JOIN users u ON b.user_id = u.id
      JOIN vehicles v ON b.vehicle_id = v.id
      JOIN services s ON b.service_id = s.id
      LEFT JOIN job_cards j ON b.id = j.booking_id
      LEFT JOIN invoices inv ON b.id = inv.booking_id
      WHERE 1=1
    `;
    const params = [];

    if (status && status !== 'ALL') {
      query += ' AND b.status = ?';
      params.push(status);
    }

    if (date) {
      query += ' AND b.booking_date = ?';
      params.push(date);
    }

    if (search) {
      query += ' AND (b.booking_reference LIKE ? OR u.full_name LIKE ? OR v.reg_number LIKE ?)';
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    query += ' ORDER BY b.created_at DESC';

    const [bookings] = await pool.query(query, params);
    res.json({ success: true, bookings });
  } catch (error) {
    console.error('[BookingController.getAllBookings] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.getBookingDetails = async (req, res) => {
  try {
    const { id } = req.params;

    // Fetch booking with details
    const [rows] = await pool.query(
      `SELECT 
        b.*,
        u.full_name AS customer_name,
        u.email AS customer_email,
        u.phone AS customer_phone,
        u.address AS customer_address,
        v.reg_number,
        v.make,
        v.model,
        v.year,
        v.fuel_type,
        v.mileage_km,
        s.name AS service_name,
        s.category AS service_category,
        s.base_price AS service_base_price,
        s.description AS service_description,
        j.id AS job_card_id,
        j.job_number,
        j.technician_name,
        j.bay_number,
        j.odometer_in,
        j.diagnosis_notes,
        j.work_summary,
        j.status AS job_status,
        inv.id AS invoice_id,
        inv.invoice_number,
        inv.service_base_amount,
        inv.additional_parts_labor,
        inv.discount_amount,
        inv.tax_amount,
        inv.total_amount,
        inv.payment_status,
        inv.paid_at
       FROM service_bookings b
       JOIN users u ON b.user_id = u.id
       JOIN vehicles v ON b.vehicle_id = v.id
       JOIN services s ON b.service_id = s.id
       LEFT JOIN job_cards j ON b.id = j.booking_id
       LEFT JOIN invoices inv ON b.id = inv.booking_id
       WHERE b.id = ? OR b.booking_reference = ?`,
      [id, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    const booking = rows[0];

    // Authorization check
    if (req.user.role !== 'admin' && req.user.role !== 'technician' && booking.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    // Get job items if job card exists
    let jobItems = [];
    if (booking.job_card_id) {
      const [items] = await pool.query('SELECT * FROM job_items WHERE job_card_id = ?', [booking.job_card_id]);
      jobItems = items;
    }

    // Get status timeline logs
    const [timelineLogs] = await pool.query(
      'SELECT * FROM service_status_logs WHERE booking_id = ? ORDER BY timestamp ASC',
      [booking.id]
    );

    // Get payment records if invoice exists
    let payments = [];
    if (booking.invoice_id) {
      const [pRows] = await pool.query('SELECT * FROM payments WHERE invoice_id = ? ORDER BY payment_date DESC', [booking.invoice_id]);
      payments = pRows;
    }

    res.json({
      success: true,
      booking,
      jobItems,
      timelineLogs,
      payments
    });
  } catch (error) {
    console.error('[BookingController.getBookingDetails] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.updateBookingStatus = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const { id } = req.params;
    const { status, remarks, technician_name, bay_number } = req.body;

    const validStatuses = ['PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY', 'COMPLETED', 'CANCELLED'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status provided.' });
    }

    const [current] = await connection.query('SELECT id, status FROM service_bookings WHERE id = ?', [id]);
    if (current.length === 0) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    const previousStatus = current[0].status;

    await connection.beginTransaction();

    // Update booking status
    await connection.query('UPDATE service_bookings SET status = ? WHERE id = ?', [status, id]);

    // Map booking status to job card status
    let jobStatus = 'QUEUED';
    if (status === 'IN_INSPECTION') jobStatus = 'INSPECTION';
    else if (status === 'IN_PROGRESS') jobStatus = 'SERVICE_IN_PROGRESS';
    else if (status === 'READY_FOR_DELIVERY') jobStatus = 'QUALITY_CHECK';
    else if (status === 'COMPLETED') jobStatus = 'COMPLETED';

    // Update job card
    let jobUpdateSql = 'UPDATE job_cards SET status = ?';
    const jobParams = [jobStatus];

    if (technician_name) {
      jobUpdateSql += ', technician_name = ?';
      jobParams.push(technician_name);
    }
    if (bay_number) {
      jobUpdateSql += ', bay_number = ?';
      jobParams.push(bay_number);
    }
    if (status === 'IN_PROGRESS') {
      jobUpdateSql += ', started_at = COALESCE(started_at, NOW())';
    }
    if (status === 'COMPLETED') {
      jobUpdateSql += ', completed_at = COALESCE(completed_at, NOW())';
    }

    jobUpdateSql += ' WHERE booking_id = ?';
    jobParams.push(id);

    await connection.query(jobUpdateSql, jobParams);

    // Insert status log
    await connection.query(
      `INSERT INTO service_status_logs (booking_id, previous_status, new_status, updated_by, remarks)
       VALUES (?, ?, ?, ?, ?)`,
      [id, previousStatus, status, req.user.full_name || 'Staff Admin', remarks || `Status updated to ${status}`]
    );

    await connection.commit();

    res.json({
      success: true,
      message: `Booking status successfully updated from ${previousStatus} to ${status}`
    });
  } catch (error) {
    await connection.rollback();
    console.error('[BookingController.updateBookingStatus] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  } finally {
    connection.release();
  }
};

exports.cancelBooking = async (req, res) => {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT * FROM service_bookings WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Booking not found.' });
    }

    const booking = rows[0];
    if (req.user.role !== 'admin' && booking.user_id !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    if (['IN_PROGRESS', 'READY_FOR_DELIVERY', 'COMPLETED'].includes(booking.status)) {
      return res.status(400).json({ success: false, message: 'Cannot cancel a booking that is currently in progress or completed.' });
    }

    await pool.query('UPDATE service_bookings SET status = "CANCELLED" WHERE id = ?', [id]);
    await pool.query(
      `INSERT INTO service_status_logs (booking_id, previous_status, new_status, updated_by, remarks)
       VALUES (?, ?, 'CANCELLED', ?, 'Appointment cancelled by user/admin.')`,
      [id, booking.status, req.user.full_name || 'User']
    );

    res.json({ success: true, message: 'Booking cancelled successfully.' });
  } catch (error) {
    console.error('[BookingController.cancelBooking] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};
