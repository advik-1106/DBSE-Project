const pool = require('../config/db');

exports.getAdminDashboardStats = async (req, res) => {
  try {
    // 1. Overall counts
    const [bookingCounts] = await pool.query(`
      SELECT 
        COUNT(*) as total_bookings,
        COUNT(CASE WHEN status IN ('PENDING', 'CONFIRMED') THEN 1 END) as pending_bookings,
        COUNT(CASE WHEN status IN ('IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY') THEN 1 END) as active_jobs,
        COUNT(CASE WHEN status = 'COMPLETED' THEN 1 END) as completed_services,
        COUNT(CASE WHEN status = 'CANCELLED' THEN 1 END) as cancelled_bookings
      FROM service_bookings
    `);

    // 2. Financial Metrics
    const [revenueCounts] = await pool.query(`
      SELECT 
        COALESCE(SUM(CASE WHEN payment_status = 'PAID' THEN total_amount ELSE 0 END), 0) as total_revenue,
        COALESCE(SUM(CASE WHEN payment_status = 'UNPAID' THEN total_amount ELSE 0 END), 0) as pending_payments,
        COUNT(CASE WHEN payment_status = 'PAID' THEN 1 END) as paid_invoices_count,
        COUNT(CASE WHEN payment_status = 'UNPAID' THEN 1 END) as unpaid_invoices_count
      FROM invoices
    `);

    // 3. Registered counts
    const [userVehicles] = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM users WHERE role = 'customer') as total_customers,
        (SELECT COUNT(*) FROM vehicles) as total_vehicles,
        (SELECT COUNT(*) FROM services WHERE is_active = TRUE) as total_services
    `);

    // 4. Recent 5 bookings
    const [recentBookings] = await pool.query(`
      SELECT 
        b.id,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status,
        u.full_name as customer_name,
        v.reg_number,
        v.make,
        v.model,
        s.name as service_name,
        inv.total_amount,
        inv.payment_status
      FROM service_bookings b
      JOIN users u ON b.user_id = u.id
      JOIN vehicles v ON b.vehicle_id = v.id
      JOIN services s ON b.service_id = s.id
      LEFT JOIN invoices inv ON b.id = inv.booking_id
      ORDER BY b.created_at DESC
      LIMIT 6
    `);

    // 5. Popular services breakdown
    const [popularServices] = await pool.query(`
      SELECT 
        s.name, 
        s.category, 
        COUNT(b.id) as booking_count,
        COALESCE(SUM(inv.total_amount), 0) as revenue_generated
      FROM services s
      LEFT JOIN service_bookings b ON s.id = b.service_id
      LEFT JOIN invoices inv ON b.id = inv.booking_id
      GROUP BY s.id
      ORDER BY booking_count DESC
      LIMIT 5
    `);

    res.json({
      success: true,
      stats: {
        ...bookingCounts[0],
        ...revenueCounts[0],
        ...userVehicles[0]
      },
      recentBookings,
      popularServices
    });
  } catch (error) {
    console.error('[DashboardController.getAdminDashboardStats] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};

exports.searchVehicleHistoryByReg = async (req, res) => {
  try {
    const { regNumber } = req.params;
    const cleanReg = regNumber.toUpperCase().trim();

    const [vRows] = await pool.query(
      `SELECT v.*, u.full_name as owner_name, u.phone as owner_phone, u.email as owner_email
       FROM vehicles v
       JOIN users u ON v.user_id = u.id
       WHERE v.reg_number = ?`,
      [cleanReg]
    );

    if (vRows.length === 0) {
      return res.status(404).json({ success: false, message: `No vehicle found with registration number "${cleanReg}".` });
    }

    const vehicle = vRows[0];

    const [history] = await pool.query(
      `SELECT 
        b.id AS booking_id,
        b.booking_reference,
        b.booking_date,
        b.time_slot,
        b.status AS booking_status,
        b.customer_notes,
        s.name AS service_name,
        s.category AS service_category,
        j.job_number,
        j.technician_name,
        j.work_summary,
        inv.invoice_number,
        inv.total_amount,
        inv.payment_status,
        inv.paid_at
       FROM service_bookings b
       JOIN services s ON b.service_id = s.id
       LEFT JOIN job_cards j ON b.id = j.booking_id
       LEFT JOIN invoices inv ON b.id = inv.booking_id
       WHERE b.vehicle_id = ?
       ORDER BY b.booking_date DESC`,
      [vehicle.id]
    );

    res.json({
      success: true,
      vehicle,
      history
    });
  } catch (error) {
    console.error('[DashboardController.searchVehicleHistoryByReg] error:', error);
    res.status(500).json({ success: false, message: 'Server error: ' + error.message });
  }
};
