const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config({ path: path.resolve(__dirname, '..', '.env') });

async function initDb() {
  console.log('[InitDB] Connecting to MySQL server...');
  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || 'root',
    port: Number(process.env.DB_PORT) || 3306,
    multipleStatements: true
  });

  try {
    const schemaSql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    const seedSql = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf8');

    console.log('[InitDB] Applying schema...');
    await connection.query(schemaSql);
    console.log('[InitDB] Schema applied successfully.');

    console.log('[InitDB] Seeding initial data...');
    await connection.query(seedSql);
    console.log('[InitDB] Data seeded successfully.');

    console.log('[InitDB] Database initialization completed!');
  } catch (err) {
    console.error('[InitDB] Error during database initialization:', err);
    throw err;
  } finally {
    await connection.end();
  }
}

if (require.main === module) {
  initDb().catch((err) => {
    console.error('[InitDB] MySQL error:', err.message);
    console.error('[InitDB] Initialization failed. Check MySQL is running and backend/.env contains valid database credentials.');
    process.exitCode = 1;
  });
}

module.exports = initDb;
