-- =====================================================================
-- SEED DATA FOR AUTOMOTIVE SERVICE BOOKING & PAYMENT SYSTEM
-- =====================================================================

USE automotive_service_db;

-- 1. Default Users
-- Admin: admin@autocare.com / password: admin123
-- Customers & Tech password: password123 (or advik123/manasa123)
INSERT INTO users (id, full_name, email, password_hash, phone, role, address) VALUES
(1, 'Service Center Admin', 'admin@autocare.com', '$2a$10$mDhLC9nwlIkfTU5zryNeuucvMxQri0Hh0BnV/LRrOdap5KQdPpChK', '+91 9876543210', 'admin', 'AutoCare Service Hub, KLH Tech Park, Hyderabad'),
(2, 'T. Advik (Customer)', 'advik@example.com', '$2a$10$REifBDIXSnkKdWKBwzT6reR.g28KKqavZ3mzSLOELksaDyexjgjlu', '+91 9848012345', 'customer', 'Hitech City, Hyderabad, Telangana'),
(3, 'M. Manasa (Customer)', 'manasa@example.com', '$2a$10$REifBDIXSnkKdWKBwzT6reR.g28KKqavZ3mzSLOELksaDyexjgjlu', '+91 9988776655', 'customer', 'Gachibowli, Hyderabad, Telangana'),
(4, 'Vikram Sharma (Lead Tech)', 'vikram.tech@autocare.com', '$2a$10$REifBDIXSnkKdWKBwzT6reR.g28KKqavZ3mzSLOELksaDyexjgjlu', '+91 9123456780', 'technician', 'Service Bay 1, AutoCare Central')
ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash), full_name=VALUES(full_name);

-- 2. Vehicle Catalog
INSERT INTO vehicles (id, user_id, reg_number, make, model, year, fuel_type, mileage_km, vin_number) VALUES
(1, 2, 'TS 09 EQ 4038', 'Honda', 'City ZX i-VTEC', 2022, 'Petrol', 24500, 'MAKGM2650N400129'),
(2, 2, 'TS 07 HK 9623', 'Hyundai', 'Creta SX(O)', 2023, 'Diesel', 18200, 'MALC381CLPM10928'),
(3, 3, 'TS 08 FA 1102', 'Tata', 'Nexon EV Empowered', 2024, 'Electric', 11300, 'MAT621422R901923')
ON DUPLICATE KEY UPDATE reg_number=VALUES(reg_number);

-- 3. Standard Services Catalog
INSERT INTO services (id, service_code, name, category, description, estimated_duration_hours, base_price, is_active) VALUES
(1, 'SVC-GEN-01', 'General Periodic Service', 'Periodic Maintenance', 'Engine oil flush & replacement, oil filter change, air filter cleaning, 50-point full vehicle safety inspection & fluid top-ups.', 3.0, 3499.00, TRUE),
(2, 'SVC-OIL-02', 'Synthetic Oil & Filter Service', 'Periodic Maintenance', '100% Synthetic 5W-30 engine oil change, genuine OEM oil filter replacement, chassis lubrication & computer diagnostics.', 1.5, 2199.00, TRUE),
(3, 'SVC-BRK-03', 'Complete Brake System Overhaul', 'Tyres & Brakes', 'Front & rear brake pad replacement, rotor skimming/polishing, brake fluid bleeding, ABS sensor calibration & caliper greasing.', 2.5, 2899.00, TRUE),
(4, 'SVC-AC-04', 'HVAC & Climate Control Service', 'Electrical & AC', 'AC gas recharging (R134a/R1234yf), evaporator coil cleaning, cabin pollen filter replacement, cooling performance benchmark test.', 2.0, 2499.00, TRUE),
(5, 'SVC-WHL-05', 'Wheel Alignment & 3D Balancing', 'Tyres & Brakes', 'Laser computer wheel alignment, 4-wheel dynamic balancing, tyre rotation and nitrogen tire inflation.', 1.0, 1199.00, TRUE),
(6, 'SVC-ENG-06', 'Engine Performance & ECU Tuning', 'Mechanical Repair', 'Throttle body de-carbonization, spark plug replacement, injector cleaning, fuel pump pressure test & electronic fault clearing.', 4.0, 4799.00, TRUE),
(7, 'SVC-DET-07', 'Ceramic Shield & Interior Spa', 'Body & Detailing', 'Deep steam interior sanitization, leather conditioning, 3-stage exterior paint correction polish, ceramic paint sealant protection.', 5.0, 5999.00, TRUE)
ON DUPLICATE KEY UPDATE name=VALUES(name);

-- 4. Sample Service Bookings
INSERT INTO service_bookings (id, booking_reference, user_id, vehicle_id, service_id, booking_date, time_slot, customer_notes, status) VALUES
(1, 'BK-2026-001', 2, 1, 1, '2026-10-01', '09:00 AM - 11:00 AM', 'Periodic 25,000 km general service. Slight noise from front suspension during bumps.', 'COMPLETED'),
(2, 'BK-2026-002', 2, 2, 4, '2026-10-03', '11:00 AM - 01:00 PM', 'AC cooling is insufficient during afternoon driving.', 'IN_PROGRESS'),
(3, 'BK-2026-003', 3, 3, 5, '2026-10-04', '02:00 PM - 04:00 PM', 'Steering vibrates at speeds over 80 km/h. Please balance all 4 wheels.', 'CONFIRMED')
ON DUPLICATE KEY UPDATE booking_reference=VALUES(booking_reference);

-- 5. Job Cards
INSERT INTO job_cards (id, job_number, booking_id, technician_name, bay_number, odometer_in, diagnosis_notes, work_summary, status, started_at, completed_at) VALUES
(1, 'JOB-2026-101', 1, 'Vikram Sharma', 'Bay-3', 24480, 'Engine oil degraded; air filter choked. Front stabilizer link bush worn out.', 'Performed full oil & filter change. Replaced front suspension stabilizer bush. Cleaned spark plugs.', 'COMPLETED', '2026-10-01 09:30:00', '2026-10-01 13:15:00'),
(2, 'JOB-2026-102', 2, 'Vikram Sharma', 'Bay-1', 18190, 'Low AC gas pressure detected (18 PSI). Minor O-ring leak near condenser port.', 'O-ring seal replaced. System vacuum tested, R134a refrigerant recharged. Testing cabin vent temperature.', 'SERVICE_IN_PROGRESS', '2026-10-03 10:15:00', NULL)
ON DUPLICATE KEY UPDATE job_number=VALUES(job_number);

-- 6. Job Items (Parts & Labor)
INSERT INTO job_items (id, job_card_id, item_type, item_description, quantity, unit_price) VALUES
(1, 1, 'PART', 'OEM Synthetic Engine Oil 5W-30 (3.5L)', 1, 1850.00),
(2, 1, 'PART', 'Genuine Oil Filter Cartridge', 1, 350.00),
(3, 1, 'PART', 'Front Stabilizer Link Bushing Kit', 1, 850.00),
(4, 1, 'LABOR', 'Suspension Bush Replacement Labor', 1, 500.00),
(5, 2, 'CONSUMABLE', 'R134a Refrigerant Gas 450g', 1, 850.00),
(6, 2, 'PART', 'Condenser High Pressure O-Ring Kit', 1, 280.00)
ON DUPLICATE KEY UPDATE item_description=VALUES(item_description);

-- 7. Invoices
INSERT INTO invoices (id, invoice_number, booking_id, job_card_id, service_base_amount, additional_parts_labor, discount_amount, tax_amount, total_amount, payment_status, paid_at) VALUES
(1, 'INV-2026-9001', 1, 1, 3499.00, 3550.00, 300.00, 1214.82, 7963.82, 'PAID', '2026-10-01 13:30:00'),
(2, 'INV-2026-9002', 2, 2, 2499.00, 1130.00, 0.00, 653.22, 4282.22, 'UNPAID', NULL)
ON DUPLICATE KEY UPDATE invoice_number=VALUES(invoice_number);

-- 8. Payments
INSERT INTO payments (id, payment_reference, invoice_id, amount, payment_method, transaction_id, gateway_response, status, payment_date) VALUES
(1, 'PAY-TXN-77382', 1, 7963.82, 'UPI', 'UPI/20261001/88392193820', '{"status":"SUCCESS","gateway":"Razorpay Mock Gateway","bank_ref":"SBIN004829"}', 'SUCCESS', '2026-10-01 13:30:00')
ON DUPLICATE KEY UPDATE payment_reference=VALUES(payment_reference);

-- 9. Status Audit Trail Logs
INSERT INTO service_status_logs (booking_id, previous_status, new_status, updated_by, remarks) VALUES
(1, 'PENDING', 'CONFIRMED', 'Admin', 'Customer booking approved and slot reserved.'),
(1, 'CONFIRMED', 'IN_INSPECTION', 'Vikram Sharma', 'Vehicle received at Bay-3. Starting preliminary inspection.'),
(1, 'IN_INSPECTION', 'IN_PROGRESS', 'Vikram Sharma', 'Parts approved. Oil change & suspension overhaul initiated.'),
(1, 'IN_PROGRESS', 'READY_FOR_DELIVERY', 'Vikram Sharma', 'Service complete and test drive verified.'),
(1, 'READY_FOR_DELIVERY', 'COMPLETED', 'Admin', 'Payment of ₹7,963.82 received. Vehicle handed over to customer.'),
(2, 'PENDING', 'CONFIRMED', 'Admin', 'Slot confirmed for AC diagnostics.'),
(2, 'CONFIRMED', 'IN_INSPECTION', 'Vikram Sharma', 'Vehicle checked in. AC manifold gauge connected.'),
(2, 'IN_INSPECTION', 'IN_PROGRESS', 'Vikram Sharma', 'O-ring leak repaired, refrigerant recharge underway.');
