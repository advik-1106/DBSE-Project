-- =====================================================================
-- DATABASE SYSTEMS ENGINEERING AND DISTRIBUTED BACKEND DEVELOPMENT
-- Course Code: 25CS1302E | Academic Year 2026-2027
-- Project Title: Online Service Job Booking & Payment System for Automotive
-- Team: Sec-02, Team-30 | Members: M.Manasa (2520030438), T.Advik (2520039623)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS automotive_service_db;
USE automotive_service_db;

-- 1. Users Table (Role-based: customer, admin, technician)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role ENUM('customer', 'admin', 'technician') NOT NULL DEFAULT 'customer',
    address TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_email (email),
    INDEX idx_user_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Vehicles Table
CREATE TABLE IF NOT EXISTS vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    reg_number VARCHAR(25) NOT NULL UNIQUE,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    fuel_type ENUM('Petrol', 'Diesel', 'Electric', 'Hybrid', 'CNG') DEFAULT 'Petrol',
    mileage_km INT DEFAULT 0,
    vin_number VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vehicle_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_reg_number (reg_number),
    INDEX idx_vehicle_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Services Catalog Table
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    service_code VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    category ENUM('Periodic Maintenance', 'Mechanical Repair', 'Electrical & AC', 'Tyres & Brakes', 'Body & Detailing') NOT NULL,
    description TEXT,
    estimated_duration_hours DECIMAL(3,1) DEFAULT 2.0,
    base_price DECIMAL(10,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Service Bookings Table
CREATE TABLE IF NOT EXISTS service_bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(30) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    service_id INT NOT NULL,
    booking_date DATE NOT NULL,
    time_slot VARCHAR(30) NOT NULL,
    customer_notes TEXT NULL,
    status ENUM('PENDING', 'CONFIRMED', 'IN_INSPECTION', 'IN_PROGRESS', 'READY_FOR_DELIVERY', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_booking_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE,
    CONSTRAINT fk_booking_service FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE RESTRICT,
    INDEX idx_booking_user (user_id),
    INDEX idx_booking_vehicle (vehicle_id),
    INDEX idx_booking_status (status),
    INDEX idx_booking_date (booking_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Job Cards Table (Service Center execution & diagnostics)
CREATE TABLE IF NOT EXISTS job_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_number VARCHAR(30) NOT NULL UNIQUE,
    booking_id INT NOT NULL UNIQUE,
    technician_name VARCHAR(100) DEFAULT 'Senior Technician',
    bay_number VARCHAR(20) DEFAULT 'Bay-1',
    odometer_in INT DEFAULT 0,
    diagnosis_notes TEXT NULL,
    work_summary TEXT NULL,
    status ENUM('QUEUED', 'INSPECTION', 'SERVICE_IN_PROGRESS', 'QUALITY_CHECK', 'COMPLETED') DEFAULT 'QUEUED',
    started_at DATETIME NULL,
    completed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_job_booking FOREIGN KEY (booking_id) REFERENCES service_bookings(id) ON DELETE CASCADE,
    INDEX idx_job_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Job Items Table (Parts replaced & Additional labor tasks)
CREATE TABLE IF NOT EXISTS job_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_card_id INT NOT NULL,
    item_type ENUM('PART', 'LABOR', 'CONSUMABLE') NOT NULL,
    item_description VARCHAR(150) NOT NULL,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    CONSTRAINT fk_item_job_card FOREIGN KEY (job_card_id) REFERENCES job_cards(id) ON DELETE CASCADE,
    INDEX idx_job_item_job (job_card_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Invoices Table
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(30) NOT NULL UNIQUE,
    booking_id INT NOT NULL UNIQUE,
    job_card_id INT NULL,
    service_base_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    additional_parts_labor DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    payment_status ENUM('UNPAID', 'PAID', 'REFUNDED') DEFAULT 'UNPAID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at DATETIME NULL,
    CONSTRAINT fk_invoice_booking FOREIGN KEY (booking_id) REFERENCES service_bookings(id) ON DELETE CASCADE,
    CONSTRAINT fk_invoice_job FOREIGN KEY (job_card_id) REFERENCES job_cards(id) ON DELETE SET NULL,
    INDEX idx_invoice_status (payment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Payments Table (Transaction gateway records)
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    payment_reference VARCHAR(50) NOT NULL UNIQUE,
    invoice_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('UPI', 'CREDIT_CARD', 'DEBIT_CARD', 'NET_BANKING', 'CASH') NOT NULL,
    transaction_id VARCHAR(100) NOT NULL,
    gateway_response TEXT NULL,
    status ENUM('SUCCESS', 'FAILED', 'PENDING') DEFAULT 'SUCCESS',
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_payment_invoice FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
    INDEX idx_payment_invoice (invoice_id),
    INDEX idx_payment_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. Status Audit Logs Table (Distributed Tracking & State Timeline)
CREATE TABLE IF NOT EXISTS service_status_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    previous_status VARCHAR(50),
    new_status VARCHAR(50) NOT NULL,
    updated_by VARCHAR(100) DEFAULT 'Service Center Staff',
    remarks TEXT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_booking FOREIGN KEY (booking_id) REFERENCES service_bookings(id) ON DELETE CASCADE,
    INDEX idx_log_booking (booking_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================================
-- DATABASE VIEWS
-- =====================================================================

-- Comprehensive view for Active Bookings and Live Tracking
CREATE OR REPLACE VIEW vw_booking_details AS
SELECT 
    b.id AS booking_id,
    b.booking_reference,
    b.booking_date,
    b.time_slot,
    b.customer_notes,
    b.status AS booking_status,
    b.created_at AS booking_created_at,
    
    u.id AS customer_id,
    u.full_name AS customer_name,
    u.email AS customer_email,
    u.phone AS customer_phone,
    
    v.id AS vehicle_id,
    v.reg_number,
    v.make,
    v.model,
    v.year AS vehicle_year,
    v.fuel_type,
    
    s.id AS service_id,
    s.service_code,
    s.name AS service_name,
    s.category AS service_category,
    s.base_price AS service_base_price,
    s.estimated_duration_hours,
    
    j.id AS job_card_id,
    j.job_number,
    j.technician_name,
    j.bay_number,
    j.status AS job_status,
    j.diagnosis_notes,
    j.work_summary,
    
    inv.id AS invoice_id,
    inv.invoice_number,
    inv.total_amount,
    inv.payment_status,
    inv.paid_at
FROM service_bookings b
JOIN users u ON b.user_id = u.id
JOIN vehicles v ON b.vehicle_id = v.id
JOIN services s ON b.service_id = s.id
LEFT JOIN job_cards j ON b.id = j.booking_id
LEFT JOIN invoices inv ON b.id = inv.booking_id;

-- Complete Vehicle Service History View
CREATE OR REPLACE VIEW vw_vehicle_history AS
SELECT 
    v.id AS vehicle_id,
    v.reg_number,
    v.make,
    v.model,
    b.id AS booking_id,
    b.booking_reference,
    b.booking_date,
    b.status AS service_status,
    s.name AS service_name,
    s.category AS service_category,
    j.job_number,
    j.technician_name,
    j.work_summary,
    inv.total_amount,
    inv.payment_status
FROM vehicles v
JOIN service_bookings b ON v.id = b.vehicle_id
JOIN services s ON b.service_id = s.id
LEFT JOIN job_cards j ON b.id = j.booking_id
LEFT JOIN invoices inv ON b.id = inv.booking_id
ORDER BY b.booking_date DESC;
