const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const { handleDemoRequest } = require('./config/demoData');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
let databaseReady = false;

// Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

app.use((req, res, next) => {
  if (req.path === '/api/health') {
    return next();
  }

  if (!databaseReady && req.path.startsWith('/api')) {
    return handleDemoRequest(req, res, next);
  }

  next();
});

// API Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/services', require('./routes/serviceRoutes'));
app.use('/api/vehicles', require('./routes/vehicleRoutes'));
app.use('/api/bookings', require('./routes/bookingRoutes'));
app.use('/api/jobs', require('./routes/jobRoutes'));
app.use('/api/billing', require('./routes/paymentRoutes'));
app.use('/api/dashboard', require('./routes/dashboardRoutes'));

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const { isDatabaseAvailable } = require('./config/db');
  const databaseReady = await isDatabaseAvailable();

  res.json({
    status: 'ONLINE',
    database: databaseReady ? 'CONNECTED' : 'DEGRADED / NOT CONFIGURED',
    project: 'Online Service Job Booking & Payment System for Automotive',
    course: 'DATABASE SYSTEMS ENGINEERING AND DISTRIBUTED BACKEND DEVELOPMENT (25CS1302E)',
    team: 'Sec-02, Team-30 (M.Manasa & T.Advik)',
    timestamp: new Date().toISOString()
  });
});

// Fallback error handler
app.use((err, req, res, next) => {
  console.error('[Global Error Handler]:', err.stack);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

async function startServer() {
  const { isDatabaseAvailable } = require('./config/db');
  databaseReady = await isDatabaseAvailable();

  if (!databaseReady) {
    console.warn('[DB] MySQL is not reachable right now. The backend will continue running in degraded mode.');
    console.warn('[DB] Update backend/.env with the correct DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, and DB_PORT values and restart the backend to enable database features.');
  }

  app.listen(PORT, () => {
    console.log(`================================================================`);
    console.log(` Automotive Service Backend Server running on port ${PORT}`);
    console.log(` Health URL: http://localhost:${PORT}/api/health`);
    console.log(` Database: ${databaseReady ? 'CONNECTED' : 'DEGRADED / NOT CONFIGURED'}`);
    console.log(` Project: Online Service Job Booking & Payment System`);
    console.log(` Team: Sec-02 Team-30 (Advik & Manasa)`);
    console.log(`================================================================`);
  });
}

startServer();
