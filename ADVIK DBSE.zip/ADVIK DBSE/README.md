# Online Service Job Booking & Payment System for Automotive
### Course: DATABASE SYSTEMS ENGINEERING AND DISTRIBUTED BACKEND DEVELOPMENT (25CS1302E)
**Academic Year:** 2026-2027 | Trimester - 4  
**Institution:** Koneru Lakshmaiah Education Foundation (KLH Deemed to be University)  
**Section:** Sec No-02 | **Team:** Team No-30  

### Team Members:
- **T. Advik** (Roll No: `2520039623`)
- **M. Manasa** (Roll No: `2520030438`)

---

## 1. Project Overview & Abstract
The **Online Service Job Booking and Payment System for Automotive** is an end-to-end full-stack distributed web platform designed to digitize and streamline vehicle servicing operations. In conventional automotive workshops, customers experience long waiting times, lack of real-time service visibility, manual paper-based job cards, and fragmented payment collection.

This solution provides:
1. **Customer Portal:**
   - Vehicle registration & garage management (Make, Model, Year, Fuel type, Odometer, Reg number).
   - Online appointment scheduling with service package selection, date & bay slot reservation.
   - **Real-Time Live Service Job Tracker** (Visual pipeline: Booked &rarr; In Inspection &rarr; Service In Progress &rarr; Quality Check &rarr; Delivered).
   - **Online Payment Gateway** (Simulated gateway supporting UPI / QR Code, Credit & Debit Cards, Net Banking).
   - Itemized GST Tax Invoices (with printable/downloadable PDF format).
   - Complete vehicle service history stored in the relational database.

2. **Service Center & Workshop Management:**
   - Operational dashboard with financial metrics (settled revenue, pending receivables, active jobs).
   - Appointment status transitions with technician assignment and bay allocation.
   - Digital Workshop Job Cards: add replaced parts, consumables, and labor tasks with automated dynamic invoice recalculation.
   - Master Vehicle Database Search: Query any vehicle registration number to retrieve full historical maintenance records.

---

## 2. Technology Stack
- **Frontend:** React.js 18, Vite, Lucide Icons, Pure Responsive Modern CSS Design System.
- **Backend:** Node.js, Express.js (REST API, JWT Authentication, Connection Pooling).
- **Database:** MySQL 8.0 (Normalized 3NF relational schema, Foreign Keys, Generated Columns, Views, and Audit Trails).
- **Payment:** Simulated Multi-Mode Online Payment Gateway (UPI / QR, Cards, Net Banking).

---

## 3. Database Architecture (MySQL)
Database Name: `automotive_service_db`

### Core Tables:
1. `users` &mdash; Role-based authentication (`customer`, `admin`, `technician`) with bcrypt hashing.
2. `vehicles` &mdash; Customer vehicle garage with foreign key references to `users(id)`.
3. `services` &mdash; Catalog of automotive maintenance packages with base rates & estimated durations.
4. `service_bookings` &mdash; Service appointment bookings with unique reference codes (`BK-2026-XXXX`).
5. `job_cards` &mdash; Workshop bay diagnostic records, assigned technician, and inspection findings.
6. `job_items` &mdash; Dynamic parts replaced & labor items with generated total columns.
7. `invoices` &mdash; GST tax invoices linked to bookings and job cards.
8. `payments` &mdash; Payment transaction audit logs with gateway references.
9. `service_status_logs` &mdash; Distributed state tracking audit timeline.

### Database Views:
- `vw_booking_details` &mdash; Joined view of bookings, customer details, vehicles, and billing.
- `vw_vehicle_history` &mdash; Chronological maintenance and invoice history for all vehicles.

---

## 4. Default Demo Accounts

| Role | Email | Password |
|---|---|---|
| **Service Center Admin** | `admin@autocare.com` | `admin123` |
| **Customer (T. Advik)** | `advik@example.com` | `password123` |
| **Customer (M. Manasa)** | `manasa@example.com` | `password123` |
| **Lead Technician** | `vikram.tech@autocare.com` | `password123` |

*(Note: The login page includes 1-click quick login buttons for instant evaluation!)*

---

## 5. How to Run the Project

### Prerequisites:
- Node.js (v18+)
- MySQL Server 8.0 running locally on port 3306
- A MySQL account with permission to create and use `automotive_service_db`

### Option A: One-Click Startup (Windows)
Double-click `run-all.bat` in the project root directory.

### Option B: Manual Startup

#### 1. Backend:
```bash
cd backend
npm install
```

Set `DB_HOST`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`, and `DB_PORT` in `backend/.env` to match your local MySQL setup. Do not assume the MySQL password is `root`; use the password configured for your local MySQL account.

```bash
npm run init-db    # Initializes MySQL tables, views, and seed data
npm start          # Runs backend on http://localhost:5001
```

#### 2. Frontend:
```bash
cd frontend
npm install
npm run dev        # Runs React Vite development server on http://localhost:3000
```

Open your browser at: **`http://localhost:3000`**
