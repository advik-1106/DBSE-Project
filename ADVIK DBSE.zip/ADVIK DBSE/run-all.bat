@echo off
title AutoCare Pro - Service Job Booking & Payment System
color 0b

echo =====================================================================
echo  DATABASE SYSTEMS ENGINEERING AND DISTRIBUTED BACKEND DEVELOPMENT
echo  Course: 25CS1302E ^| Sec-02 Team-30 (M.Manasa ^& T.Advik)
echo  Project: Online Service Job Booking ^& Payment System for Automotive
echo =====================================================================
echo.

echo [1/4] Checking Database Service (Port 3306)...
netstat -ano | findstr :3306 | findstr LISTENING >nul
if %ERRORLEVEL% NEQ 0 (
    echo [INFO] Starting Database Engine (MariaDB)...
    if exist "C:\Program Files\MariaDB 13.0\bin\mariadbd.exe" (
        start "AutoCare Database Server" /min "C:\Program Files\MariaDB 13.0\bin\mariadbd.exe" --defaults-file="C:\Program Files\MariaDB 13.0\data\my.ini"
        timeout /t 3 >nul
    )
)

echo.
echo [2/4] Initializing MySQL Database & Seed Data...
cd backend
call npm run init-db
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Database initialization failed.
    echo Check that MySQL is running and backend\.env has the correct credentials.
    pause
    exit /b 1
)

echo.
echo [3/4] Starting Backend API Server (Port 5001)...
start "AutoCare Backend Server (Port 5001)" cmd /k "npm start"
cd ..

echo.
echo [4/4] Starting Frontend React Application (Port 3000)...
cd frontend
start "AutoCare Frontend React (Port 3000)" cmd /k "npm run dev"
cd ..

echo.
echo =====================================================================
echo  Both Servers Started Successfully!
echo  Opening http://localhost:3000 in your browser...
echo =====================================================================
timeout /t 3 >nul
start http://localhost:3000

pause
